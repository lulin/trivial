/**
 * Data model, double check luci-1.0.0/doc/api.md:
 */

#include <libphi_cgi.h>
#include <vpn_client.h>

#define nv2json(k) (json_object_new_string(nvram_safe_get(k)))

int get_vpnc_conf(json_object *object)
{
    json_object *carry;

    if ((carry = json_object_new_object()) == NULL) {
        cgi_debug("json new failed, run out of memory?\n");
        return NV_FAIL;
    }

    json_object_object_add(carry, "enable", nv2json(NV_KEY_VPNC_ENABLE));
    json_object_object_add(carry, "status", nv2json(NV_KEY_VPNC_STATUS));
    json_object_object_add(carry, "name", nv2json(NV_KEY_VPNC_NAME));
    json_object_object_add(carry, "id", nv2json(NV_KEY_VPNC_ID));

    json_object_object_add(object, "config", carry);

    return NV_SUCCESS;
}

int set_vpnc_conf(json_object *object)
{
    char enable[2];
    char name[65];
    char id[3];
    int need_switch = 0;
    json_object_object_foreach(object, key, val) {
        if (!strcmp(key, "enable")) {
            snprintf(enable, sizeof(enable), "%s", json_object_get_string(val));

            if (!nvram_match(NV_KEY_VPNC_ENABLE, enable))
                need_switch = 1;
        }
        else if (!strcmp(key, "name")) {
            snprintf(name, sizeof(name), "%s", json_object_get_string(val));

            if (!nvram_match(NV_KEY_VPNC_NAME, name))
                need_switch = 1;
        }
        else if (!strcmp(key, "id")) {
            snprintf(id, sizeof(id), "%s", json_object_get_string(val));

            if (!nvram_match(NV_KEY_VPNC_ID, id))
                need_switch = 1;
        }
        else {
            continue;
        }
    }

    nvram_set(NV_KEY_VPNC_ENABLE, json_object_get_string(val));
    nvram_commit();

    /* The start/stop switch */
    if (enabled) {
        /* restart */
    }
    return NV_SUCCESS;
}

int nv_setup_change_trigger(const char *keys[], unsigned int nkeys)
{
    return 0;
}

typedef struct nvram_set_hook_t {
    char key[100];
    void (*fn)(void *);
} nvram_set_hook_t;

int nvram_set_withhook(const char *key, const char *val, nvram_set_hook_t *hook)
{
    if (!key)
        return -1;
    nvram_set(key, val);
    if (hook && hook->fn) {
        hook->fn(NULL);
    }
    return 0;
}
