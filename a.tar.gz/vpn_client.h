#ifndef VPN_CLIENT_H_
#define VPN_CLIENT_H_

/* The nvram keys */
#define NV_KEY_VPNC_ENABLE "vpnc_enable"
#define NV_KEY_VPNC_STATUS "vpnc_status"
#define NV_KEY_VPNC_NAME "vpnc_name"
#define NV_KEY_VPNC_ID "vpnc_id"

/* key format */
#define NV_KEY_FMT_VPNC_ACCOUNT_ID "vpnc%d_id"
#define NV_KEY_FMT_VPNC_ACCOUNT_NAME "vpnc%d_name"
#define NV_KEY_FMT_VPNC_ACCOUNT_PROTO "vpnc%d_proto"
#define NV_KEY_FMT_VPNC_ACCOUNT_PEER "vpnc%d_peer"
#define NV_KEY_FMT_VPNC_ACCOUNT_USER "vpnc%d_username"
#define NV_KEY_FMT_VPNC_ACCOUNT_PASSWD "vpnc%d_password"
#define NV_KEY_FMT_VPNC_ACCOUNT_ENABLE "vpnc%d_enable"

#endif
