# 路由器配置交互接口
> 接口版本：V1.0.0（未发布）
***
### 版本历史
|  版本  |   作者   |         时间         |           描述            |
| :--: | :----: | :----------------: | :---------------------: |
| 0.1  | 陈鸂/李茂源 | 2016.8.26-2016.9.1 |         撰写文档初稿          |
| 0.2  |  李光华   |     2016.12.5      | 优化数据接口格式，增加设备发现、通信流程等说明 |
| 0.3  |  李光华   |      2017.5.4      |          完善文档           |

### 前言
* 该文档针对K3项目路由器配置交互接口进行重新设计，以满足后续路由器平台化要求
* 开发人员严格按照该文档定义开发，**新增接口必须经过评审**，评审通过后再进行开发

### 需求分析
1. 符合平台化要求，具备不同平台可移植性
2. 前端（APP、Web/H5页面）与服务端后台接口数据分离
3. 定义详细交互数据格式
4. 定义统一错误代码
5. 完整的数据合法性检查
6. 认证授权机制

### 接口定义
定义具体接口格式，并对各项做详细描述

##### 接口格式
* URL：http://{host}/token={xxx}/data
1. 协议目前仅支持HTTP，暂不考虑HTTPS
2. 协议统一使用POST方法，（GET方式传输的数据大小有限制）
3. host表示路由器IP地址或者域名
4. token=xxx表示一次连接的session ID，其中xxx是32位长的字符串，超时时间暂定5分钟（根据PRD定义超时机制调整）
5. data表示调用本文档的数据接口
6. 请求头部中的Content-Type字段为“application/json;charset=UTF-8”
7. 前端和后台将json格式的数据发送出去之前，**必须对数据进行url编码，转换成json格式的字符串，对端接受到数据后，再进行url解码**

##### 接口范例
请求：
`
POST http://host/token=xxx/data HTTP/1.1
{
    "method" : "get",
    "module" :
    {
        "module1" : {"section1_1" : { "para1" : "para1_val" , "para2" : "param2_val"}, "section1_2" : null},
        "module2" : {"section2_1" : null}
    }
}
`
响应：
`
{
    "error_code" : 0,
    "module" :
    {
        "module1" :
        {
            "section1_1" : {"option1" : "value1", "option2" : "value2", "option3" : "value3"} ,
            "section1_2" :
            [
                {"index" : "1", "option1" : "value" , "option2" : "value" },
                {"index" : "1", "option1" : "value" , "option2" : "value" }
            ]
        },
        "module2" :
        {
            "section2_1" : {"option1" : "value1", "option2" : "value2", "option3" : "value3"}
        }
    }
}
`

##### 接口描述
1. method为必须项，表示此次调用行为，具体行为包含（get，set，add，del）
2. get表示获取数据，set表示修改数据，add表示添加数据（用于表格操作），del表示删除数据（用于表格操作）
3. module包含此次需要操作的模块
4. module1为模块名，类似于面向对象中“类”的概念
5. section1为数据块名，类似于面向对象中“类”的“实例”的概念
6. para1是每个数据块的请求参数，具体行为由具体的模块接口定义
7. option1为数据名，作为参数传递到底层模块中去，类似于每个“实例”的属性
8. error_code为必须项，表示此次接口调用返回的错误代码

##### get接口范例
请求：
`
POST http://host/token=xxx/data HTTP/1.1
{
    "method" : "get" ,
    "module" :
    {
        "network" : {"lan" : {"ip" : "1"}},
        "dhcpd" : {"dhcp_client" : null, "config" : null}
    }
}
`
响应：
`
{
    "error_code" : 0,
    "module" :
    {
        "network" :
        {
            "lan" : { "ip" : "192.168.2.0" }
        },
        "dhcpd" :
        {
            "dhcp_client" :
            [
                {"id" : "0" , "name" : "pc1" , "ip" : "192.168.2.100" , "mac" : "00:11:22:33:44:55" , "lease" : "3600"},
                {"id" : "1" , "name" : "pc2" , "ip" : "192.168.2.101" , "mac" : "00:11:22:33:44:66" , "lease" : "3600"}
            ],
            "config" : {"enable" : "1", "pool_start" : "100", "pool_end" : "199"}
        }
    }
}
`

##### set接口范例
请求：
`
POST http://host/token=xxx/data HTTP/1.1
{
    "method" : "set" ,
    "module" :
    {
        "network" :
        {
            "lan" : { "ip" : "192.168.168.1" , "netmask" : "255.255.255.0" }
        }
    }
}
`
响应：
`
{ "error_code" : 0 }
`

##### add接口范例
请求：
`
POST http://host/token=xxx/data HTTP/1.1
{
    "method" : "add" ,
    "module" :
    {
        "parent_ctrl" :
        {
            "entry" : {"id" : "1" , "mac" : "00:00:00:00:00:01" , "time_start" : "00:00" , "time_end" : "01:00"}
        }
    }
}
`
响应：
`
{ "error_code" : 0 }
`

##### del接口范例
请求：
`
POST http://host/token=xxx/data HTTP/1.1
{
    "method" : "del" ,
    "module" :
    {
        "parent_ctrl" :
        {
            "entry" : {"id" : "1"}
        }
    }
}
`
响应：
`
{ "error_code" : 0 }
`

### 合法性校验

前端发送过来的数据需经过合法性校验，需要说明的是：

1. 后台都进行了合法性校验，一旦有错误时，通过错误码告知前端，由前端去做出相应的提示；
2. 前端可以视情况在发送请求之前要对数据进行合法性校验，建议先校验下再发送给后台。

### 出错处理

后端处理出错时，返回错误码给前端，前端根据错误码定义做出相应的处理。详细的错误码定义见**error_code.md**


### 认证授权
    1. 同一个IP登录成功或者首次快速向导配置管理员密码后，返回之前登录成功的token值，若不存在则生成新的token值（根据PRD定义超时机制调整）
    2. 定义最大token数为10（根据PRD定义同一时刻最大登录用户数）
    3. 错误token参数计入错误登录次数中
    4. token位32个字母与数据组合的字符串
    5. 未超时接口根据token值进行访问时间更新
    6. 根据token值进行超时判断，超时则返回对应错误码，参考error_code.md



# 具体接口定义

下面是各个模块的详细接口定义。

#### 设置管理员密码

请求：
`
POST http://host/ HTTP/1.1
{
    "method" : "set" ,
    "module" :
    {
        "security" :
        {
            "register" : { "password" : "xxxxxx" }
        }
    }
}
`
响应：
`
{
    "error_code" : 0,
    "module" :
    {
        "security" :
        {
            "register" :
            {
                "stok" : "58ac731d060be9558879549f515d688e",
                "guide" : "1"
            }
        }
    }
}

| 字段    | 描述                                     | API    |
| :---- | :------------------------------------- | :----- |
| stok  | 设置管理员密码成功后服务器分配的session token，为32个英文字符 | 1.0.0+ |
| guide | 是否需要走向导（1：是，0：否）                       | 1.0.0+ |

#### 修改管理员密码
请求：
`
POST http://host/ HTTP/1.1
{
    "method" : "set" ,
    "module" :
    {
        "security" :
        {
            "modify" : { "old_password" : "xxxxxx", "new_password" : "xxxxxx" }
        }
    }
}
`

| 字段           | 描述                     | API    |
| :----------- | :--------------------- | :----- |
| old_password | 原密码（用户输入经过base64编码后的值） | 1.0.0+ |
| new_password | 新密码（用户输入经过base64编码后的值） | 1.0.0+ |

响应：
`
{
    "error_code" : 0
}


#### 登录
请求：
`
POST http://host/ HTTP/1.1
{
    "method" : "set" ,
    "module" :
    {
        "security" :
        {
            "login" : { "password" : "xxxxxx" }
        }
    }
}
`
响应：
`
{
    "error_code" : 0,
    "module" :
    {
        "security" :
        {
            "login" :
            {
                "stok" : "58ac731d060be9558879549f515d688e",
                "guide" : "0"
            }
        }
    }
}

| 字段    | 描述                       | API    |
| :---- | :----------------------- | :----- |
| stok  | 认证成功后服务器分配的session token | 1.0.0+ |
| guide | 是否需要走向导（1：是，0：否）         | 1.0.0+ |

#### 注销登录
请求：
`
POST http://host/ HTTP/1.1
{
    "method" : "set" ,
    "module" :
    {
        "security" :
        {
            "logout" : { "stok" : "58ac731d060be9558879549f515d688e" }
        }
    }
}

| 字段   | 描述                       | API    |
| :--- | :----------------------- | :----- |
| stok | 退出登录时，用于认证的session token | 1.0.0+ |

`
响应：
`
{
    "error_code" : 0
}


### 路由器与App的通信（TODO）
    App通过设备发现协议（详见《SOHO设备发现协议》）来发现设备，并获取管理路由器配置的信息。当前通过设备发现协议能知道的信息如下：
`
{
    "ip":"192.168.2.1",
    "domain":"p.to",
    "mac":"11-22-33-44-55-66",
    "type":"router",
    "model":"K2",
    "api_ver":"1.0.0",
    "sw_ver":"22.4.2.15",
    "hw_ver":"A2",
    "alias":"牛逼的K2",
    "state":"normal",
    "is_factory":"1"
}
`
|     字段     | 描述                      |
| :--------: | ----------------------- |
|     ip     | 设备的IP地址                 |
|   domain   | 设备的域名                   |
| is_factory | 设备是否处于出厂状态              |
|    mac     | 设备的MAC地址                |
|    type    | 设备类型（router、repeater）   |
|   model    | 设备型号                    |
|  api_ver   | 设备支持的本文档的API版本          |
|   sw_ver   | 设备的软件版本                 |
|   hw_ver   | 设备的硬件版本                 |
|   state    | 设备状态（运行中，已离线、重启/升级中...） |

* APP通过设备发现协议获取到设备信息后，通过**api_ver**字段来获取路由器支持的API版本，然后根据API版本来配置路由器
* 此API版本对应本文档的“接口版本”

### 产品特性
APP端需要支持很多产品（路由器、扩展器...），不同产品之间有硬件上、软件功能上的差异，APP需要得知这些信息
APP可以发送get请求去查询：
请求：
`
POST http://host/token=xxx/data HTTP/1.1
{
    "method" : "get" ,
    "module" :
    {
        "dev_feature" : {"data_collect" : null, "system_info" : null, "time_zone" : null, "app" : null, "wifi_2g" : null, "wifi_5g" : null, "network_set" : null, "time" : null}
    }
}
`
响应：
`
{
    "error_code" : 0,
    "module" :
    {
        "dev_feature" :
        {
            "data_collect":
            {
              "installed" : ["dev_first_config", "dev_login"]
            },
            "system_info":
            {
              "language" : ["zh-cn", "en-us", "de-de"...],
              "app_URL" : "http://app.phiwifi.phicomm.com/Service/App/downloadpage/chanel/1H5WK2Pro",
              "sw_URL" : "http://www.phicomm.com/cn/support.php/Soho/software_support/t/sm.html"
            },
            "time_zone":
            {
              "area" : ["EU", "SA", "NA"...]
            },
            "app" :
            {
                "installed" : ["DMZ", "QoS", "UPnP", "usb", "dhcp-server"...]
            },
            "wifi_2g" :
            {
                "channel" : [0,1,2,3,4,5,6,7,8,9,10,11,12,13]
            },
            "wifi_5g" :
            {
                "channel" : [0,36,40,44,48,149,153,157,161,165]
            },
            "network_set" :
            {
                "wan_type" : ["dhcp", "static", "pptp", "l2tp"]
            },
            "time" :
            {
                "reboot" : "120",
                "reset" : "120",
                "restore" : "120",
                "online_upgrade" : "130",
                "manual_upgrade" : "120",
                "detect_delay" : "120"
            }
        }
    }
}
`
device中的字段含义如下：
|            字段            |       字段       | 描述             |   API   |
| :----------------------: | :------------: | -------------- | :-----: |
| dev_feature.data_collect |   installed    | 大数据收集功能支持收集的选项 | 1.0.0+  |
| dev_feature.system_info  |    language    | 支持的语言          | 1.0.0+  |
| dev_feature.system_info  |    app_URL     | 下载APP的链接       | 1.0.0+  |
| dev_feature.system_info  |     sw_URL     | 下载固件的链接        | 1.0..0+ |
|  dev_feature.time_zone   |      area      | 时区设置支持的地区      | 1.0.0+  |
|     dev_feature.app      |   installed    | 已安装的APP        | 1.0.0+  |
|   dev_feature.wifi_2g    |    channel     | 支持的信道列表        | 1.0.0+  |
|   dev_feature.wifi_5g    |    channel     | 支持的信道列表        | 1.0.0+  |
|     dev_feature.time     |     reboot     | 重启所需时间（秒）      | 1.0.0+  |
|     dev_feature.time     |     reset      | 恢复出厂时间（秒）      | 1.0.0+  |
|     dev_feature.time     |    restore     | 载入备份时间（秒）      | 1.0.0+  |
|     dev_feature.time     | online_upgrade | 在线升级时间（秒）      | 1.0.0+  |
|     dev_feature.time     | manual_upgrade | 手动升级时间（秒）      | 1.0.0+  |
|     dev_feature.time     |  detect_delay  | 以上操作等待探测时间（秒）  | 1.0.0+  |
| dev_feature.network_set  |    wan_type    | 支持的上网方式        | 1.0.0+  |
| dev_feature.data_collect |   installed    | 大数据收集的内容       | 1.0.0+  |

**dev_feature.app.installed**可能的值如下：

| 值                 | 描述                        |
| ----------------- | ------------------------- |
| system-status     | 系统状态                      |
| network-set       | 上网设置                      |
| guest-wifi        | 访客网络                      |
| parent-ctrl       | 家长控制                      |
| backup-reset      | 备份恢复                      |
| signal-power      | 健康节能                      |
| wifi-extend       | 无线扩展（WISP方案）              |
| wds               | 无线扩展（WDS方案）               |
| screen            | 屏幕设置                      |
| usb               | 存储管理（包含ftp、samba等USB相关功能） |
| QoS               | QoS                       |
| auto-upgrade      | 自动升级                      |
| diagnose          | 一键体检                      |
| safe-set          | 安全设置                      |
| manual-upgrade    | 手动升级                      |
| remote-manage     | 远程管理                      |
| lan-set           | LAN设置                     |
| dhcp-server       | DHCP服务器                   |
| ddns              | DDNS                      |
| port-forward      | 端口转发                      |
| DMZ               | DMZ主机                     |
| UPnP              | UPnP                      |
| time-zone         | 时区设置                      |
| vpn-server        | VPN服务器                    |
| vpn-client        | VPN客户端                    |
| repeater          | 重置无线扩展（扩展器上的功能）           |
| repeater-wifi-set | 无线设置（扩展器上的功能）             |
| light             | 指示灯开关                     |

**dev_feateure.system_info.language** 可能的取值：

| 值     | 描述   |
| ----- | ---- |
| zh-cn | 中文简体 |
| eu-us | 英文   |
| de-de | 德文   |

**dev_feateure.time_zone.area** 可能的取值：

| 值    | 描述   | 具体时区列表                                   |
| ---- | ---- | ---------------------------------------- |
| NA   | 北美   | GMT-10:00 GMT-09:00 GMT-08:00 GMT-07:00 GMT-06:00 GMT-05:00 GMT-04:30 GMT-04:00 GMT-03:30 GMT-03:00 GMT-02:00 GMT-01:00 |
| AS   | 亚洲   | GMT+03:00 GMT+03:00 GMT+04:00 GMT+04:30 GMT+05:00 GMT+05:30 GMT+05:45 GMT+06:00 GMT+06:30 GMT+07:00 GMT+08:00 GMT+09:00 GMT+09:30 GMT+10:00 GMT+11:00 |
| OA   | 大洋洲  | GMT+09:00 GMT+09:30 GMT+10:00 GMT+11:00 GMT+12:00 GMT+13:00 GMT-12:00  GMT-11:00 |
| EU   | 欧洲   | GMT GMT+01:00 GMT+02:00 GMT+03:00        |
| SA   | 南美   | GMT-05:00 GMT-04:30 GMT-04:00 GMT-03:30 GMT-03:00 |
| AF   | 非洲   | GMT GMT+01:00 GMT+02:00 GMT+03:00 GMT+03:00 GMT+04:00 |

**dev_feature.network_set.wan_type** 可能的取值

| 值      | 描述          |
| ------ | ----------- |
| static | 静态上网方式      |
| dhcp   | DHCP上网方式    |
| pppoe  | PPPOE拨号上网方式 |
| pp2p   | PPTP上网方式    |
| l2tp   | L2TP上网方式    |

**dev_feature.data_collect.installed**  可能的取值

| 值                | 描述           |
| ---------------- | ------------ |
| dev_first_config | 首次配置所采用的设备类型 |
| dev_login        | 登录所用的设备类型    |
|                  |              |

### 兼容旧APP机制

* 方案1：固件端同时支持两套接口

* 方案2：固件只保留新的接口，APP提示升级

  当前的做法是，固件端同时支持两套接口，路由器中的功能模块都实现新接口，然后在老接口和新接口之间增加一个适配层。

### APP <--> cloud <--> router通信流程
* cloud充当一个中转数据包的角色，使用长连接的方式将APP的**POST**请求从cloud转发给路由器
* APP <--> cloud、cloud <--> router之间通信的数据，进行加密处理，具体的通信流程：
1. APP使用POST方式将数据包发送出去，数据包发送出去之前进行AES128加密
2. 路由器端这边有个“长连接模块”收到cloud发过来的数据包后，解析出数据包中的payload，对其进行AES128解密
3. “长连接模块”将解密后的数据，转发到路由器内部的Web Server交由其处理
4. 路由器内部Web Server的相应交由“长连接模块”，“长连接模块”对相应的数据进行AES128加密，通过云转发给APP
5. APP收到云转发过来的包，进行AES128解密处理

## 具体模块接口设计
以下为具体操作路由器配置和状态接口定义，由UI同事逐个添加，并添加APP同事多方评审
### 向导

#### 获取向导信息

request:
`
{
    "method" : "get" ,
    "module" :
    {
        "welcome" : {"config" : null}
    }
}
`
response:
`
{
    "error_code" : 0,
    "module" :
    {
        "welcome" :
        {
            "config" :
            {
                "guide" : "1",
                "language" : "zh-cn",
                "agreement" : "1"
            }
        }
    }
}
`

| 字段        | 描述                                       | API    |
| :-------- | :--------------------------------------- | :----- |
| guide     | 是否需要走向导（1：需要，0：不需要）                      | 1.0.0+ |
| language  | GUI语言（auto:自动，zh-cn:中文，en-us：英文，ge-ge: 德文） | 1.0.0+ |
| agreement | 是否已经同意用户协议（1：同意，0：不同意）                   | 1.0.0+ |

### 终端管理
#### 获取设备列表
request:
`
{
    "method" : "get" ,
    "module" :
    {
        "device_manage" : {"client_list" : null}
    }
}
`
response:
`
{
    "error_code" : 0,
    "module" :
    {
        "device_manage" :
        {
            "client_list" :[
            {
                "name" : "iPhone",
                "ip" = "192.168.2.100",
                "mac" = "00:CD:FE:DF:D7:48",
                "internet_enable" = "1",
                "upload_speed" = "123",
                "download_speed" = "456",
                "upload_limit" = "51200",
                "download_limit" = "1024000",
                "online_status" = "1",
                "online_time" = "3600",
                "device_type" = "1"
            },
            {
                "name" : "Huawei",
                "ip" = "192.168.2.101",
                "mac" = "48:AD:08:DF:D7:48",
                "internet_enable" = "1",
                "upload_speed" = "123",
                "download_speed" = "456",
                "upload_limit" = "0",
                "download_limit" = "0",
                "online_status" = "1",
                "online_time" = "3600",
                "device_type" = "1"
            }
            ]
        }
    }
}
`

#### 保存设备配置
request:
`
{
    "method" : "get" ,
    "module" :
    {
        "device_manage" :
        {
            "client_list" :
            {
                "name" : "iPhone",
                "ip" = "192.168.2.100",
                "mac" = "00:CD:FE:DF:D7:48",
                "internet_enable" = "1",
                "upload_limit" = "0",
                "download_limit" = "4096"
            }
        }
    }
}
`
response:
`
{
    "error_code" : 0
}
`

| 字段              | 描述                          | API    |
| :-------------- | :-------------------------- | :----- |
| name            | 终端名称                        | 1.0.0+ |
| ip              | IP地址                        | 1.0.0+ |
| mac             | MAC地址                       | 1.0.0+ |
| internet_enable | 允许上网（1：允许，0：不允许）            | 1.0.0+ |
| upload_speed    | 上行速率（单位为b/s）                | 1.0.0+ |
| download_speed  | 下行速率（单位为b/s）                | 1.0.0+ |
| upload_limit    | 上行限速（单位为Kb/s）               | 1.0.0+ |
| download_limit  | 上行限速（单位为Kbs）                | 1.0.0+ |
| online_status   | 在线状态（1：在线，0：离线）             | 1.0.0+ |
| online_time     | 在线时长（单位为秒）                  | 1.0.0+ |
| device_type     | 设备类型（0：有线，1：2.4G，2：5G，3：访客） | 1.0.0+ |

### 设备信息
#### 获取设备信息
request:
`
{
    "method" : "get" ,
    "module" :
    {
        "divice" : {"info" : null}
    }
}
`
response:
`
{
    "error_code" : 0,
    "module" :
    {
        "divice" :
        {
            "info" :
            {
                "uptime" : "3600",
                "sw_ver" : "21.4.17.157",
                "hw_ver" : "A1",
                "model" : "K3",
                "domain" : "p.to",
                "mac" : "00:11:22:33:44:55",
                "hw_id" : "297f3079eff5d0c277bd942e9f138b30",
                "product_id" : "671acc6fd3121424524ef8de8706b567"
            }
        }
    }
}
`
| 字段         | 描述      | API    |
| :--------- | :------ | :----- |
| uptime     | 系统启动时间  | 1.0.0+ |
| sw_ver     | 软件版本    | 1.0.0+ |
| hw_ver     | 硬件版本    | 1.0.0+ |
| model      | 产品型号    | 1.0.0+ |
| domain     | 设备域名    | 1.0.0+ |
| mac        | 设备MAC地址 | 1.0.0+ |
| hw_id      | 硬件ID    | 1.0.0+ |
| product_id | 产品ID    | 1.0.0+ |

### 无线设置

#### 获取无线状态

request:
`
{
	"method" : "get" ,
	"module" :
	{
		"wireless" : {"smart_connect" : null, "wifi_2g_config" : null, "wifi_5g_config" : null}
	}
}
`
response:
`
{
	"error_code" : 0,
	"module" :
	{
		"wireless" :
		{
			"smart_connect" :
			{
				"enable" : "1"
			},
			"wifi_2g_config" :
			{
				"enable" : "1",
				"ssid" : "@PHICOMM_XX",
				"password" : "12345678",
				"hidden" : "1",
				"mode" : "0",
				"channel" : "0",
				"band_width" : "0",
				"ap_isolate" : "1",
				"mu_mimo" : "1",
				"beamforming" : "1",
				"safety":"1"
			},
			"wifi_5g_config" :
			{
				"enable" : "1",
				"ssid" : "@PHICOMM_XX_5G",
				"password" : "12345678",
				"hidden" : "1",
				"mode" : "0",
				"channel" : "0",
				"band_width" : "0",
				"ap_isolate" : "1",
				"mu_mimo" : "1",
				"beamforming" : "1",
				"safety":"1"
			},
			"wifi_2g_status" :
			{
				enable = "1",
				ssid = "@PHICOMM_XX",
				safe_mode = "1",
				mode = "0",
				channel = "1",
				mac = "00-11-22-33-44-55"
			},
			"wifi_5g_status" :
			{
				enable = "1",
				ssid = "@PHICOMM_XX_5G",
				safe_mode = "1",
				mode = "0",
				channel = "1",
				mac = "00-11-22-33-44-55"
			}
		}
	}
}
`

| 字段       | 字段             | 字段          | 描述                                       | API    |
| :------- | :------------- | :---------- | :--------------------------------------- | :----- |
| wireless | smart_connect  | enable      | 双频合一（1：启用，0：禁用）                          | 1.0.0+ |
| wireless | wifi_2g_config | enable      | 2.4G无线开关（1：启用，0：禁用）                      | 1.0.0+ |
| wireless | wifi_2g_config | ssid        | 2.4G无线名称                                 | 1.0.0+ |
| wireless | wifi_2g_config | password    | 2.4G无线密码（空字符串表示不加密）                      | 1.0.0+ |
| wireless | wifi_2g_config | hidden      | 2.4G无线隐藏（1：启用，0：禁用）                      | 1.0.0+ |
| wireless | wifi_2g_config | mode        | 2.4G无线模式（0：11b/g/n，1：11b/g，2：11n）        | 1.0.0+ |
| wireless | wifi_2g_config | channel     | 2.4G无线信道（0：自动，n：n）                       | 1.0.0+ |
| wireless | wifi_2g_config | band_width  | 2.4G无线带宽（0：20MHz，1：20/40MHz，2：40MHz）     | 1.0.0+ |
| wireless | wifi_2g_config | ap_isolate  | 2.4G无线AP隔离（1：启用，0：禁用）                    | 1.0.0+ |
| wireless | wifi_2g_config | mu_mimo     | MU-MIMO（1：启用，0：禁用）                       |        |
| wireless | wifi_2g_config | beamforming | Beamforming（1：启用，0：禁用）                   |        |
| wireless | wifi_2g_config | safety      | 2.4G无线密码强度（1：弱，2：中，3：强）                  | 1.0.0+ |
| wireless | wifi_5g_config | enable      | 5G无线开关（1：启用，0：禁用）                        | 1.0.0+ |
| wireless | wifi_5g_config | ssid        | 5G无线名称                                   | 1.0.0+ |
| wireless | wifi_5g_config | password    | 5G无线密码（空字符串表示不加密）                        | 1.0.0+ |
| wireless | wifi_5g_config | hidden      | 5G无线隐藏（1：启用，0：禁用）                        | 1.0.0+ |
| wireless | wifi_5g_config | mode        | 5G无线模式（0：11a/n/ac，1：11n/ac）              | 1.0.0+ |
| wireless | wifi_5g_config | channel     | 5G无线信道（0：自动，n：n）                         | 1.0.0+ |
| wireless | wifi_5g_config | band_width  | 5G无线带宽（0：20MHz，1：40MHz，2：80MHz，3：20/40/80MHz） | 1.0.0+ |
| wireless | wifi_5g_config | ap_isolate  | 5G无线AP隔离（1：启用，0：禁用）                      | 1.0.0+ |
| wireless | wifi_5g_config | mu_mimo     | MU-MIMO（1：启用，0：禁用）                       | 1.0.0+ |
| wireless | wifi_5g_config | beamforming | Beamforming（1：启用，0：禁用）                   | 1.0.0+ |
| wireless | wifi_5g_config | safety      | 5G无线密码强度（1：弱，2：中，3：强）                    | 1.0.0+ |
| wireless | wifi_2g_status | enable      | 2.4G无线开关（1：启用，0：禁用）                      | 1.0.0+ |
| wireless | wifi_2g_status | ssid        | 2.4G无线名称                                 | 1.0.0+ |
| wireless | wifi_2g_status | safe_mode   | 2.4G加密方式（1：WPA-PSK/WPA2-PSK，0：OPEN）      | 1.0.0+ |
| wireless | wifi_2g_status | mode        | 2.4G无线模式（0：11b/g/n，1：11b/g，2：11n）        | 1.0.0+ |
| wireless | wifi_2g_status | channel     | 2.4G无线信道                                 | 1.0.0+ |
| wireless | wifi_2g_status | mac         | MAC地址                                    | MAC    |
| wireless | wifi_5g_status | enable      | 5G无线开关（1：启用，0：禁用）                        | 1.0.0+ |
| wireless | wifi_5g_status | ssid        | 5G无线名称                                   | 1.0.0+ |
| wireless | wifi_5g_status | safe_mode   | 5G加密方式（1：WPA-PSK/WPA2-PSK，0：OPEN）        | 1.0.0+ |
| wireless | wifi_5g_status | mode        | 5G无线模式（0：11a/n/ac，1：11n/ac）              | 1.0.0+ |
| wireless | wifi_5g_status | channel     | 5G无线信道                                   | 1.0.0+ |
| wireless | wifi_5g_status | mac         | MAC地址                                    | 1.0.0+ |

### 访客网络

#### 获取访客网络配置

request:
`
{
    "method" : "get" ,
    "module" :
    {
        "wireless" : {"guest_wifi" : null}
    }
}
`
response:
`
{
    "error_code" : 0,
    "module" :
    {
        "wireless" :
        {
            "guest_wifi" :
            {
                "enable" : "1",
                "ssid" : "@PHICOMM_XX",
                "password" : "12345678"
            }
        }
    }
}
`

| 字段       | 描述                  | API    |
| :------- | :------------------ | :----- |
| enable   | 2.4G无线开关（1：启用，0：禁用） | 1.0.0+ |
| ssid     | 2.4G无线名称            | 1.0.0+ |
| password | 2.4G无线密码（空字符串表示不加密） | 1.0.0+ |

### 一键体检

#### 获取管理员密码强度信息

request:
`
{
    "method" : "get" ,
    "module" :
    {
        "security" : {"status" : null}
    }
}
`
response:
`
{
    "error_code" : 0,
    "module" :
    {
        "security" :
        {
            "status" :
            {
                "safety" : "1"
            }
        }
    }
}
`

| 字段     | 描述                   | API    |
| :----- | :------------------- | :----- |
| safety | 管理员密码强度（1：弱，2：中，3：强） | 1.0.0+ |

#### 固件版本检测

request:
`
{
    "method" : "get" ,
    "module" :
    {
        "system" : {"upgrade_info" : {"action" : "start"}}
    }
}
`
| 字段     | 描述                                       | API    |
| :----- | :--------------------------------------- | :----- |
| action | 检查新版本固件，最开始"action"值为"start"，出发后台开始新固件检查，后续轮训检查结果（action=get） | 1.0.0+ |

response:
`
{
    "error_code" : 0,
    "module" :
    {
        "system" :
        {
            "upgrade_info" :
            {
                "running_status" : "1",
                "status_code" : "1",
                "sw_ver" : "1",
                "new_ver" : "2",
                "log" : "1"
            }
        }
    }
}
`

| 字段             | 描述                                       | API    |
| :------------- | :--------------------------------------- | :----- |
| running_status | 后台检测程序运行状态（0：未开始，1：检查中，2：检查完成）           | 1.0.0+ |
| status_code    | 检测结果，当running_status=2时有效（0：没有新版本，1：有新版本，8801：服务器繁忙，8802：服务器错误，8803：参数非法，8804：固件已是最新） | 1.0.0+ |
| sw_ver         | 当前固件版本号                                  | 1.0.0+ |
| new_ver        | 新固件版本号                                   | 1.0.0+ |
| release_log    | 升级日志                                     | 1.0.0+ |
| release_time   | 发布时间                                     | 1.0.0+ |

### 存储管理

#### 获取存储管理配置

request:
`
{
    "method" : "get" ,
    "module" :
    {
        "usb" : {"samba" : null, media_server : null, device : null}
    }
}
`
response:
`
{
    "error_code" : 0,
    "module" :
    {
        "usb" :
        {
            "samba" :
            {
                "enable" : "1",
                "encrypt" : "1",
                "username" : "admin",
                "password" : "admin"
            },
            "media_server" :
            {
                "enable" : "1"
            },
            "usb3" :
            {
                "enable" : "1"
            },
            "device" :
            {
                "connecte" : "1",
                "device_list" :
                [
                    {"name":"Kinston USB device", "total_capacity":"15308177408", "free_capacity":"15270084608", "dev":"sda0"},
                    {"name":"PNY USB device", "total_capacity":"30234177408", "free_capacity":"12352345408", "dev:"sda1"}
                ]
            }
        }
    }
}
`

| 字段           | 字段                         | 描述                  | API    |
| :----------- | :------------------------- | :------------------ | :----- |
| samba        | enable                     | 存储共享开关（1：启用，0：禁用）   | 1.0.0+ |
| samba        | encrypt                    | 存储加密（1：启用，0：禁用）     | 1.0.0+ |
| samba        | username                   | 用户名                 | 1.0.0+ |
| samba        | password                   | 密码                  | 1.0.0+ |
| media_server | enable                     | 媒体服务器开关（1：启用，0：禁用）  | 1.0.0+ |
| usb3         | enable                     | USB3.0开关（1：启用，0：禁用） | 1.0.0+ |
| device       | connecte                   | 存储状态（1：已连接，0：未连接）   | 1.0.0+ |
| device       | device_list                | USB设备列表             | 1.0.0+ |
| device       | device_list.name           | 厂商                  | 1.0.0+ |
| device       | device_list.total_capacity | 总容量（单位KB）           | 1.0.0+ |
| device       | device_list.free_capacity  | 剩余容量（单位KB）          | 1.0.0+ |
| device       | device_list.dev            | 设备名                 | 1.0.0+ |

### 自动升级

#### 获取自动升级配置

request:
`
{
    "method" : "get" ,
    "module" :
    {
        "system" : {"upgrade" : null}
    }
}
`
response:
`
{
    "error_code" : 0,
    "module" :
    {
        "system" :
        {
            "upgrade" :
            {
                "mode" : "1",
                "start_hour" : "23",
                "start_minute" : "30"
            }
        }
    }
}
`

| 字段      | 字段           | 描述                     | API    |
| :------ | :----------- | :--------------------- | :----- |
| upgrade | mode         | 升级方式（0：在线升级，1：自定义升级时间） | 1.0.0+ |
| upgrade | start_hour   | 升级时间：小时                | 1.0.0+ |
| upgrade | start_minute | 升级时间：分钟                | 1.0.0+ |

### 上网设置
#### 获取上网方式信息
request:
`
{
    "method" : "get" ,
    "module" :
    {
        "network" : {"wan" : null, "static" : null, "dhcp" : null, "pppoe" : null, "pptp" : null, "l2tp" : null, "wan_status" : null, "wan_detection" : {"action" : "start"}}
    }
}
`
| 字段     | 描述                                       | API    |
| :----- | :--------------------------------------- | :----- |
| action | 检测上网方式，最开始"action"="start"，触发后台开始上网方式检测，后续轮训检查结果（action=get） | 1.0.0+ |

response:
`
{
    "error_code" : 0,
    "module" :
    {
        "network" :
        {
            "wan" :
            {
                "protocol" : "static",
                "clone_mode" : "1",
                "mac" : "00:CD:FE:DF:D7:48",
                "source_mac" : "08:57:00:de:69:55"
            },
            "static" :
            {
                "ip" : "172.17.48.129",
                "netmaask" : "255.255.255.0",
                "gateway" : "172.17.48.1",
                "mtu" : "1500",
                "dns_mode" : "",
                "dns_pri" : "172.17.10.6",
                "dns_sec" : "172.17.10.7"
            },
            "dhcp" :
            {
                "mtu" : "1500",
                "dns_mode" : "1",
                "dns_pri" : "172.17.100.6",
                "dns_sec" : "172.17.100.7"
            },
            "pppoe" :
            {
                "username" : "feixun",
                "password" : "feixun",
                "dial_mode" : "0",
                "server" : "",
                "mtu" : "1480",
                "dns_mode" : "1",
                "dns_pri" : "172.17.10.6",
                "dns_sec" : "172.17.10.7"
            },
            "pptp" :
            {
                "server" : "172.17.48.10",
                "username" : "feixun",
                "password" : "feixun",
                "ip_protocol" : "0",
                "mtu" : "1480",
                "dns_mode" : "1",
                "ip" : "172.17.48.129",
                "netmask" : "255.255.255.0",
                "gateway" : "172.17.48.1",
                "dns_pri" : "172.17.100.12",
                "dns_sec" : "172.17.100.16"
            },
            "l2tp" :
            {
                "server" : "172.17.48.10",
                "username" : "feixun",
                "password" : "feixun",
                "ip_protocol" : "0",
                "mtu" : "1480",
                "dns_mode" : "1",
                "ip" : "172.17.48.129",
                "netmask" : "255.255.255.0",
                "gateway" : "172.17.48.1",
                "dns_pri" : "172.17.100.12",
                "dns_sec" : "172.17.100.16"
            },
            "wan_status" :
            {
                "protocol" : "dhcp",
                "ip" : "172.17.48.129",
                "netmask" : "255.255.255.0",
                "gateway" : "172.17.48.1",
                "dns_pri" : "192.168.100.3",
                "dns_sec" : "192.168.100.4",
                "internet_status" : "1",
                "upload_speed" : "1234",
                "download_speed" : "5678",
                "status_code" : "0"
            }
        }
    }
}
`
| 字段      | 字段            | 字段              | 描述                                       | API    |
| :------ | :------------ | :-------------- | :--------------------------------------- | :----- |
| network | wan           | protocol        | 当前上网方式（static：静态地址 dhcp：自动获取 pppoe：宽带拨号 pptp：pptp l2tp：l2tp） | 1.0.0+ |
| network | wan           | clone_mode      | mac克隆模式（0：禁止克隆  1：克隆mac）                 | 1.0.0+ |
| network | wan           | mac             | 克隆的mac                                   | 1.0.0+ |
| network | wan           | source_mac      | 路由器源mac                                  | 1.0.0+ |
| network | static        | ip              | IP地址                                     | 1.0.0+ |
| network | static        | netmask         | 子网掩码                                     | 1.0.0+ |
| network | static        | gateway         | 默认网关                                     | 1.0.0+ |
| network | static        | mtu             | mtu值                                     | 1.0.0+ |
| network | static        | dns_mode        | dns服务模式（静态IP时，为“1”，表示自定义DNS）             | 1.0.0+ |
| network | static        | dns_pri         | 首选dns                                    | 1.0.0+ |
| network | static        | dns_sec         | 备用dns                                    | 1.0.0+ |
| network | dhcp          | mtu             | mtu值                                     | 1.0.0+ |
| network | dhcp          | dns_mode        | dns服务模式（0：自动获取 1：自定义dns）                 | 1.0.0+ |
| network | dhcp          | dns_pri         | 首选dns                                    | 1.0.0+ |
| network | dhcp          | dns_sec         | 备用dns                                    | 1.0.0+ |
| network | pppoe         | username        | 宽带账号                                     | 1.0.0+ |
| network | pppoe         | password        | 宽带密码                                     | 1.0.0+ |
| network | pppoe         | dial_mode       | 拨号模式（0：正常拨号  1：特殊拨号1  2：特殊拨号2  3：特殊拨号3  4：特殊拨号4） | 1.0.0+ |
| network | pppoe         | server          | 服务名称                                     | 1.0.0+ |
| network | pppoe         | mtu             | mtu值                                     | 1.0.0+ |
| network | pppoe         | dns_mode        | dns服务模式（0：自动获取dns 1：自定义dns）              | 1.0.0+ |
| network | pppoe         | dns_pri         | 首选dns                                    | 1.0.0+ |
| network | pppoe         | dns_sec         | 备用dns                                    | 1.0.0+ |
| network | pptp          | server          | 服务IP                                     | 1.0.0+ |
| network | pptp          | username        | 用户名                                      | 1.0.0+ |
| network | pptp          | password        | 密码                                       | 1.0.0+ |
| network | pptp          | ip_protocol     | IP获取方式（0：动态，1：静态）                        | 1.0.0+ |
| network | pptp          | ip              | IP地址                                     | 1.0.0+ |
| network | pptp          | netmask         | 子网掩码                                     | 1.0.0+ |
| network | pptp          | gateway         | 默认网关                                     | 1.0.0+ |
| network | pptp          | dns_mode        | dns服务模式（0：自动获取dns，1：自定义dns）              | 1.0.0+ |
| network | pptp          | dns_pri         | 首选dns                                    | 1.0.0+ |
| network | pptp          | dns_sec         | 备用dns                                    | 1.0.0+ |
| network | l2tp          | mtu             | mtu值                                     | 1.0.0+ |
| network | l2tp          | server          | 服务IP                                     | 1.0.0+ |
| network | l2tp          | username        | 用户名                                      | 1.0.0+ |
| network | l2tp          | password        | 密码                                       | 1.0.0+ |
| network | l2tp          | ip_protocol     | IP获取方式（0：动态，1：静态）                        | 1.0.0+ |
| network | l2tp          | ip              | IP地址                                     | 1.0.0+ |
| network | l2tp          | netmask         | 子网掩码                                     | 1.0.0+ |
| network | l2tp          | gateway         | 默认网关                                     | 1.0.0+ |
| network | l2tp          | dns_mode        | dns服务模式（0：自动获取dns，1：自定义dns）              | 1.0.0+ |
| network | l2tp          | dns_pri         | 首选dns                                    | 1.0.0+ |
| network | l2tp          | dns_sec         | 备用dns                                    | 1.0.0+ |
| network | l2tp          | mtu             | mtu值                                     | 1.0.0+ |
| network | wan_status    | protocol        | 当前上网方式（static：静态地址 dhcp：自动获取 pppoe：宽带拨号） | 1.0.0+ |
| network | wan_status    | ip              | IP地址                                     | 1.0.0+ |
| network | wan_status    | netmask         | 子网掩码                                     | 1.0.0+ |
| network | wan_status    | gateway         | 默认网关                                     | 1.0.0+ |
| network | wan_status    | dns_pri         | 首选dns                                    | 1.0.0+ |
| network | wan_status    | dns_sec         | 备用dns                                    | 1.0.0+ |
| network | wan_status    | internet_status | 网络状态（1：可以上网 0：不能上网）                      | 1.0.0+ |
| network | wan_status    | upload_speed    | 上行速率（单位为B/s）                             | 1.0.0+ |
| network | wan_status    | download_speed  | 下行速率（单位为B/s）                             | 1.0.0+ |
| network | wan_status    | status_code     | 错误码                                      | 1.0.0+ |
| network | wan_detection | running_status  | 后台检测程序运行状态（0：未开始 1：检查中 2：检查完成）           | 1.0.0+ |
| network | wan_detection | status_code     | 检测结果，当running_status=2时有效（0：WAN口连接，检测成功 1：WAN口未连接，检测失败） | 1.0.0+ |
| network | wan_detection | protocol        | 检测出的上网方式（static：静态地址 dhcp：自动获取 pppoe：宽带拨号） | 1.0.0+ |

 **network.wan_status.status_code**值描述：
| 值    | 描述                           | API    |
| :--- | :--------------------------- | :----- |
| 0    | WAN口状态正常                     | 1.0.0+ |
| 1    | WAN口未连接                      | 1.0.0+ |
| 2    | WAN口无IP                      | 1.0.0+ |
| 3    | 网关无响应                        | 1.0.0+ |
| 4    | WAN口无DNS地址                   | 1.0.0+ |
| 5    | WAN口DNS无响应                   | 1.0.0+ |
| 6    | WAN口自定义DNS错误                 | 1.0.0+ |
| 7    | WAN口无DHCP服务器（针对上网方式为DHCP的情况） | 1.0.0+ |
| 8    | WAN口获取地址中（针对上网方式为DHCP的情况）    | 1.0.0+ |
| 9    | 正在PPPOE拨号（针对上网方式为PPPOE的情况）   | 1.0.0+ |
| 10   | PPPOE服务器无应答（针对上网方式为PPPOE的情况） | 1.0.0+ |
| 646  | PPPOE拨号错误                    | 1.0.0+ |
| 647  | PPPOE拨号错误                    | 1.0.0+ |
| 648  | PPPOE拨号错误                    | 1.0.0+ |
| 649  | PPPOE拨号错误                    | 1.0.0+ |
| 678  | PPPOE服务器错误                   | 1.0.0+ |
| 691  | PPPOE账号错误                    | 1.0.0+ |
| 709  | PPPOE密码错误                    | 1.0.0+ |

### 安全设置

#### 获取安全设置信息

request:
`
{
	"method" : "get" ,
	"module" :
	{
		"safe_set" : {"config" : null}
	}
}
`
response:
`
{
	"error_code" : 0,
	"module" :
	{
		"safe_set" :
		{
			"config" :
			{
				"enable" : "1",
				"dos" : "1",
				"icmp_flood" : "1",
				"icmp_threshold" : "500",
				"udp_flood" : "1",
				"udp_threshold" : "500",
				"tcp_flood" : "1",
				"tcp_threshold" : "500",
				"ping_disable" : "1"
			}
		}
	}
}
`

| 字段             | 描述                           | API    |
| :------------- | :--------------------------- | :----- |
| enable         | 防火墙（1：启用，0：禁用）               | 1.0.0+ |
| dos            | DoS攻击防范（1：启用，0：禁用）           | 1.0.0+ |
| icmp_flood     | ICMP-FLOOD攻击过滤（1：启用，0：禁用）    | 1.0.0+ |
| icmp_threshold | ICMP-FLOOD数据包阈值              | 1.0.0+ |
| udp_flood      | UDP-FLOOD攻击过滤（1：启用，0：禁用）     | 1.0.0+ |
| udp_threshold  | UDP-FLOOD数据包阈值               | 1.0.0+ |
| tcp_flood      | TCP-SYN-FLOOD攻击过滤（1：启用，0：禁用） | 1.0.0+ |
| tcp_threshold  | TCP-SYN-FLOOD数据包阈值           | 1.0.0+ |
| ping_disable   | 禁来自WAN口的Ping（1：启用，0：禁用）      | 1.0.0+ |

### 动态DNS

#### 获取动态DNS信息

request:
`
{
	"method" : "get" ,
	"module" :
	{
		"ddns" : {"config" : null}
	}
}
`
response:
`
{
	"error_code" : 0,
	"module" :
	{
		"ddns" :
		{
			"config" :
			{
				"enable" : "1",
				"provider" : "oray.com",
				"user" : "admin",
				"password" : "admin",
				"domain" : "www.oray.com"
			}
		}
	}
}
`

| 字段       | 描述               | API    |
| :------- | :--------------- | :----- |
| enable   | 动态DNS（1：启用，0：禁用） | 1.0.0+ |
| provider | 服务提供商            | 1.0.0+ |
| user     | 用户名              | 1.0.0+ |
| password | 密码               | 1.0.0+ |
| domain   | 主机名称             | 1.0.0+ |

### UPnP

#### 获取UPnP信息

request:
`
{
	"method" : "get" ,
	"module" :
	{
		"upnp" : {"config" : null, "upnp_list" : null}
	}
}
`
response:
`
{
	"error_code" : 0,
	"module" :
	{
		"upnp" :
		{
			"config" :
			{
				"enable" : "1"
			}
			"upnp_list" :
			{
			  {
				"descript" : "AAAAAA",
				"protocol" : "TCP",
				"external_port" : "100",
				"internal_port" : "200",
				"ip" : "192.168.2.10",
				"status" : "1"
			  },
			  {
				"descript" : "BBBBBB",
				"protocol" : "UDP",
				"external_port" : "300",
				"internal_port" : "400",
				"ip" : "192.168.2.20",
				"status" : "0"
			  }
			}
		}
	}
}
`

| 字段        | 字段            | 描述              | API    |
| :-------- | :------------ | :-------------- | ------ |
| config    | enable        | UPnP（1：启用，0：禁用） | 1.0.0+ |
| upnp_list | descript      | 服务描述            | 1.0.0+ |
| upnp_list | protocol      | 端口类型            | 1.0.0+ |
| upnp_list | external_port | 外部端口            | 1.0.0+ |
| upnp_list | internal_port | 内部端口            | 1.0.0+ |
| upnp_list | ip            | IP地址            | 1.0.0+ |
| upnp_list | status        | 状态              | 1.0.0+ |

### LAN设置

#### 获取LAN信息

request:
`
{
    "method" : "get" ,
    "module" :
    {
        "network" : {"lan" : null}
    }
}
`
response:
`
{
    "error_code" : 0,
    "module" :
    {
        "network" :
        {
            "lan" :
            {
                "ip" : "192.168.2.1",
                "netmask" : "255.255.255.0",
                "mac" : "00:AA:34:21:DD:65"
            }
        }
    }
}
`

| 字段      | 描述        | API    |
| :------ | :-------- | :----- |
| ip      | ip地址      | 1.0.0+ |
| netmask | 子网掩码      | 1.0.0+ |
| mac     | lan侧mac地址 | 1.0.0+ |

### DMZ主机

#### 获取DMZ主机信息

request:
`
{
    "method" : "get" ,
    "module" :
    {
        "firewall" : {"dmz" : null}
    }
}
`
response:
`
{
    "error_code" : 0,
    "module" :
    {
        "firewall" :
        {
            "dmz" :
            {
                "enable" : "1",
                "ip" : "192.168.2.110"
            }
        }
    }
}
`

| 字段     | 描述               | API    |
| :----- | :--------------- | :----- |
| enable | DMZ主机（1：启用，0：禁用） | 1.0.0+ |
| ip     | DMZ主机ip地址        | 1.0.0+ |

### 远程管理

#### 获取远程管理信息

request:
`
{
    "method" : "get" ,
    "module" :
    {
        "firewall" : {"remote_manager" : null}
    }
}
`
response:
`
{
    "error_code" : 0,
    "module" :
    {
        "firewall" :
        {
            "remote_manager" :
            {
                "enable" : "1",
                "port" : "8181",
                "ip" : "255.255.255.255"
            }
        }
    }
}
`

| 字段     | 描述                    | API    |
| :----- | :-------------------- | :----- |
| enable | 远程管理（1：启用，0：禁用）       | 1.0.0+ |
| port   | 远程管理允许的端口号（1~65535之间） | 1.0.0+ |
| ip     | 远程管理允许的IP             | 1.0.0+ |

### 屏幕显示

#### 获取屏幕显示信息

request:
`
{
	"method" : "get" ,
	"module" :
	{
		"screen_set" : {"config" : null}
	}
}
`
response:
`
{
	"error_code" : 0,
	"module" :
	{
		"screen_set" :
		{
			"config" :
			{
				"screen_time" : "0",
				"show_wireless_pwd" : "1",
				"show_guestwifi_pwd" : "1"
			}
		}
	}
}

| 字段          | 描述                                       | API    |
| :---------- | :--------------------------------------- | :----- |
| screen_time | 息屏时间（60：一分钟，300：五分钟，600：十分钟，1800：三十分钟，0：从不） | 1.0.0+ |
| show_wireless_pwd | 屏幕是否显示无线（2.4G、5G）密码（1：显示，0：不显示） | 1.0.0+ |
| show_guestwifi_pwd | 屏幕是否显示无线（访客网络）密码（1：显示，0：不显示） | 1.0.0+ |

### 健康节能

#### 获取健康节能信息

request:
`
{
    "method" : "get" ,
    "module" :
    {
        "signal_set" : {"config" : null}
    }
}
`
response:
`
{
    "error_code" : 0,
    "module" :
    {
        "signal_set" :
        {
            "config" :
            {
                "power" : "1"
            }
        }
    }
}

| 字段    | 描述                 | API    |
| :---- | :----------------- | :----- |
| power | 健康节能开关（1：关闭， 0：开启） | 1.0.0+ |

###DHCP服务
####获取DHCP服务信息
request：
`
POST http://host/token=xxx/data HTTP/1.1
{
    "method" : "get" ,
    "module" :
    {
        "dhcpd" : {"config" : null, "bind_list" : null}
    }
}
`
response：
`
{
    "error_code" : 0,
    "module" :
    {
        "dhcpd" :
        {
            "config" : {"enable" : "1", "pool_start" : "100", "pool_end" : "200", "network_address" : "192.168.2.0/24"}
        },
        "bind_list" :
        [
            {
                "id" : "xx" ,
                "name" : "pc1" ,
                "ip" : "192.168.2.100" ,
                "mac" : "22:33:44:55:66:00"
            },
            {
                "id" : "xx" ,
                "name" : "pc2" ,
                "ip" : "192.168.2.101" ,
                "mac" : "22:33:44:55:66:08"
            }
        ]
    }
}
`

| 字段              | 描述                  | API    |
| :-------------- | :------------------ | :----- |
| enable          | DHCP服务开关（1：开启 0：关闭） | 1.0.0+ |
| pool_start      | DHCP服务地址池起始地址       | 1.0.0+ |
| pool_end        | DHCP服务地址池结束地址       | 1.0.0+ |
| network_address | 网络地址                | 1.0.0+ |
| id              | 条目id                | 1.0.0+ |
| name            | 设备名称                | 1.0.0+ |
| ip              | IP地址                | 1.0.0+ |
| mac             | MAC地址               | 1.0.0+ |

### 端口转发

#### 获取端口转发信息

request:
`
{
	"method" : "get" ,
	"module" :
	{
		"port_forward" : {"config" : null, "forward_list" : null}
	}
}
`
response:
`
{
	"error_code" : 0,
	"module" :
	{
		"port_forward" :
		{
			"config" :
			{
				"enable" : "0"
			}
			"forward_list" :
			[
				{
					"id" : "test",
					"name" : "AAAAAA",
					"ip" : "192.168.2.100",
					"extern_port_start" : "1",
					"extern_port_end" : "1",
					"inner_port_start" : "10",
					"inner_port_end" : "10",
					"protocol" : "1"
				},
				{
					"id" : "2",
					"name" : "BBBBBB",
					"ip" : "192.168.2.200",
					"extern_port_start" : "1",
					"extern_port_end" : "1",
					"inner_port_start" : "10",
					"inner_port_end" : "10",
					"protocol" : "1"
				}
			]
		}
	}
}
`

| 字段           | 字段                | 描述                          | API    |
| :----------- | :---------------- | :-------------------------- | ------ |
| config       | enable            | 端口转发（1：启用，0：禁用）             | 1.0.0+ |
| forward_list | id                | 规则序号                        | 1.0.0+ |
| forward_list | name              | 规则名称                        | 1.0.0+ |
| forward_list | ip                | IP地址                        | 1.0.0+ |
| forward_list | extern_port_start | 外部端口起始端口号                   | 1.0.0+ |
| forward_list | extern_port_end   | 外部端口结束端口号                   | 1.0.0+ |
| forward_list | inner_port_start  | 内部端口起始端口号                   | 1.0.0+ |
| forward_list | inner_port_end    | 内部端口结束端口号                   | 1.0.0+ |
| forward_list | protocol          | 协议类型（1:TCP,2:UDP,3:TCP&UDP） | 1.0.0+ |

### 无线扩展

#### 获取无线扩展信息

request:
`
{

	"method" : "get" ,
	"module" :
	{
		"wisp" : {"config" : null, "ap_list" : null}
	}
}
`
response:
`
{
	"error_code" : 0,
	"module" :
	{
		"wisp" :
		{
			"config" :
			{
				"enable" : "1",
				"band" : "0",
				"bssid" : "00:CD:FE:DF:D7:48",
				"ssid" : "@PHICOMM_XX",
				"safe_mode" : "WPA2-PSK",
				"encryption" : "TKIP",
				"password" : "12345678",
				"protocol" : "dhcp",
				"ip" : "10.10.10.1",
				"gateway" : "10.10.10.100"
			}
			"ap_list" :[
			{
				"bssid" : "00:CD:FE:DF:D7:48",
				"ssid" : "@PHICOMM_11",
				"safe_mode" : "OPEN",
				"encryption" : "NONE",
				"signal" : "90",
				"band" : "0"
			},
			{
				"bssid" : "00:CD:FE:DF:D7:48",
				"ssid" : "@PHICOMM_22",
				"safe_mode" : "WPA2-PSK",
				"encryption" : "TKIP",
				"signal" : "20",
				"band" : "1"
			}
			]
		}
	}
}
`
| 字段      | 字段         | 描述                                       | API    |
| :------ | :--------- | :--------------------------------------- | ------ |
| config  | enable     | 无线扩展（1：启用，0：禁用）                          | 1.0.0+ |
| config  | band       | 无线扩展频段（1：5G，0：2.4G）                      | 1.0.0+ |
| config  | bssid      | MAC地址                                    | 1.0.0+ |
| config  | ssid       | 网络名称                                     | 1.0.0+ |
| config  | safe_mode  | 安全模式（OPEN，WPA-PSK，WPA2-PSK，WPAWPA2-PSK, WPAENT） | 1.0.0+ |
| config  | encryption | 加密类型（NONE，TKIP，AES，TKIPAES）              | 1.0.0+ |
| config  | password   | 网络密码                                     | 1.0.0+ |
| config  | protocol   | 上网方式（static：静态地址 dhcp：自动获取 pppoe：宽带拨号）   | 1.0.0+ |
| config  | ip         | IP地址                                     | 1.0.0+ |
| config  | gateway    | 默认网关                                     | 1.0.0+ |
| ap_list | bssid      | MAC地址                                    | 1.0.0+ |
| ap_list | ssid       | 网络名称                                     | 1.0.0+ |
| ap_list | safe_mode  | 安全模式（OPEN，WEP，WPA-PSK，WPA2-PSK，WPAWPA2-PSK, WPAENT） | 1.0.0+ |
| ap_list | encryption | 加密类型（NONE，WEP，TKIP，AES，TKIPAES）          | 1.0.0+ |
| ap_list | signal     | 信号强度                                     | 1.0.0+ |
| ap_list | band       | 无线扩展频段（1：5G，0：2.4G）                      | 1.0.0+ |

### 时区设置

#### 获取时区信息

request:
`
{
	"method" : "get" ,
	"module" :
	{
		"time_zone" : {"config" : null}
	}
}
`
response:
`
{
	"error_code" : 0,
	"module" :
	{
		"time_zone" :
		{
			"config" :
			{
				"area" : "EU",
				"region" : "01200"
			}
		}
	}
}
`

| 字段     | 字段     | 描述                        | 版本     |
| ------ | ------ | ------------------------- | ------ |
| config | area   | 时区所在的地区（具体见产品特性中对地区支持的描述） | 1.0.0+ |
| config | region | 时区（格式xxxxx）               | 1.0.0+ |

 region取值范围描述：

| 值     | 描述                                   | API    |
| :---- | :----------------------------------- | :----- |
| 01200 | (GMT-12:00)国际日期变更线西                  | 1.0.0+ |
| 01100 | (GMT-11:00)萨摩亚群岛                     | 1.0.0+ |
| 01000 | (GMT-10:00)夏威夷                       | 1.0.0+ |
| 00900 | (GMT-09:00)阿拉斯加                      | 1.0.0+ |
| 00800 | (GMT-08:00)太平洋时间 (美国和加拿大)            | 1.0.0+ |
| 00700 | (GMT-07:00)山地时间 (美国和加拿大)             | 1.0.0+ |
| 00600 | (GMT-06:00)瓜达拉哈拉、墨西哥城、蒙特雷            | 1.0.0+ |
| 00500 | (GMT-05:00)波哥大、利马、基多                 | 1.0.0+ |
| 00430 | (GMT-04:30)加拉加斯                      | 1.0.0+ |
| 00400 | (GMT-04:00)大西洋时间(加拿大)                | 1.0.0+ |
| 00330 | (GMT-03:30)纽芬兰                       | 1.0.0+ |
| 00300 | (GMT-03:00)巴西利亚                      | 1.0.0+ |
| 00200 | (GMT-02:00)中大西洋                      | 1.0.0+ |
| 00100 | (GMT-01:00)佛得角群岛                     | 1.0.0+ |
| 00000 | (GMT)都柏林、爱丁堡、里斯本、伦敦                  | 1.0.0+ |
| 10100 | (GMT+01:00)阿姆斯特丹、柏林、伯尔尼、罗马、斯德哥尔摩、维也纳 | 1.0.0+ |
| 10200 | (GMT+02:00)赫尔辛基、基辅、里加、索非亚、塔林、维尔纽斯    | 1.0.0+ |
| 10300 | (GMT+03:00)莫斯科、圣彼得堡、伏尔加格勒            | 1.0.0+ |
| 10330 | (GMT+03:30)德黑兰                       | 1.0.0+ |
| 10400 | (GMT+04:00)阿布扎比、马斯喀特                 | 1.0.0+ |
| 10430 | (GMT+04:30)喀布尔                       | 1.0.0+ |
| 10500 | (GMT+05:00)伊斯兰堡、卡拉奇                  | 1.0.0+ |
| 10530 | (GMT+05:30)钦奈、加尔各答、孟买、新德里            | 1.0.0+ |
| 10545 | (GMT+05:45)加德满都                      | 1.0.0+ |
| 10600 | (GMT+06:00)阿斯塔纳                      | 1.0.0+ |
| 10630 | (GMT+06:30)仰光                        | 1.0.0+ |
| 10700 | (GMT+07:00)曼谷、河内、雅加达                 | 1.0.0+ |
| 10800 | (GMT+08:00)北京、重庆、香港特别行政区、乌鲁木齐        | 1.0.0+ |
| 10900 | (GMT+09:00)大阪、札幌、东京                  | 1.0.0+ |
| 10930 | (GMT+09:30)阿德莱德                      | 1.0.0+ |
| 11000 | (GMT+10:00)布里斯班                      | 1.0.0+ |
| 11100 | (GMT+11:00)所罗门群岛、新喀里多尼亚              | 1.0.0+ |
| 11200 | (GMT+12:00)奥克兰、惠灵顿                   | 1.0.0+ |
| 11300 | (GMT+13:00)努库阿洛法                     | 1.0.0+ |

### VPN客户端

#### 获取VPN客户端信息

request:
`
{
	"method" : "get" ,
	"module" :
	{
		"vpn_client" : {"config" : null, "account_list" : null}
	}
}
`
response:
`
{
	"error_code" : 0,
	"module" :
	{
		"vpn_client" :
		{
			"config" :
			{
				"enable" : "1",
				"status" : "2",
				"name" : "AAAAAA",
				"id" : "1"
			}
			"account_list" :
			[
				{
					id : "1",
					name : "AAAAAA",
					protocol : "pptp",
					ip : "192.168.2.100",
					username : "admin",
					password : "admin",
					enable : "1"
				},
				{
					id : "2",
					name : "BBBBBB",
					protocol : "l2tp",
					ip : "192.168.2.101",
					username : "feixun",
					password : "feixun",
					enable : "0"
				}
			]
		}
	}
}
`

| 字段           | 字段       | 描述                                | API    |
| :----------- | :------- | :-------------------------------- | ------ |
| config       | enable   | VPN客户端（1：启用，0：禁用）                 | 1.0.0+ |
| config       | status   | 规则状态（0：未拨号，1：正在拨号，2：拨号成功，-1：拨号失败） | 1.0.0+ |
| config       | name     | 规则名称                              | 1.0.0+ |
| config       | id       | 规则id，跟account_list中的id对应          | 1.0.0+ |
| account_list | id       | VPN客户端规则序号                        | 1.0.0+ |
| account_list | name     | VPN客户端规则名称                        | 1.0.0+ |
| account_list | protocol | VPN客户端规则协议                        | 1.0.0+ |
| account_list | ip       | VPN客户端规则服务IP                      | 1.0.0+ |
| account_list | username | VPN客户端规则用户名                       | 1.0.0+ |
| account_list | password | VPN客户端规则密码                        | 1.0.0+ |
| account_list | enable   | VPN客户端规则状态（0：未连接，1：连接）            | 1.0.0+ |


### VPN服务器

#### 获取VPN服务器信息

request:
`
{
	"method" : "get" ,
	"module" :
	{
		"vpn_server" : {"config" : null, "user_list" : null}
	}
}
`
response:
`
{
	"error_code" : 0,
	"module" :
	{
		"vpn_server" :
		{
			"config" :
			{
				"enable" : "1",
				"protocol" : "pptp",
	        	"server" : "192.168.2.100"
			}
			"user_list" :
	        [
				{
					id : "1",
					username : "AAAAAA",
					password : "123456",
					status : "1"
				},
				{
	                id : "2",
					username : "BBBBBB",
					password : "234567",
					status : "0"
				}
			]
		}
	}
}
`

| 字段        | 字段       | 描述                     | API    |
| :-------- | :------- | :--------------------- | ------ |
| config    | enable   | VPN服务器（1：启用，0：禁用）      | 1.0.0+ |
| config    | protocol | VPN服务器协议               | 1.0.0+ |
| config    | server   | VPN服务器IP/域名            | 1.0.0+ |
| user_list | id       | VPN服务器规则序号             | 1.0.0+ |
| user_list | username | VPN服务器规则用户名            | 1.0.0+ |
| user_list | password | VPN服务器规则密码             | 1.0.0+ |
| user_list | status   | VPN服务器规则状态（0：未连接，1：连接） | 1.0.0+ |

### WDS

#### 获取WDS信息

request:
`
{
	"method" : "get" ,
	"module" :
	{
		"wds" : {"config" : null, "ap_list" : null}
	}
}
`
response:
`
{
	"error_code" : 0,
	"module" :
	{
		"wds" :
		{
			"config" :
			{
				"enable" : "1",
				"bssid" : "00:CD:FE:DF:D7:48",
				"ssid" : "@PHICOMM_XX_XX",
				"password" : "87654321",
				"band" : "0",
				"status" : "1"
			}
			"ap_list" :[
			{
				"bssid" : "00:CD:FE:DF:D7:48",
				"ssid" : "@PHICOMM_11",
				"safe_mode" : "OPEN",
				"mode" : "0",
				"channel" : "0",
				"band_width" : "0",
				"signal" : "90",
				"band" : "0"
			},
			{
				"bssid" : "00:CD:FE:DF:D7:48",
				"ssid" : "@PHICOMM_22",
				"safe_mode" : "WPA2-PSK",
				"mode" : "1",
				"channel" : "1",
				"band_width" : "1",
				"signal" : "20",
				"band" : "1"
			}
			]
		}
	}
}
`

| 字段      | 字段         | 描述                                       | API    |
| ------- | :--------- | :--------------------------------------- | ------ |
| config  | enable     | WDS（1：启用，0：禁用）                           | 1.0.0+ |
| config  | bssid      | 主路由MAC地址                                 | 1.0.0+ |
| config  | ssid       | 主路由SSID                                  | 1.0.0+ |
| config  | password   | 主路由无线密码                                  | 1.0.0+ |
| config  | band       | WDS连接频段（1：5G，0：2.4G）                     | 1.0.0+ |
| config  | status     | WDS连接状态（1：连接，0：未连接）                      | 1.0.0+ |
| ap_list | bssid      | MAC地址                                    | 1.0.0+ |
| ap_list | ssid       | 网络名称                                     | 1.0.0+ |
| ap_list | safe_mode  | 安全模式（OPEN，WEP，WPA-PSK，WPA2-PSK，WPAWPA2-PSK, WPAENT） | 1.0.0+ |
| ap_list | mode       | 无线模式（与无线设置保存一致）                          | 1.0.0+ |
| ap_list | channel    | 无线信道（与无线设置保存一致）                          | 1.0.0+ |
| ap_list | band_width | 无线带宽（与无线设置保存一致）                          | 1.0.0+ |
| ap_list | signal     | 信号强度                                     | 1.0.0+ |
| ap_list | band       | 无线扩展频段（1：5G，0：2.4G）                      | 1.0.0+ |

### QoS

#### 获取QoS信息

request:
`
{
	"method" : "get" ,
	"module" :
	{
		"qos" : {"config" : null}
	}
}
`
response:
`
{
	"error_code" : 0,
	"module" :
	{
		"qos" :
		{
			"config" :
			{
				"enable" : "0",
				"mode" : "0"
			}
		}
	}
}
`

| 字段     | 字段     | 描述                                    | API    |
| :----- | :----- | :------------------------------------ | ------ |
| config | enable | QoS（1：启用，0：禁用）                        | 1.0.0+ |
| config | mode   | 带宽优先项（0：BT下载，1：游戏，2：网页浏览，3：影音，4：平衡模式） | 1.0.0+ |

### 家长控制

#### 获取家长控制信息

request:
`
{
	"method" : "get" ,
	"module" :
	{
		"parent_ctrl" : {"config" : null, "parent_list" : null}
	}
}
`
response:
`
{
	"error_code" : 0,
	"module" :
	{
		"parent_ctrl" :
		{
			"config" :
			{
				"enable" : "0"
			}
			"parent_list" :
			[
				{
					"id" : "0",
					"name" : "AAAAAA",
					"mac" : "11:22:33:44:55:66",
					"cycle" : "1111111",
					"start_time" : "0",
					"end_time" : "3600",
					"brand": "mi"
				},
				{
					"id" : "1",
					"name" : "BBBBBB",
					"mac" : "22:22:33:44:55:66",
					"cycle" : "0011111",
					"start_time" : "0",
					"end_time" : "86439",
					"brand": "apple"
				}
			]
		}
	}
}
`

| 字段          | 字段         | 描述                 | API    |
| :---------- | :--------- | :----------------- | ------ |
| config      | enable     | 家长控制（1：启用，0：禁用）    | 1.0.0+ |
| parent_list | id         | 规则序号               | 1.0.0+ |
| parent_list | name       | 规则名称               | 1.0.0+ |
| parent_list | mac        | MAC地址                | 1.0.0+ |
| parent_list | cycle      | 规则周期               | 1.0.0+ |
| parent_list | start_time | 起始时间（秒为单位，0-86439） | 1.0.0+ |
| parent_list | end_time   | 终止时间（秒为单位，0-86439） | 1.0.0+ |
| parent_list | brand      | 品牌名称（支持OUI更新时需返回）| 1.0.0+ |

### 指示灯开关

#### 获取指示灯信息

request:
`
{
    "method" : "get" ,
    "module" :
    {
        "light" : {"config" : null}
    }
}
`
response:
`
{
    "error_code" : 0,
    "module" :
    {
        "light" :
        {
            "config" :
            {
                "enable" : "1"
            }
        }
    }
}

| 字段     | 描述                | API    |
| :----- | :---------------- | :----- |
| enable | 指示灯开关（0：关闭， 1：开启） | 1.0.0+ |

### 定时重启路由器

#### 获取定时重启路由器信息

request:
`
{
    "method" : "get" ,
    "module" :
    {
        "time_reboot" : {"config" : null}
    }
}
`
response:
`
{
    "error_code" : 0,
    "module" :
    {
        "time_reboot" :
        {
            "config" :
            {
                "enable" : "1",
                "reboot_hour" : 0,
                "reboot_minute" : 0
            }
        }
    }
}

| 字段     | 描述                | API    |
| :----- | :---------------- | :----- |
| enable | 定时重启路由器开关（0：关闭， 1：开启） | 1.0.0+ |
| reboot_hour | 重启小时数，为0~23之间的整数 | 1.0.0+ |
| reboot_minute | 重启分钟数，为0~55之间5的倍数 | 1.0.0+ |