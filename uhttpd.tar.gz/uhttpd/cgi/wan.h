#ifndef _WAN__H_
#define _WAN_H_


#include <fcntl.h>

/* for get primary dns and secondary dns */
#define DNS_STATIC 0
#define DNS_DHCP   1
#define DNS_PPPOE  2
#define DNS_NONE   3

/* for get PPPoE error code */
#define INTERNET_FAIL 0
#define INTERNET_SUCCESS 1
#define PPPOE_ERR_PATH "/tmp/pppoeerr"
#define ERRORCODE "ErrorCode="

/* for wan status code */
#define WAN_OK                          0
#define WAN_DISCONNET                   1
#define WAN_NOIP                        2
#define WAN_GATE_NO_RSP                 3
#define WAN_NODNS                       4
#define WAN_DNS_NO_RSP                  5
#define WAN_DNS_MANUAL                  6
#define WAN_DHCP_NO_SER                 7
#define WAN_DHCP_GETING                 8
#define WAN_PPPOE_GETING                9
#define WAN_PPPOE_SER_NO_RSP            10
#define WAN_PPPOE_ERR_646               646
#define WAN_PPPOE_ERR_647               647
#define WAN_PPPOE_ERR_648               648
#define WAN_PPPOE_ERR_649               649
#define WAN_PPPOE_ERR_678               678
#define WAN_PPPOE_ERR_691               691
#define WAN_PPPOE_ERR_709               709


extern int encrypt_user(char *dst, char *src);
extern int encrypt_pwd_chinavnet32(char *dst, char *src);
extern int encrypt_user_chinavnet_31(char *dst, char *src);
extern int encrypt_user_chinavnet32(char *dst, char *src);
extern int encrypt_user_chinavnet25(char *dst, char *src);

extern int pingalive(char *ipaddress);

#endif
