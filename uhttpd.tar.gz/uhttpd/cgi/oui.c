#include <json.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <oui.h>
#include <unistd.h>
#include <brand.h>
#include <elog.h>

#define VENDOR_FILE "/usr/sbin/oui.txt"

json_object *parse_file(char *filename);

oui_handler_t load_available_oui()
{
    json_object *js_obj;
    /* access UPDATED_OUI */
    if (access(UPDATED_OUI, R_OK) == 0) {
        js_obj = parse_file((char*)(UPDATED_OUI));
        if (js_obj != NULL) {
            elog_printf(ELOG_DEBUG, "load updated OUI succeeded\n");
            return js_obj;
        }
    }

    /* no usable updated-oui, then access NATIVE_OUI */
    if (access(NATIVE_OUI, R_OK) == 0) {
        js_obj = parse_file((char*)NATIVE_OUI);
        if (js_obj != NULL) {
            elog_printf(ELOG_DEBUG, "load native OUI succeeded\n");
            return js_obj;
        }
    }
    /* Oops! */
    elog_printf(ELOG_ERR, "Oops! Load OUI failed!\n");
    return NULL;
}

void release_oui(oui_handler_t oui_json)
{
    json_object *json = (json_object *)oui_json;
    if (json)
        json_object_put(json);
}

json_object* json_check_type(json_object *obj, json_type type)
{
    if (!obj)
        return NULL;

    if (json_object_get_type(obj) != type)
        return NULL;

    return obj;
}

json_object* json_get_field(json_object *obj, const char *name, json_type type)
{
    return json_check_type(json_object_object_get(obj, name), type);
}

json_object *parse_file(char *filename)
{
    FILE *fp = NULL;
    long file_s,file_e,file_l;
    char *buffer = NULL;
    json_object *json = NULL;

    fp = fopen(filename,"r");
    if (fp == NULL) {
        perror("fopen");
        return NULL;
    }
    if ((fseek(fp, 0, SEEK_SET) == -1) || ((file_s = ftell(fp)) == -1) ||
        (fseek(fp, 0, SEEK_END)== -1) || ((file_e = ftell(fp)) == -1)) {
        perror("fp opt");
        return NULL;
    }
    file_l = file_e - file_s;
    buffer = (unsigned char*)malloc(file_l);
    if (buffer == NULL) {
        perror("malloc");
        return NULL;
    }
    memset(buffer, 0, file_l);
    if ((fseek(fp, 0, SEEK_SET) == -1) || (fread(buffer, file_l, 1, fp) == -1) ) {
        perror("fp opt");
        return NULL;
    }
    fclose(fp);
    fp = NULL;
    json = json_tokener_parse(buffer);
    free(buffer);
    buffer = NULL;

    return json;
}

int get_vendor_id(oui_handler_t oui, const char *mac)
{
    json_object *json = (json_object *)oui;
    int obj_size, i;
    int found = 0;

    if (json == NULL) {
        elog_printf(ELOG_ERR, "NULL pointer\n");
        found = 0;
        goto out;
    }
    elog_printf(ELOG_DEBUG, "MAC lookup: %s\n", mac);

    /* traverse brand object */
    obj_size = json_object_array_length(json);
    for (i = 0; i < obj_size; i++) {
        json_object *cur, *mac_obj, *brand_obj;
        cur = json_check_type(json_object_array_get_idx(json, i), json_type_object);
        if (!cur) {
            elog_printf(ELOG_ERR, "Wrong json format!\n");
            goto out;
        }

        brand_obj = json_get_field(cur, "brand", json_type_string);
        if (!brand_obj) {
            elog_printf(ELOG_ERR, "Wrong json format!\n");
            goto out;
        }

        mac_obj = json_get_field(cur, "mac", json_type_array);
        if (!mac_obj) {
            elog_printf(ELOG_ERR, "Wrong json format!\n");
            goto out;
        }

        /* traverse mac array */
        int j, nmac;
        nmac = json_object_array_length(mac_obj);
        found = 0;
        for (j = 0; j < nmac; j++) {
            json_object *element = json_check_type(json_object_array_get_idx(mac_obj, j), json_type_string);
            if (element == NULL) {
                elog_printf(ELOG_ERR, "Wrong json format!!");
                goto out;
            }

            const char *tmpmac = json_object_get_string(element);
            if (strncasecmp(tmpmac, mac, strlen("AA:BB:CC")) == 0) {
                found = resolve_vendor(json_object_get_string(brand_obj));
                elog_printf(ELOG_DEBUG, "Brand found :%s, VID is %d\n",
                            json_object_get_string(brand_obj), found);
                goto out;
            }
        }
    }
 out:

	return found;
}

int get_vendor_name(oui_handler_t oui, const char *mac, char *buffer, size_t size)
{
    json_object *json = (json_object *)oui;
    int obj_size, i;

    if (!buffer) {
        elog_printf(ELOG_ERR, "@buffer shouldn't be empty\n");
        return -1;
    }
    snprintf(buffer, size, "Unknown");

    if (!json) {
        elog_printf(ELOG_ERR, "NULL pointer\n");
        return -1;
    }
    elog_printf(ELOG_DEBUG, "MAC lookup: %s\n", mac);

    /* traverse brand object */
    obj_size = json_object_array_length(json);
    for (i = 0; i < obj_size; i++) {
        json_object *cur, *mac_obj, *brand_obj;
        cur = json_check_type(json_object_array_get_idx(json, i), json_type_object);
        if (!cur) {
            elog_printf(ELOG_ERR, "Wrong json format!\n");
            return -1;
        }

        brand_obj = json_get_field(cur, "brand", json_type_string);
        if (!brand_obj) {
            elog_printf(ELOG_ERR, "Wrong json format!\n");
            return -1;
        }

        mac_obj = json_get_field(cur, "mac", json_type_array);
        if (!mac_obj) {
            elog_printf(ELOG_ERR, "Wrong json format!\n");
            return -1;
        }

        /* traverse mac array */
        int j, nmac;
        nmac = json_object_array_length(mac_obj);
        json_object *element;
        for (j = 0; j < nmac; j++) {
            element = json_check_type(json_object_array_get_idx(mac_obj, j),
                                      json_type_string);
            if (element == NULL) {
                elog_printf(ELOG_ERR, "Wrong json format!!");
                return -1;
            }

            const char *tmpmac = json_object_get_string(element);
            if (strncasecmp(tmpmac, mac, strlen("AA:BB:CC")) == 0) {
                snprintf(buffer, size, "%s", json_object_get_string(brand_obj));

                elog_printf(ELOG_DEBUG, "Brand found :%s\n",
                            json_object_get_string(brand_obj));
                return 0;
            }
        }
    }

	return 0;
}
