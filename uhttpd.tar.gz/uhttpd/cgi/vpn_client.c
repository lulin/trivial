/**
 * Data model, double check luci-1.0.0/doc/api.md:
 */

#include <stdlib.h>
#include <libphi_cgi.h>
#include <vpn_client.h>
#include <nv_vpn_client.h>

#define nv2json(k) (json_object_new_string(nvram_safe_get(k)))

int get_vpnc_conf(json_object *object)
{
    json_object *carry;

    if ((carry = json_object_new_object()) == NULL) {
        cgi_debug("json new failed, run out of memory?\n");
        return NV_FAIL;
    }

    json_object_object_add(carry, "enable", nv2json(NV_KEY_VPNC_ENABLE));
    json_object_object_add(carry, "status", nv2json(NV_KEY_VPNC_STATUS));
    json_object_object_add(carry, "name", nv2json(NV_KEY_VPNC_NAME));
    json_object_object_add(carry, "id", nv2json(NV_KEY_VPNC_ID));

    /* WARNING, constant "confs" is bare */
    json_object_object_add(object, "confs", carry);

    return NV_SUCCESS;
}

int set_vpnc_conf(json_object *object)
{
    const char *enabled = NULL;
    const char *name = NULL;
    const char *id = NULL;

    int i_enabled_old;
    int i_enabled_new;
    i_enabled_old = atoi(nvram_safe_get(NV_KEY_VPNC_ENABLE))? 1: 0;
    i_enabled_new = i_enabled_old;

    json_object_object_foreach(object, key, val) {
        if (!strcmp(key, "enable")) {
            enabled = json_object_get_string(val);
            i_enabled_new = atoi(enabled)? 1 : 0;
        }
        else if (!strcmp(key, "name")) {
            name = json_object_get_string(val);
        }
        else if (!strcmp(key, "id")) {
            id = json_object_get_string(val);
        }
        else {
            continue;
        }
    }

    if ((name && !nvram_match(NV_KEY_VPNC_NAME, name)) ||
        (id && !nvram_match(NV_KEY_VPNC_ID, id)) ||
        (enabled && (i_enabled_new != i_enabled_old))
        ) {

        /* verify, omitted */
        /* store */
        if (enabled)
            nvram_set(NV_KEY_VPNC_ENABLE, enabled);
        if (id)
            nvram_set(NV_KEY_VPNC_ID, id);
        if (name)
            nvram_set(NV_KEY_VPNC_NAME, name);
        nvram_commit();

        int pstatus = 0;
        if (i_enabled_new == i_enabled_old){
            if (i_enabled_new) {
                /* restart */
                pstatus = system("/etc/init.d/vpnc.sh restart");
            } /* else do nothing */
        }
        else if (i_enabled_new) {
            /* start */
            pstatus = system("/etc/init.d/vpnc.sh start");
        }
        else {
            /* stop */
            pstatus = system("/etc/init.d/vpnc.sh stop");
        }

        if (pstatus && !(WIFEXITED(pstatus) && (WEXITSTATUS(pstatus) == 0))) {
            return NV_FAIL;
        }
    }

    return NV_SUCCESS;
}

int get_vpnc_accounts(json_object *object)
{
    json_object *carry = json_object_new_array();
    // assert(carry);

    int count = 0;
    vpnc_account_ptr *accts;
    if (!(accts = vpnc_setup_accounts_dump(&count))) {
        goto out;
    }

    int i;
    json_object *item;
    for (i = 0; i < count; i++) {
        item = json_object_new_object();

        json_object_object_add(item, "id", json_object_new_string(accts[i]->id));
        json_object_object_add(item, "enable",
                               json_object_new_string(accts[i]->enabled? "1": "0"));
        json_object_object_add(item, "name", json_object_new_string(accts[i]->name));
        json_object_object_add(item, "protocol",
                               json_object_new_string(accts[i]->protocol));
        json_object_object_add(item, "ip", json_object_new_string(accts[i]->peer));
        json_object_object_add(item, "username",
                               json_object_new_string(accts[i]->user));
        json_object_object_add(item, "password",
                               json_object_new_string(accts[i]->password));

        json_object_array_add(carry, item);
    }

 out:
    if (accts) {
        for (i = 0; i < count; i++) {
            vpnc_account_release(accts[i]);
        }
        free(accts);
    }

    json_object_object_add(object, "confs", carry);
    return 0;
}

int set_vpnc_account(json_object *object)
{
    int ec = NV_SUCCESS;
    json_object *item;
    vpnc_account_ptr account = vpnc_account_new();

    if (json_object_object_get_ex(object, "id", &item)) {
        vpnc_account_set_id(account, json_object_get_string(item));
    }

    if (json_object_object_get_ex(object, "name", &item)) {
        vpnc_account_set_name(account, json_object_get_string(item));
    }

    if (json_object_object_get_ex(object, "protocol", &item)) {
        vpnc_account_set_proto(account, json_object_get_string(item));
    }

    if (json_object_object_get_ex(object, "ip", &item)) {
        vpnc_account_set_peer(account, json_object_get_string(item));
    }

    if (json_object_object_get_ex(object, "username", &item)) {
        vpnc_account_set_user(account, json_object_get_string(item));
    }

    if (json_object_object_get_ex(object, "password", &item)) {
        vpnc_account_set_password(account, json_object_get_string(item));
    }

    if (json_object_object_get_ex(object, "enable", &item)) {
        vpnc_account_set_enabled(account, atoi(json_object_get_string(item))? 1: 0);
    }

    /* store account into nvram */
    if (vpnc_setup_account_set(account) < 0) {
        ec = NV_FAIL;
        goto out;
    }

 out:
    vpnc_account_release(account);
    return ec;
}

int add_vpnc_account(json_object *object)
{
    int ec = NV_SUCCESS;
    json_object *item;
    vpnc_account_ptr account = vpnc_account_new();

    /**
     * Convert json_object to vpnc_account_ptr object
     */

    if (json_object_object_get_ex(object, "id", &item)) {
        /* actually, the ID field is determined by vpnc_setup_account_add(). */
        vpnc_account_set_id(account, json_object_get_string(item));
    }

    if (json_object_object_get_ex(object, "name", &item)) {
        vpnc_account_set_name(account, json_object_get_string(item));
    }

    if (json_object_object_get_ex(object, "protocol", &item)) {
        vpnc_account_set_proto(account, json_object_get_string(item));
    }

    if (json_object_object_get_ex(object, "ip", &item)) {
        vpnc_account_set_peer(account, json_object_get_string(item));
    }

    if (json_object_object_get_ex(object, "username", &item)) {
        vpnc_account_set_user(account, json_object_get_string(item));
    }

    if (json_object_object_get_ex(object, "password", &item)) {
        vpnc_account_set_password(account, json_object_get_string(item));
    }

    if (json_object_object_get_ex(object, "enable", &item)) {
        vpnc_account_set_enabled(account, atoi(json_object_get_string(item))? 1: 0);
    }

    /* add account */
    if (vpnc_setup_account_add(account) < 0) {
        ec = NV_FAIL;
        goto out;
    }

 out:
    vpnc_account_release(account);
    return ec;
}

int del_vpnc_account(json_object *object)
{
    const char *name = NULL;
    json_object *item = NULL;

    if (!json_object_object_get_ex(object, "name", &item)) {
        return NV_FAIL;
    }
    name = json_object_get_string(item);

    if (vpnc_setup_account_del(name) < 0) {
        return NV_FAIL;
    }

    return NV_SUCCESS;
}

