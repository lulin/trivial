#include <signal.h>
#include <notify.h>
#include <oid.h>

#include "libphi_cgi.h"
#define MAX_NO_BRIDGE 1
#define __CONFIG_P_TO__ 1

static char *g_dns[]={
	".top",
	".com",
	".net",
	".org",
	".edu",
	".gov",
	".int",
	".mil",
	".cn",
	".com.cn",
	".net.cn",
	".gov.cn",
	".org.cn",
	".tel",
	".biz",
	".cc",
	".tv",
	".info",
	".name",
	".hk",
	".mobi",
	".asia",
	".cd",
	".travel",
	".pro",
	".museum",
	".coop",
	".aero",
	".ad",
	".ae",
	".af",
	".ag",
	".ai",
	".al",
	".am",
	".an",
	".ao",
	".aq",
	".ar",
	".as",
	".at",
	".au",
	".aw",
	".az",
	".ba",
	".bb",
	".bd",
	".be",
	".bf",
	".bg",
	".bh",
	".bi",
	".bj",
	".bm",
	".bn",
	".bo",
	".br",
	".bs",
	".bt",
	".bv",
	".bw",
	".by",
	".bz",
	".ca",
	".cc",
	".cf",
	".cg",
	".ch",
	".ci",
	".ck",
	".cl",
	".cm",
	".cn",
	".co",
	".cq",
	".cr",
	".cu",
	".cv",
	".cx",
	".cy",
	".cz",
	".de",
	".dj",
	".dk",
	".dm",
	".do",
	".dz",
	".ec",
	".ee",
	".eg",
	".eh",
	".es",
	".et",
	".ev",
	".fi",
	".fj",
	".fk",
	".fm",
	".fo",
	".fr",
	".ga",
	".gb",
	".gd",
	".ge",
	".gf",
	".gh",
	".gi",
	".gl",
	".gm",
	".gn",
	".gp",
	".gr",
	".gt",
	".gu",
	".gw",
	".gy",
	".hk",
	".hm",
	".hn",
	".hr",
	".ht",
	".hu",
	".id",
	".ie",
	".il",
	".in",
	".io",
	".iq",
	".ir",
	".is",
	".it",
	".jm",
	".jo",
	".jp",
	".ke",
	".kg",
	".kh",
	".ki",
	".km",
	".kn",
	".kp",
	".kr",
	".kw",
	".ky",
	".kz",
	".la",
	".lb",
	".lc",
	".li",
	".lk",
	".lr",
	".ls",
	".lt",
	".lu",
	".lv",
	".ly",
	".ma",
	".mc",
	".md",
	".mg",
	".mh",
	".ml",
	".mm",
	".mn",
	".mo",
	".mp",
	".mq",
	".mr",
	".ms",
	".mt",
	".mv",
	".mw",
	".mx",
	".my",
	".mz",
	".na",
	".nc",
	".ne",
	".nf",
	".ng",
	".ni",
	".nl",
	".no",
	".np",
	".nr",
	".nt",
	".nu",
	".nz",
	".om",
	".qa",
	".pa",
	".pe",
	".pf",
	".pg",
	".ph",
	".pk",
	".pl",
	".pm",
	".pn",
	".pr",
	".pt",
	".pw",
	".py",
	".re",
	".ro",
	".ru",
	".rw",
	".sa",
	".sb",
	".sc",
	".sd",
	".se",
	".sg",
	".sh",
	".si",
	".sj",
	".sk",
	".sl",
	".sm",
	".sn",
	".so",
	".sr",
	".st",
	".su",
	".sy",
	".sz",
	".tc",
	".td",
	".tf",
	".tg",
	".th",
	".tj",
	".tk",
	".tm",
	".tn",
	".to",
	".tp",
	".tr",
	".tt",
	".tv",
	".tw",
	".tz",
	".ua",
	".ug",
	".uk",
	".us",
	".uy",
	".va",
	".vc",
	".ve",
	".vg",
	".vn",
	".vu",
	".wf",
	".ws",
	".ye",
	".yu",
	".za",
	".zm",
	".zr",
	".zw",
	NULL
};
int creatednsmanqconf()
{
	FILE *fp = -1;
	char buf[256] = {0};
	char ip[16] = {0};
	int i = 0;
	strncpy(ip, nvram_safe_get( "lan_ipaddr" ), 15 );
	printf("%s %d ip = %s\n", __FUNCTION__, __LINE__, ip);

	fp = fopen("/tmp/dnsmasq_1.conf","w");
	if (fp == NULL)
	{
	    return -1;
	}
	memset(buf, 0, sizeof(buf));
	memcpy(buf, "strict-order\n", sizeof("strict-order\n"));
	fwrite(buf, strlen(buf), 1 , fp);
	memset(buf, 0, sizeof(buf));
	memcpy(buf, "no-poll\n", sizeof("no-poll\n"));
	fwrite(buf, strlen(buf), 1 , fp);

	memset(buf, 0, sizeof(buf));
	sprintf(buf, "address=/phicomm.me/%s\n", ip);
	fwrite(buf, strlen(buf), 1 , fp);

	for (i = 0; g_dns[i] != NULL; i++)
	{
		memset(buf, 0, sizeof(buf));
		sprintf(buf, "address=/%s/%s\n",g_dns[i], ip);
		fwrite(buf, strlen(buf), 1 , fp);
	}

	memset(buf, 0, sizeof(buf));
	sprintf(buf, "listen-address=%s,127.0.0.1\n",ip);
	fwrite(buf, strlen(buf), 1 , fp);
	fclose(fp);
	
	return 0;
}

int clean_dns_hijack()
{
	char *dns_hijack= NULL;

	dns_hijack = nvram_get("dns_hijack");

	if (dns_hijack == NULL)
		return 0;
	
	if (nvram_match("dns_hijack", "") || nvram_invmatch("dns_hijack", "1"))
		return 0;

	nvram_set("dns_hijack", "0");
	nvram_commit();
}

static int resetDNSconfig(int flag)
{
	char dns_cmd[255];
	char *lan_ifname = NULL;
	char dns_ifnames[64] = "";
	char tmp[20];
	int i = 0;
	int ret = 0;

	if (nvram_match("dns_hijack", "0"))
		return 0;
	
	/* Setup interface list for the dns relay */
	for (i = 0; i < MAX_NO_BRIDGE; i++) {
		if (!i)
			snprintf(tmp, sizeof(tmp), "lan_ifname");
		else
			snprintf(tmp, sizeof(tmp), "lan%x_ifname", i);

		lan_ifname = nvram_safe_get(tmp);

		if (!strcmp(lan_ifname, ""))
			continue;

		snprintf(dns_ifnames, sizeof(dns_ifnames), "%s -i %s", dns_ifnames, lan_ifname);
	}

	if (flag == 1 && (creatednsmanqconf() == 0)) //first login
	{
		sprintf(dns_cmd, "/usr/sbin/dnsmasq %s -C /tmp/dnsmasq_1.conf &", dns_ifnames);
	}
	else
	{
#ifdef __CONFIG_P_TO__
		sprintf(dns_cmd, "/usr/sbin/dnsmasq -n %s -r /tmp/resolv.conf&", dns_ifnames);
#else
		sprintf(dns_cmd, "/usr/sbin/dnsmasq -h -n %s -r /tmp/resolv.conf&", dns_ifnames);
#endif
	}
	system("killall dnsmasq");

	clean_dns_hijack();
	ret = system(dns_cmd);
	return 0;
}

void close_redirect(void)
{
	resetDNSconfig(0);
	nvram_set("dns_hijack","0");
	nvram_commit();
}

void do_reboot(void)
{
	system("uhmiMsg reboot");
	notification_send_rc(OID_SYSTEM_REBOOT, NOTIFY_NOWAIT);
}

void rc_restart(void)
{
	kill(1, SIGHUP);
}


