#ifndef __DEVICE_MANAGE_H__
#define __DEVICE_MANAGE_H__


#define DEV_IP_LEN			16 // xxx.xxx.xxx.xxx?
#define DEV_MAC_LEN			18 // xx:xx:xx:xx:xx:xx
#define NVRAM_RENAME_LEN	128
#define DEV_VENDOR_LEN		64

#define DEVICE_MAX			HOSTS_MAX

//#define NVRAM_RATE_LIMIT	"dev_ratelimit"
#define NVRAM_RENAME		"dev_rename"
//#define NVRAM_IPCTL_RULES	"ip_ctl_rules"
#define NVRAM_DEVDENY		"blockmac_rules"
#define NVRAM_STATIC_LIST	"dhcpreve_rules"

#undef DEV_MNG_DEBUG
#ifdef DEV_MNG_DEBUG
#define dev_mng_debug(fmt, args...) cprintf("(%s:%d)=> " fmt, __FUNCTION__, __LINE__, ## args)
#else
#define dev_mng_debug(fmt, args...)
#endif

typedef struct _dev_status_s{
	struct _dev_status_s *p_next;
	char   ip[DEV_IP_LEN];
	char   mac[DEV_MAC_LEN];
	char   hostname[HOST_NAME_LEN];
	char   rename[NVRAM_RENAME_LEN];
	char   brand[DEV_VENDOR_LEN];
//	char   iface[16];
	int    if_type;
	int    bind_flags;	//DHCP static ip bind flags
	uint32 rxByte;		//rx rate
	uint32 txByte;		//tx rate
	uint32 limit_down;	//dowload limit
	uint32 limit_up;	//upload limit
	int    deny;		//internet allow -> 1:deny  0:allow
	int    online_flags; //1:online, 0:ofline (get from nvram)
	u_int32_t lease_time; //lease time from dhcpd.lease
	u_int32_t join_time; //client join time
	int    i_idx;
}dev_status;

#endif

