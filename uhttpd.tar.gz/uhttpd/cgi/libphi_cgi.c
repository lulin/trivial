/*********************************************************************
   Copyright (C) 2016. Shanghai PHICOMM Communication Co.,Ltd.

   DISCREPTION   : CGI Adapter Layer
   AUTHOR        : meining.sun <meining.sun@phicomm.com.cn>
   CREATED DATE  : 2017-6-28
   MODIFIED DATE :
*********************************************************************/

#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <syslog.h>
#include <lua.h>
#include <lualib.h>
#include <lauxlib.h>
#include <unistd.h>


#include "libphi_cgi.h"


/*=============================================================================
 * Function Name : phi_json_object_put
 * Description   : if the args is not null, put the json object
 *===========================================================================*/
static void phi_json_object_put(json_object *object)
{
	if (object)
	{
		json_object_put(object);
	}
	return;
}

/*=============================================================================
 * Function Name : send_response
 * Description   : Send error_code and confs with json string format
 *===========================================================================*/
static int send_response(int nRet, json_object *object, lua_State *L)
{
	lua_pushnumber(L, nRet);

	if (object)
		lua_pushstring(L, json_object_get_string(object));

	return NV_SUCCESS;
}

/*=============================================================================
 * Function Name : send_response
 * Description   : Send error_code
 *===========================================================================*/
static int send_response_ex(int nRet, lua_State *L)
{
	lua_pushnumber(L, nRet);

	return NV_SUCCESS;
}

struct phi_nvhandler{
	char *keyword;
	int (*get_section_conf)(json_object *object);
	int (*set_section_conf)(json_object *confs);
	int (*add_section_conf)(json_object *confs);
	int (*del_section_conf)(json_object *confs);
};

struct phi_nvhandler phi_nvhandlers[] = {
	{"network.lan", get_lan_conf, set_lan_conf, NULL, NULL},
	{"network.wan", get_wan_conf, set_wan_conf, NULL, NULL},
	{"network.static", get_static_conf, set_static_conf, NULL, NULL},
	{"network.dhcp", get_dhcp_conf, set_dhcp_conf, NULL, NULL},
	{"network.pppoe", get_pppoe_conf, set_pppoe_conf, NULL, NULL},
	{"network.wan_status", get_wan_status_conf, NULL, NULL, NULL},
	{"wireless.guest_wifi", get_guest_network_conf, set_guest_network_conf, NULL, NULL},

	/* wireless config */
	{"wireless.smart_connect", get_smart_connect, set_smart_connect, NULL, NULL},
	{"wireless.wifi_2g_config", get_wifi_2g, set_wifi_2g, NULL, NULL},
	{"wireless.wifi_5g_config", get_wifi_5g, set_wifi_5g, NULL, NULL},
	{"wireless.wifi_2g_status", get_wifi_2g_status_conf, NULL, NULL, NULL},
	{"wireless.wifi_5g_status", get_wifi_5g_status_conf, NULL, NULL, NULL},
	/* wireless config end */

	{"account.config", get_password_conf, set_password_conf, NULL, NULL},
	{"welcome.config", get_welcome_password_conf, set_welcome_password_conf, NULL, NULL},
	{"safe_set.config", get_safe_set_conf, set_safe_set_conf, NULL, NULL},
	{"device.info", get_info_conf, NULL, NULL, NULL},
	{"firewall.remote_manager", get_remote_manager_conf, set_remote_manager_conf, NULL, NULL},
	{"firewall.dmz", get_firewall_dmz_conf, set_firewall_dmz_conf, NULL, NULL},
	{"device_manage.client_list", get_device_mng_conf, set_device_mng_conf, NULL, NULL},
	{"upnp.config", get_upnp_config_conf, set_upnp_config_conf, NULL, NULL},
	{"upnp.upnp_list", get_upnp_list_conf, NULL, NULL, NULL},
	{"screen_set.config", get_screen_set_conf, set_screen_set_conf, NULL, NULL},
	{"parent_ctrl.config", get_parent_ctrl_config_conf, set_parent_ctrl_config_conf, NULL, NULL},
	{"parent_ctrl.parent_list", get_parent_ctrl_list_conf, set_parent_ctrl_list_conf, add_parent_ctrl_list_conf, del_parent_ctrl_list_conf},
	{"dhcpd.config", get_dhcpd_conf, set_dhcpd_conf, NULL, NULL},
	{"dhcpd.bind_list", get_bind_list, set_bind_list, add_bind_list, del_bind_list},
	{"time_reboot.config", get_time_reboot_conf, set_time_reboot_conf, NULL, NULL},
    /* VPN client related */
    {"vpn_client.config", get_vpnc_conf, set_vpnc_conf, NULL, NULL},
    {"vpn_client.account_list", get_vpnc_accounts, set_vpnc_account, add_vpnc_account, del_vpnc_account},
	{NULL, NULL, NULL, NULL, NULL}
};

struct action_handler
{
	char *module;
	char *action;
	int (*do_action)(void);
};

struct action_handler action_handlers[] = {
	{"system", "reboot", do_reboot},
	{"redirect", "close", close_redirect},
	//{"system", "reset", do_reset},
	{"rc", "restart", rc_restart},
	{NULL, NULL, NULL}
};

/*=============================================================================
 * Function Name : set_cgi_option
 * Description   : Set the phi_nv handler
 *===========================================================================*/
static int set_cgi_option(lua_State *L, char *Object, const char *method)
{
	int nRet = NV_SUCCESS;
	json_object *my_object = NULL;
	struct phi_nvhandler *handler;
	json_object *confs = NULL;
	json_object *module_object = NULL;
	confs = json_object_new_object();

	if (!Object || !strlen(Object) )
	{
		cgi_debug("Object %s is NULL\n",Object);
		nRet = NV_FAIL;
		goto returnHandler;
	}

	if (!(my_object = json_tokener_parse(Object)))
	{
		cgi_debug("param json parse failed, Object=%s\n",Object);
		nRet = NV_FAIL;
		goto returnHandler;
	}

	/* should check is object first */
	if (json_object_get_type(my_object) == json_type_null)
	{
		cgi_debug("param is not json object, Object=%s\n",Object);
		nRet = NV_FAIL;
		goto returnHandler;
	}

	if (json_object_get_type(my_object) == json_type_object)
	{
		json_object_object_foreach(my_object, key, val)
		{
			//循环去结构体查找对应模块的处理函数
			for(handler = &phi_nvhandlers[0]; handler->keyword; handler++)
			{
				if (!strcmp(key, handler->keyword))
				{
					if (!strcmp(method, "get"))
					{
						nRet = handler->get_section_conf(confs);
						if(!json_object_object_get_ex(confs,"confs",&module_object))
						{
							nRet = NV_FAIL;
							goto returnHandler;
						}
					}
					else if (!strcmp(method, "set"))
					{
						nRet = handler->set_section_conf(val);
					}
					else if (!strcmp(method, "add"))
					{
						nRet = handler->add_section_conf(val);
					}
					else if (!strcmp(method, "del"))
					{
						nRet = handler->del_section_conf(val);
					}

					goto returnHandler;
				}
			}
			//未找到相应模块的对应处理函数
			cgi_debug("%s module handler not find\n",key);
			nRet = NV_FAIL;
		}
	}

returnHandler:
	send_response(nRet, module_object, L);
	/* free json */
	phi_json_object_put(confs);
	phi_json_object_put(my_object);

	return nRet;
}

/*=============================================================================
 * Function Name : do_cgi
 * Description   : do action function, include reboot,factoryreset,backup...
 *===========================================================================*/
static int do_cgi(lua_State *L, char *Object)
{
	int nRet = NV_FAIL;
	struct action_handler *handler;
	json_object *my_object = NULL;
	json_object *do_object = NULL;
	json_object *module_object = NULL;

	if (!Object  || !strlen(Object))
	{
		goto returnHandler;
	}

	if (!(my_object = json_tokener_parse(Object)))
	{
		goto returnHandler;
	}

	if (!json_object_object_get_ex(my_object, "action", &do_object))
	{
		goto returnHandler;
	}

	if (!json_object_object_get_ex(my_object, "module", &module_object))
	{
		goto returnHandler;
	}

	const char *action = json_object_get_string(do_object);
	const char *module = json_object_get_string(module_object);
	//循环去结构体查找对应模块的处理函数
	for(handler = &action_handlers[0]; handler->action; handler++)
	{
		if (!strcmp(module, handler->module)  && !strcmp(action, handler->action))
		{
			cgi_debug("module=%s\n",handler->module);
			nRet = handler->do_action();

			goto returnHandler;
		}
	}

	//未找到相应模块的对应处理函数
	cgi_debug("not find apply handler\n");
	nRet = NV_FAIL;

returnHandler:
	send_response_ex(nRet, L);
	/* free json */
	phi_json_object_put(my_object);

	return nRet;
}


static int get_module_cfg(lua_State *L)
{
	int nRet = 0;

	/* read object name from lua stack */
	char *Object  = lua_tostring(L, -1) ;


	nRet = set_cgi_option(L, Object, "get");

	/* return param number */
	return 2;
}

static int set_module_cfg(lua_State *L)
{
	int nRet = 0;

	/* read object name from lua stack */
	char *Object  = lua_tostring(L, -1) ;

	nRet = set_cgi_option(L, Object, "set");

	/* return param number */
	return 1;
}

static int add_module_cfg(lua_State *L)
{
	int nRet = 0;

	/* read object name from lua stack */
	char *Object  = lua_tostring(L, -1) ;

	nRet = set_cgi_option(L, Object, "add");

	/* return param number */
	return 1;
}

static int del_module_cfg(lua_State *L)
{
	int nRet = 0;

	/* read object name from lua stack */
	char *Object  = lua_tostring(L, -1) ;

	nRet = set_cgi_option(L, Object, "del");

	/* return param number */
	return 1;
}

static int do_module_cfg(lua_State *L)
{
	int nRet = 0;

	/* read object name from lua stack */
	char *Object  = lua_tostring(L, -1) ;

	nRet = do_cgi(L, Object);

	/* return param number */
	return 1;
}

/*=============================================================================
 * Function Name : module_cfg_lib
 * Description   : Define get,set,add,del four cgi function
 *===========================================================================*/
static const struct luaL_Reg module_cfg_lib[] = {
	{"get_conf", get_module_cfg},
	{"set_conf", set_module_cfg},
	{"add_conf", add_module_cfg},
	{"del_conf", del_module_cfg},
	{"do_conf", do_module_cfg},
	{NULL, NULL}
};

/*=============================================================================
 * Function Name : luaopen_luci_adapter
 * Description   : Register lua c lib function
 *===========================================================================*/
LUALIB_API int luaopen_luci_adapter_libphi_cgi(lua_State *L)
{
	luaL_register(L, "libphi_cgi", module_cfg_lib);
	return 1;
}
