#ifndef NV_VPN_CLIENT_H_
#define NV_VPN_CLIENT_H_

#include <stdlib.h>
#include <string.h>
#include <bcmparams.h>
#include <bcmconfig.h>
#include <bcmnvram.h>

typedef struct vpnc_config_t {
    int enabled;
    char *status;
    char *name;
    char *id;
} vpnc_config_t;

typedef struct vpnc_account_t {
    int enabled;
    char *id;
    char *name;
    char *protocol;
    char *peer;
    char *user;
    char *password;
} vpnc_account_t;

typedef vpnc_account_t * vpnc_account_ptr;

#define member_object_copy(o, m, v, fn) do {    \
        (o)->m = fn(v);                         \
    } while (0)

#define member_object_replace(o, m, v, fn_free, fn_dup) do {    \
        if ((o)->m)                                             \
            fn_free((o)->m);                                    \
        member_object_copy((o), m, (v), fn_dup);                \
    } while (0)

#define member_string_replace(o, m, v)                  \
    member_object_replace((o), m, (v), free, strdup)


#define vpnc_account_enabled(a) ((a)->enabled)
#define vpnc_account_set_enabled(a, e) ({(a)->enabled = (e);})

#define vpnc_account_id(a) ((a)->id)
#define vpnc_account_set_id(a, i) member_string_replace((a), id, (i))

#define vpnc_account_name(a) ((a)->name)
#define vpnc_account_set_name(a, n) member_string_replace((a), name, (n))

#define vpnc_account_proto(a) ((a)->protocol)
#define vpnc_account_set_proto(a, p) member_string_replace((a), protocol, (p))

#define vpnc_account_peer(a) ((a)->peer)
#define vpnc_account_set_peer(a, p) member_string_replace((a), peer, (p))

#define vpnc_account_user(a) ((a)->user)
#define vpnc_account_set_user(a, u) member_string_replace((a), user, (u))

#define vpnc_account_password(a) ((a)->password)
#define vpnc_account_set_password(a, p) member_string_replace((a), password, (p))


#define vpnc_account_new() ((vpnc_account_ptr)calloc(1, sizeof(vpnc_account_t)))
void vpnc_account_release(vpnc_account_ptr);

vpnc_account_ptr *vpnc_setup_accounts_dump(int *count);
int vpnc_setup_account_add(vpnc_account_ptr new_item);
int vpnc_setup_account_set(vpnc_account_ptr item);
int vpnc_setup_account_del(const char *name);
int vpnc_setup_account_del_byid(int id);
int vpnc_setup_account_get_byid(int id, vpnc_account_ptr *account);
int vpnc_setup_account_get_byname(const char *name, vpnc_account_ptr *account);

#endif
