#ifndef _LIBPHI_CGI_H_
#define _LIBPHI_CGI_H_

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <shutils.h>
#include <bcmparams.h>
#include <bcmconfig.h>
#include <bcmnvram.h>
#include "json.h"

#define NV_SUCCESS 0
#define NV_FAIL -1

#define CGI_DEBUG 1
#ifdef CGI_DEBUG
#define cgi_debug(fmt, args...) cprintf("(%s:%d)=> " fmt, __FUNCTION__, __LINE__, ## args)
#else
#define cgi_debug(fmt, args...)
#endif

/*****************cgi function*********************/

/****LAN设置****/
extern  int get_lan_conf(json_object *object);
extern  int set_lan_conf(json_object *object);

/****WAN设置****/
extern  int get_wan_conf(json_object *object);
extern  int set_wan_conf(json_object *object);
extern  int get_static_conf(json_object *object);
extern  int set_static_conf(json_object *object);
extern  int get_dhcp_conf(json_object *object);
extern  int set_dhcp_conf(json_object *object);
extern  int get_pppoe_conf(json_object *object);
extern  int set_pppoe_conf(json_object *object);
extern  int get_wan_status_conf(json_object *object);

//2 Guest Network Setting
extern int get_guest_network_conf(json_object * object);
extern int set_guest_network_conf(json_object * object);

/****密码设置****/
extern  int get_password_conf(json_object *object);
extern  int set_password_conf(json_object *object);

/****首次配置密码设置****/
extern  int get_welcome_password_conf(json_object *object);
extern  int set_welcome_password_conf(json_object *object);

/****安全设置****/
extern  int get_safe_set_conf(json_object *object);
extern  int set_safe_set_conf(json_object *object);

/****运行状态****/
extern int get_info_conf(json_object *object);
extern int get_wifi_2g_status_conf(json_object *object);
extern int get_wifi_5g_status_conf(json_object *object);

/****远程管理****/
extern int get_remote_manager_conf(json_object *object);
extern int set_remote_manager_conf(json_object *object);

/****终端管理****/
extern int get_device_mng_conf(json_object *object);
extern int set_device_mng_conf(json_object *object);

/****UPNP****/
extern int get_upnp_config_conf(json_object *object);
extern int set_upnp_config_conf(json_object *object);
extern int get_upnp_list_conf(json_object *object);

/****屏幕显示****/
extern int get_screen_set_conf(json_object *object);
extern int set_screen_set_conf(json_object *object);

/****家长控制****/
extern int get_parent_ctrl_config_conf(json_object *object);
extern int set_parent_ctrl_config_conf(json_object *object);

extern int get_parent_ctrl_list_conf(json_object *object);
extern int set_parent_ctrl_list_conf(json_object *object);
extern int add_parent_ctrl_list_conf(json_object *object);
extern int del_parent_ctrl_list_conf(json_object *object);

/**** DHCP Server ****/
int get_dhcpd_conf(json_object *object);
int set_dhcpd_conf(json_object *object);

/**** ip mac bind ****/
int get_bind_list(json_object *object);
int set_bind_list(json_object *object);
int add_bind_list(json_object *object);
int del_bind_list(json_object *object);

/**** DMZ ****/
extern int get_firewall_dmz_conf(json_object *object);
extern int set_firewall_dmz_conf(json_object *object);

/****定时重启****/
extern int get_time_reboot_conf(json_object *object);
extern int set_time_reboot_conf(json_object *object);

/**** 无线设置 ****/
extern int get_smart_connect(json_object *object);
extern int set_smart_connect(json_object *object);
extern int get_wifi_2g(json_object *object);
extern int set_wifi_2g(json_object *object);
extern int get_wifi_5g(json_object *object);
extern int set_wifi_5g(json_object *object);

/*** VPN Client ***/
extern int get_vpnc_conf(json_object *object);
extern int set_vpnc_conf(json_object *object);
extern int get_vpnc_accounts(json_object *object);
extern int set_vpnc_account(json_object *object);
extern int add_vpnc_account(json_object *object);
extern int del_vpnc_account(json_object *object);

/*****************action function*******************/

extern void do_reboot(void);
extern void rc_restart(void);
extern void close_redirect(void);

#endif
