#!/bin/sh
option_file_l2tp=/tmp/xl2tpd.options
config_file_l2tp=/tmp/xl2tpd.conf

option_file_pptp=/tmp/pptpd.options

start () {
    # Get vpn_client.config
    g_vpnc_enabled=$(nvram get vpnc_enable)
    g_vpnc_name="$(nvram get vpnc_name)"
    g_vpnc_id=$(nvram get vpnc_id)

    # Get vpnc account
    g_account_id=$g_vpnc_id
    g_account_name=$g_vpnc_name
    g_account_protocol=$(nvram get vpnc"$g_account_id"_proto)
    g_account_peer=$(nvram get vpnc"$g_account_id"_peer)
    g_account_user=$(nvram get vpnc"$g_account_id"_user)
    g_account_password=$(nvram get vpnc"$g_account_id"_password)

    if [ "$g_vpnc_enabled" == "0" ]; then
        return 1
    fi

    if [ "$account_protocol" == "l2tp" ]; then
        start_l2tp
    elif [ "$account_protocol" == "pptp" ]; then
        start_pptp
    else
        logger -s "Unsupported VPN protocol!"
    fi
}

stop () {
    stop_pptp
    stop_l2tp
}

restart() {
    stop
    start
}

start_l2tp() {
    if [ ! -d /var/run/xl2tpd ]; then
        mkdir -p /var/run/xl2tpd
    fi

    build_config_file_for_l2tp
    xl2tpd -c $config_file_l2tp
    g_l2tp_tunnel=default
    echo "c $g_l2tp_tunnel" > /var/run/xl2tpd/l2tp-control
}

stop_l2tp() {
    killall -9 xl2tpd
}

build_config_file_for_l2tp () {
    g_target=$config_file_l2tp
    > $g_target
    g_append [global]
    g_append port 1701
    g_append access control = no
    g_append rand source = dev
    g_append $newline
    g_append [lac l2tpd]
    g_append pppoptfile = $option_file_l2tp
    g_append lns = $g_account_peer
    g_append name = default
    g_append require authentication = no
    g_append tunnel rws = 8
    g_append autodial = yes
    g_append redial = yes
    g_append redial timeout = 15
    g_append tx bps = 100000000
    g_append rx bps = 100000000

    g_target=$option_file_l2tp
    > $g_target
    g_append noauth
    g_append user $g_account_user
    g_append password $g_account_password
    g_append refuse-eap
    g_append mtu 1450
    g_append mru 1450
    g_append maxfail 0
    g_append holdoff 10
    g_append ipcp-accept-remote ipcp-accept-local
    g_append noipdefault
    g_append usepeerdns
    g_append default-asyncmap
    g_append nopcomp noaccomp
    g_append novj nobsdcomp nodeflate
    g_append lcp-max-terminate 0
    g_append lcp-echo-interval 20
    g_append lcp-echo-failure 6
    g_append unit 5
    g_append ktune
}

start_pptp() {
    pppd pty "pptp $g_account_peer --nolaunchpppd" \
         file "$option_file_pptp" \
         remotename default \
         ipparam pptp \
         name $g_account_user \
         password $g_account_password
}

stop_pptp() {
    killall -9 pptp
}

restart_pptp() {
    stop_pptp
    start_pptp
}

build_config_file_for_pptp() {
    g_target=$option_file_pptp
    > $g_target
    g_append lock
    g_append noauth
    g_append nobsdcomp
    g_append nodeflate
    g_append refuse-pap
    g_append refuse-eap
    g_append refuse-chap
    g_append refuse-mschap
    #g_append require-mppe-128

}

g_append () {
    if [ -z "$g_target" ]; then return; fi
    echo "$*" >> $g_target
}

$1

exit $?
