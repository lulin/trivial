#include "libphi_cgi.h"
#include <oid.h>
#include <notify.h>

/*=============================================================================
 * Function Name : get_firewall_dmz_conf
 * Description   : Use nvram handler function to get confs,
 *                 return error_code and output confs in the json object format
 * Format        :
{
	"enable" : "1",
	"ip" : "192.168.2.110"
}
 * Description   : Use nvram handler function to get confs,return success or fail
 *===========================================================================*/
int get_firewall_dmz_conf(json_object *object)
{
	int ret = NV_SUCCESS;

	json_object *myobject = NULL;
	myobject = json_object_new_object();
	if(NULL == myobject)
	{
		ret = NV_FAIL;
		cgi_debug("creat json fail.\n");
		return ret;
	}

	json_object_object_add(myobject,"enable",json_object_new_string(nvram_safe_get("dmz_en")));
	json_object_object_add(myobject,"ip",json_object_new_string(nvram_safe_get("dmz_ipaddr")));

	json_object_object_add(object,"confs",myobject);

	return ret;
}

/*=============================================================================
 * Function Name : set_remote_manager_conf
 * Description   : Use nvram handler function to get confs,
 *                 return error_code and output confs in the json object format
 * Para Format   :
{
	"enable" : "1",
	"ip" : "192.168.2.110"
}
 * Description   : Use nvram handler function to get confs,return success or fail
 *===========================================================================*/
int set_firewall_dmz_conf(json_object *object)
{
	int ret = NV_SUCCESS;
	char enable[3] = {0};
	char ip[32] = {0};

	json_object_object_foreach(object, key, val)
	{
		if(!strcmp(key, "enable"))
		{
			strncpy(enable, json_object_get_string(val), sizeof(enable));
		}
		else if(!strcmp(key, "ip"))
		{
			strncpy(ip, json_object_get_string(val), sizeof(ip));
		}
		else
		{
			//do nothing
		}
	}

	if(0 == strlen(enable))
	{
		ret = NV_FAIL;
		cgi_debug("the dmz enable is empty.\n");
		return ret;
	}

	if(0 == strncmp(enable, "1", sizeof(enable)))
	{
		nvram_set("dmz_en", enable);
		nvram_set("dmz_ipaddr", ip);
	}
	else
	{
		nvram_set("dmz_en", enable);
	}

	nvram_commit();
	notification_send_rc(OID_NETWORK_DMZ, NOTIFY_WAIT);

	return ret;
}

