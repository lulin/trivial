#include "libphi_cgi.h"
#include <wlutils.h>
#include <wlif_utils.h>

#define DOMAIN "p.to"
#define SAFE_MODE_WPA "1"
#define SAFE_MODE_NONE "0"
#define CHANNEL_2 0
#define CHANNEL_5 1

/*=============================================================================
 * Function Name : get_info_conf
 * Description   : Use nvram handler function to get confs,
 *                 return error_code and output confs in the json object format
 * Format        :
{
	"uptime" : "3600",
	"sw_ver" : "21.4.17.157",
	"hw_ver" : "A1",
	"model" : "K3",
	"domain" : "p.to",
	"mac" : "00:11:22:33:44:55",
	"hw_id" : "297f3079eff5d0c277bd942e9f138b30",
	"product_id" : "671acc6fd3121424524ef8de8706b567"
}
 * Description   : Use nvram handler function to get confs,return success or fail
 *===========================================================================*/
int get_info_conf(json_object *object)
{
	int ret = NV_SUCCESS;
	char *uptime = file2str("/proc/uptime");
	char upTime[128] = {0};

	json_object *myobject = NULL;
	myobject = json_object_new_object();
	if(NULL == myobject)
	{
		ret = NV_FAIL;
		cgi_debug("creat json fail.\n");
		return ret;
	}

	if(uptime)
	{
		snprintf(upTime, sizeof(upTime), "%d", atoi(uptime));
		free(uptime);
	}
	else
	{
		ret =NV_FAIL;
		cgi_debug("get uptime fail.\n");
		return ret;
	}

	json_object_object_add(myobject,"uptime",json_object_new_string(upTime));
	json_object_object_add(myobject,"sw_ver",json_object_new_string(nvram_safe_get("fw_version")));
	json_object_object_add(myobject,"hw_ver",json_object_new_string(nvram_safe_get("hd_version")));
	json_object_object_add(myobject,"model",json_object_new_string(nvram_safe_get("product")));
	json_object_object_add(myobject,"domain",json_object_new_string(DOMAIN));
	json_object_object_add(myobject,"mac",json_object_new_string(nvram_safe_get("et0macaddr")));
	json_object_object_add(myobject,"hw_id",json_object_new_string(nvram_safe_get("hw_id")));
	json_object_object_add(myobject,"product_id",json_object_new_string(nvram_safe_get("product_id")));

	json_object_object_add(object,"confs",myobject);

	return ret;
}

int wl_phytype_getByname(int *phytype, char *name)
{
	/* Get configured phy type */
	wl_ioctl(name, WLC_GET_PHYTYPE, phytype, sizeof(int));

	return 0;
}

/*=========================================================================
 * Function Name : wl_cur_channel
 * Decscription  :
 *          type : 0 stands for 2.4G
 *                 1 stands for 5G
 * Return Decs   : get wireless current channel
 *========================================================================*/
int wl_cur_channel(int type)
{
	char *name = NULL;
	char ifname[16] = {0};
	channel_info_t ci;
	int phytype;
	uint32 chanspec;
	int channel;
	int chan_adj = 0;
	int status;
	uint32 chanim_enab = 0;
#define CHANIMSTR(a, b, c, d) ((a) ? ((b) ? c : d) : "")

	switch (type)
	{
		case CHANNEL_2:
			// wisp 2.4G
			if((!strcmp(nvram_safe_get("ure_disable"),"0")) && (!strcmp(nvram_safe_get("frequency"),"0")))
			{
				strncpy(ifname, "wl0.1_ifname", sizeof(ifname));
			}
			else
			{
				strncpy(ifname, "wl0_ifname", sizeof(ifname));
			}
			break;
		case CHANNEL_5:
			// wisp 5G
			if((!strcmp(nvram_safe_get("ure_disable"),"0")) && (!strcmp(nvram_safe_get("frequency"),"1")))
			{
				strncpy(ifname, "wl1.1_ifname", sizeof(ifname));
			}
			else
			{
				strncpy(ifname, "wl1_ifname", sizeof(ifname));
			}
			break;
		default:
			break;
	}

	if(0 == strlen(ifname))
	{
		cgi_debug("get wl ifname fail.\n");
		return -1;
	}

	name = nvram_safe_get(ifname);

	/* Get configured phy type */
	if ((status = wl_phytype_getByname(&phytype, name)) != 0)
	{
		return status;
	}

	if (wl_iovar_getint(name, "chanim_enab", (int*)(void*)&chanim_enab))
	{
		chanim_enab = 0;
	}

	if ((phytype != WLC_PHY_TYPE_N) && (phytype != WLC_PHY_TYPE_SSN) &&
		(phytype != WLC_PHY_TYPE_LCN) && (phytype != WLC_PHY_TYPE_HT))
	{
		wl_ioctl(name, WLC_GET_CHANNEL, &ci, sizeof(ci));
		channel = ci.target_channel;
		chanspec = CH20MHZ_CHSPEC(channel);
	}
	else
	{
		if (wl_iovar_getint(name, "chanspec", (int*)(void *)&chanspec))
			return -1;
		if ((chanspec & WL_CHANSPEC_BW_MASK) == WL_CHANSPEC_BW_40) {
			int sb = chanspec & WL_CHANSPEC_CTL_SB_MASK;
			if (sb == WL_CHANSPEC_CTL_SB_LOWER)
				chan_adj = -2;
			else
				chan_adj = 2;
		}

		channel = CHSPEC_CHANNEL(chanspec);
	}

	return channel+chan_adj;
#undef CHANIMSTR
}

/*=============================================================================
 * Function Name : get_wifi_2g_status_conf
 * Description   : Use nvram handler function to get confs,
 *                 return error_code and output confs in the json object format
 * Format        :
{
	enable = "1",
	ssid = "@PHICOMM_XX",
	safe_mode = "1",
	mode = "0",
	channel = "1",
	mac = "00-11-22-33-44-55"
}
 * Description   : Use nvram handler function to get confs,return success or fail
 *===========================================================================*/
int get_wifi_2g_status_conf(json_object *object)
{
	int ret = NV_SUCCESS;
	int curChannel;
	char enable[2] = {0};
	char ssid[128] = {0};
	char safe_mode[16] = {0};
	char mode[16] = {0};
	char channel[6] = {0};
	char mac[32] = {0};
	char mode_akm[32] = {0};
	json_object *myobject = NULL;

	myobject = json_object_new_object();
	if(NULL == myobject)
	{
		ret = NV_FAIL;
		cgi_debug("creat json fail.\n");
		return ret;
	}

	//wisp 2.4G
	if((!strcmp(nvram_safe_get("ure_disable"),"0")) && (!strcmp(nvram_safe_get("frequency"),"0")))
	{
		strncpy(enable, nvram_safe_get("wl0.1_bss_enabled"), sizeof(enable));
		strncpy(ssid, nvram_safe_get("wl0.1_ssid"), sizeof(ssid));
		strncpy(mode_akm, nvram_safe_get("wl0.1_akm"), sizeof(mode_akm));
		strncpy(mac, nvram_safe_get("wl0.1_hwaddr"), sizeof(mac));
	}
	else
	{
		strncpy(enable, nvram_safe_get("wl0_bss_enabled"), sizeof(enable));
		strncpy(ssid, nvram_safe_get("wl0_ssid"), sizeof(ssid));
		strncpy(mode_akm, nvram_safe_get("wl0_akm"), sizeof(mode_akm));
		strncpy(mac, nvram_safe_get("wl0_hwaddr"), sizeof(mac));
	}

	curChannel = wl_cur_channel(CHANNEL_2);
	if(curChannel < 0)
	{
		ret = NV_FAIL;
		cgi_debug("get 2.4G channel fail.\n");
		return ret;
	}
	snprintf(channel, sizeof(channel), "%d", curChannel);

	if(0 == strlen(mode_akm))
	{
		strncpy(safe_mode, SAFE_MODE_NONE, sizeof(safe_mode));
	}
	else
	{
		strncpy(safe_mode, SAFE_MODE_WPA, sizeof(safe_mode));
	}

	strncpy(mode, nvram_safe_get("pc_show_2_mode"), sizeof(mode));

	json_object_object_add(myobject,"enable",json_object_new_string(enable));
	json_object_object_add(myobject,"ssid",json_object_new_string(ssid));
	json_object_object_add(myobject,"safe_mode",json_object_new_string(safe_mode));
	json_object_object_add(myobject,"mode",json_object_new_string(mode));
	json_object_object_add(myobject,"channel",json_object_new_string(channel));
	json_object_object_add(myobject,"mac",json_object_new_string(mac));

	json_object_object_add(object,"confs",myobject);
	return ret;
}


/*=============================================================================
 * Function Name : get_wifi_5g_status_conf
 * Description   : Use nvram handler function to get confs,
 *                 return error_code and output confs in the json object format
 * Format        :
{
	enable = "1",
	ssid = "@PHICOMM_XX_5G",
	safe_mode = "1",
	mode = "0",
	channel = "149",
	mac = "00-11-22-33-44-55"
}
 * Description   : Use nvram handler function to get confs,return success or fail
 *===========================================================================*/
int get_wifi_5g_status_conf(json_object *object)
{
	int ret = NV_SUCCESS;
	int curChannel;
	char enable[2] = {0};
	char ssid[128] = {0};
	char safe_mode[16] = {0};
	char mode[16] = {0};
	char channel[6] = {0};
	char mac[32] = {0};
	char mode_akm[32] = {0};
	json_object *myobject = NULL;

	myobject = json_object_new_object();
	if(NULL == myobject)
	{
		ret = NV_FAIL;
		cgi_debug("creat json fail.\n");
		return ret;
	}

	//wisp 5G
	if((!strcmp(nvram_safe_get("ure_disable"),"0")) && (!strcmp(nvram_safe_get("frequency"),"1")))
	{
		strncpy(enable, nvram_safe_get("wl1.1_bss_enabled"), sizeof(enable));
		strncpy(ssid, nvram_safe_get("wl1.1_ssid"), sizeof(ssid));
		strncpy(mode_akm, nvram_safe_get("wl1.1_akm"), sizeof(mode_akm));
		strncpy(mac, nvram_safe_get("wl1.1_hwaddr"), sizeof(mac));
	}
	else
	{
		strncpy(enable, nvram_safe_get("wl1_bss_enabled"), sizeof(enable));
		strncpy(ssid, nvram_safe_get("wl1_ssid"), sizeof(ssid));
		strncpy(mode_akm, nvram_safe_get("wl1_akm"), sizeof(mode_akm));
		strncpy(mac, nvram_safe_get("wl1_hwaddr"), sizeof(mac));
	}

	curChannel = wl_cur_channel(CHANNEL_5);
	if(curChannel < 0)
	{
		ret = NV_FAIL;
		cgi_debug("get 5G channel fail.\n");
		return ret;
	}
	snprintf(channel, sizeof(channel), "%d", curChannel);

	if(0 == strlen(mode_akm))
	{
		strncpy(safe_mode, SAFE_MODE_NONE, sizeof(safe_mode));
	}
	else
	{
		strncpy(safe_mode, SAFE_MODE_WPA, sizeof(safe_mode));
	}

	strncpy(mode, nvram_safe_get("pc_show_5_mode"), sizeof(mode));

	json_object_object_add(myobject,"enable",json_object_new_string(enable));
	json_object_object_add(myobject,"ssid",json_object_new_string(ssid));
	json_object_object_add(myobject,"safe_mode",json_object_new_string(safe_mode));
	json_object_object_add(myobject,"mode",json_object_new_string(mode));
	json_object_object_add(myobject,"channel",json_object_new_string(channel));
	json_object_object_add(myobject,"mac",json_object_new_string(mac));

	json_object_object_add(object,"confs",myobject);
	return ret;
}


