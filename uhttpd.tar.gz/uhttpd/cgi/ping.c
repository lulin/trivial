#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <errno.h>
#include <unistd.h>
#include <limits.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/types.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <sys/time.h>
#include <netinet/ip_icmp.h>
#include <signal.h>
#include <setjmp.h>
#include <resolv.h>
#define MAX_SIZE 1024
static char send_buf[MAX_SIZE];
static char recv_buf[MAX_SIZE];
int nsend = 0,nrecv = 0;
int datalen = 56;
#if 0
void statistics(int signum)
{
    printf("\n----------------PING statistics---------------\n");
    printf("%d packets transmitted,%d recevid,%%%d lost\n",nsend,nrecv,(nsend - nrecv)/nsend * 100);
    exit(EXIT_SUCCESS);
}
#endif
int calc_chsum(unsigned short *addr,int len)
{
    int sum = 0,n = len;
    unsigned short answer = 0;
    unsigned short *p = addr;

    while(n > 1)
    {
        sum += *p ++;
        n -= 2;
    }
    if(n == 1)
    {
        *((unsigned char *)&answer) = *(unsigned char *)p;
        sum += answer;
    }

    sum = (sum >> 16) + (sum & 0xffff);

    sum += sum >> 16;
    answer = ~sum;

    return answer;
}


int pack(int pack_num)
{
    int packsize;
    struct icmp *icmp;
    struct timeval *tv;

    icmp = (struct icmp *)send_buf;
    icmp->icmp_type = ICMP_ECHO;
    icmp->icmp_code = 0;
    icmp->icmp_cksum = 0;
    icmp->icmp_id = htons(getpid());
    icmp->icmp_seq = htons(pack_num);
    tv = (struct timeval *)icmp->icmp_data;

    if(gettimeofday(tv,NULL) < 0)
    {
        perror("Fail to gettimeofday");
        return -1;
    }

    packsize = 8 + datalen;
    icmp->icmp_cksum = calc_chsum((unsigned short *)icmp,packsize);

    return packsize;
}


int send_packet(int sockfd,struct sockaddr *paddr)
{
    int packsize;

    memset(send_buf,'a',sizeof(send_buf));
    nsend ++;

    packsize = pack(nsend);
    if(sendto(sockfd,send_buf,packsize,0,paddr,sizeof(struct sockaddr)) < 0)
	{
		perror("Fail to sendto");
		return -1;
	}

    return 0;
}



struct timeval time_sub(struct timeval *tv_send,struct timeval *tv_recv)
{
    struct timeval ts;

    if(tv_recv->tv_usec - tv_send->tv_usec < 0)
    {
        tv_recv->tv_sec --;
        tv_recv->tv_usec += 1000000;
    }

    ts.tv_sec = tv_recv->tv_sec - tv_send->tv_sec;
    ts.tv_usec = tv_recv->tv_usec - tv_send->tv_usec;

    return ts;
}

int unpack(int len,struct timeval *tv_recv,struct sockaddr *paddr,char *ipname)
{
    struct ip *ip;
    struct icmp *icmp;
    struct timeval *tv_send,ts;
    int ip_head_len;
    float rtt;

    ip = (struct ip *)recv_buf;
    ip_head_len = ip->ip_hl << 2;
    icmp = (struct icmp *)(recv_buf + ip_head_len);
    len -= ip_head_len;
    if(len < 8)
    {
        printf("ICMP packets\'s is less than 8.\n");
        return -1;
    }

    if(ntohs(icmp->icmp_id) == getpid() && icmp->icmp_type == ICMP_ECHOREPLY)
    {
        nrecv ++;
        tv_send = (struct timeval *)icmp->icmp_data;
        ts = time_sub(tv_send,tv_recv);
        rtt = ts.tv_sec * 1000 + (float)ts.tv_usec/1000;
	#if 0
        printf("%d bytes from %s (%s):icmp_req = %d ttl=%d time=%.3fms.\n",
            len,ipname,inet_ntoa(((struct sockaddr_in *)paddr)->sin_addr),ntohs(icmp->icmp_seq),ip->ip_ttl,rtt);
	#endif
		return 0;
    }
    printf("ICMP packets not avaliable.\n");

    return -1;
}
int recv_packet(int sockfd,char *ipname)
{
    int addr_len ,n;
    struct timeval tv;
    struct sockaddr from_addr;
    addr_len = sizeof(struct sockaddr);
    if((n = recvfrom(sockfd,recv_buf,sizeof(recv_buf),MSG_DONTWAIT,&from_addr,&addr_len)) < 0)
    {
        perror("Fail to recvfrom");
        return -1;
    }
    if(gettimeofday(&tv,NULL) < 0)
    {
        perror("Fail to gettimeofday");
        return -1;
    }
    return unpack(n,&tv,&from_addr,ipname);
    //return 0;
}

static sigjmp_buf cloud_jmp_buf;
static void cloudAlarmFunc()
{
    siglongjmp( cloud_jmp_buf, 1);
}

static struct hostent *timeGetHostByName(char *url, int cloudUrlTimeout)
{
    struct hostent *ipHostent = NULL;
	char *domain;
	domain = url;

	if(domain == NULL)
		return NULL;

    signal(SIGALRM, cloudAlarmFunc);
    if ( 0 != sigsetjmp(cloud_jmp_buf, 1))
    {
        alarm(0); //timeout
        signal(SIGALRM, SIG_IGN);
        return NULL;
    }

	res_init();//clear dns cache
    alarm(cloudUrlTimeout);
    ipHostent = gethostbyname2(domain, AF_INET);

    signal( SIGALRM, SIG_IGN);
    return ipHostent;

}



int pingalive(char *ipaddress)
{
    int size = 50 * 1024;
    int sockfd,netaddr;
    //struct protoent *protocol;
    struct hostent *host;
    struct sockaddr_in peer_addr;
	int ret = -1;
	int count = 0;
	int tmp = 10000;
	//printf("pingalive = %s \n", ipaddress);
	#if 0
    if((protocol = getprotobyname("icmp")) == NULL)
    {
        perror("Fail to getprotobyname");
        goto done;
    }
	#endif
    if((sockfd = socket(AF_INET,SOCK_RAW,IPPROTO_ICMP)) < 0)
    {
        perror("Fail to socket");
        goto done;
    }

    //setuid(getuid());

    if(setsockopt(sockfd,SOL_SOCKET,SO_RCVBUF,&size,sizeof(size)) < 0)
    {
        perror("Fail to setsockopt");
        goto done;
    }

    bzero(&peer_addr,sizeof(peer_addr));
    peer_addr.sin_family = AF_INET;

    if((netaddr = inet_addr(ipaddress)) == INADDR_NONE)
    {
		host = timeGetHostByName(ipaddress, 12);
       // if((host = gethostbyname(ipaddress)) == NULL)
        if(host == NULL)
        {
            fprintf(stderr,"unknown host : %s.\n",ipaddress);
            goto done;
        }

        memcpy((char *)&peer_addr.sin_addr,host->h_addr,host->h_length);
    }
	else
	{
        peer_addr.sin_addr.s_addr = netaddr;
    }

    //signal(SIGALRM,statistics);
    //signal(SIGINT,statistics);
    //alarm(5);

   // printf("PING %s(%s) %d bytes of data.\n",ipaddress,inet_ntoa(peer_addr.sin_addr),datalen);
	count = 4;
    while(count--)
    {

        ret = send_packet(sockfd,(struct sockaddr *)&peer_addr);
		if (ret != 0)
			continue;
		if (count ==0)
			usleep(1500000);
		usleep(100000);
		ret = recv_packet(sockfd,ipaddress);
		if (ret == 0)
			break;

        //alarm(5);
		//printf("once again\n");
		//tmp = tmp + 500000;
        //usleep(tmp);
        //sleep(1);
    }

done:
	close(sockfd);
    return ret;
}
