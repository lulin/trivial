/********************************************************************
*  There are some functions add for PPPoE special dial type. Some of the dial types
*  may be dealing with the user name or password even both of them. In order to
*  keep the primary arguments same with intrinsic settings. There may be some temp
*  arguments only define for this functions.
*  FUNCTIONS:
*	int encrypt_user(char *dst, char *src)
*	int encrypt_pwd_chinavnet32(char *dst, char *src)
*	int encrypt_user_chinavnet_31(char *dst, char *src)
*	int encrypt_user_chinavnet32(char *dst, char *src)
*	int encrypt_user_chinavnet25(char *dst, char *src)
*	void upchar(char *str)
*					added by jian.ouyang Phicomm 2012.03.09
*********************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "cypher_tbl.h"

void upchar(char *str)
{
	int i = 0;
	int iloop = strlen(str);

	for(i = 0; i < iloop; i++)
	{
		str[i]=toupper(str[i]);
	}

}

int encrypt_user(char *dst, char *src)
{
	char *username = src;
	int nlen = strlen(src);
	char strA[]="9012345678abcdeABCDEFGHIJKLMNfghijklmnUVWXYZxyzuvwopqrstOPQRST";
	int szint[18]={0x11,0x34,0xC9,0x23,0x75,0x18,0xD7,0xE2,0x12,0x35,0x29,0x2B,0xEC,0xB6,0x23,0x19};
	int ljq1=0,ljq2=0x25;
	int k=0,l=0,q=0;
	char temmp[200];
	char *serile=temmp;
	int i;
	int j;

	for (i=0;i<strlen(username);ljq1=ljq1+5,i++)
	{
		for (j=0;j<strlen(strA);j++)
		{
			if (username[i]==strA[j])
			{
				l=szint[i];
				if (i>=16)
				{
		 		      l=i % 0x10;
		 		      l=szint[l];
				}
				k=ljq2;
				k=k*3;
				l=l^k;
				l=l^ljq1;
				l=l+j;
				l=l % 0x3e;
				serile[i]=strA[l];
				l=l+0x24d9;
				ljq2=l^ljq2;
				break;
			}
		}
		if (j>=strlen(strA))
		{
			serile[i] = username[i];
		}
	}
	serile[nlen]=0x00;
	sprintf(dst, "2:%s",serile);
	return 1;

}

int encrypt_pwd_chinavnet32(char *dst, char *src)
{
	int i,j,k;
	int cypher_table_size = 0;
	int passwd_len = 0;
	char *passwd = src;
	char temp[200] = {0};
	char pwdlocal[200] = {0};
	char code[4];
	char charactor[2] = {0};
	char *serile=temp;

	cypher_table_size = sizeof(stCypherTbl) / sizeof(T_cypherTbl);
	passwd_len = strlen(passwd);
	strcpy(pwdlocal, src);

	for (i=0; i < passwd_len; i ++)
	{
		sprintf(charactor, "%c", pwdlocal[i]);
		for( j=0; j<cypher_table_size; j++)
		{
			if( 0 == strcmp( charactor, (char*)stCypherTbl[j].ucCharactor ) )
			{
				k = i%8;
				sprintf(code, "%0.2x", stCypherTbl[j].ucCode[k]);
				upchar(code);
				strcat(serile, code);
			}
		}
  	}

	sprintf(dst, "%s",serile);
  	return 1;
}


int encrypt_user_chinavnet_31(char *dst, char *src)
{
	char temp[200] = {0};
	char *serile=temp;
	char *a="NJ3r05t949R9jdkdfo4lDLR2Evzl35Rkdl1tggtjofdKRIOkLH888iJkyUkjNNbVvjU84410Keloekri78DJ490I574RjK96HjJt7676554r5tgjhHhBGY78668754631HIUHUggGgyGFY78684Ffhyj6JJBN464335dfDDXZccblpoppytrdrdfGFtrgjii87pdl545";
	int i = 0, iLen = 0;
	unsigned int pre_char=0;
	char account[20];
	sprintf(account,"%s",src);

	iLen = strlen(account);
	for(i=0; i < iLen&&*(account+i)!='@'; i++)
	{
		pre_char=*(account+i)+33*pre_char;
	}

	sprintf(serile, "~%c%s",a[pre_char%200],account);
	sprintf(dst, "%s",serile);

	return 1;
}

int encrypt_user_chinavnet32(char *dst, char *src)
{
	char temp[200] = {0};
	char *serile=temp;

	strcat(serile, "^^");
	strcat(serile, src);

	sprintf(dst, "%s",serile);
	printf("************encrypt user is %s************\n", dst);

	return 1;
}

int encrypt_user_chinavnet25(char *dst, char *src)
{
	char account[20]={0};
	char ShareKey[]="nanchang3.0";
	char strInput[30];    // Storage will be the string MD5 calculation

	long lTime1c=0;
	long LastTimeC=0;
	long lTime1Converted=0; //
	unsigned char ss[4]={0,0,0,0}; // The source data of 1, calculated character format data source for lTime1Converted
       unsigned char ss2[4]={0,0,0,0}; // A part of the MD5 encryption parameters, lTime1c the form of characters
	//   unsigned char ss2[4]={0x0F,0xB0,0x42,0xB7}; // Fixed time test
       //input the username
       sprintf(account,"%s",src);
	time_t tTime;
	//get tTime
	time(&tTime);
	//  At the beginning of treatment time lTime1c results, the first encryption through time calculated
	long long t;
	t=tTime;
	t*=0x66666667;
	t>>=0x20;
	t>>=0x01;
	lTime1c=(long)t;

	// 5 seconds the same dynamic user name
	if(lTime1c <= LastTimeC )
	{
		lTime1c=LastTimeC+1;
	}
	LastTimeC=lTime1c;
	//save LastTimeC

	long t0;
	t0=lTime1c;
	//printf("t1=%08x\n",t1);
	ss2[3]=(t0 & 0xFF);
	ss2[2]=(t0 & 0xFF00)/0x100 ;
	ss2[1]=(t0 & 0xFF0000)/0x10000;
	ss2[0]=(t0 & 0xFF000000)/0x1000000;


	int t1,t2,t3;
	//	t=lTime1c;   //t t0
	t1=t0;
	t2=t0;
	t3=t0;
	t3=t3 << 0x10;
	t1=t1 & 0x0FF00;
	t1= t1 | t3;
	t3 = t0;
	t3 = t3 & 0x0FF0000;
	t2=t2 >> 0x10;
	t3 = t3 | t2;
	t1=t1 << 0x08;
	t3=t3 >> 0x08;
	t1 = t1 | t3;
	lTime1Converted=t1;

	//The source data of 1, calculated character format data source for lTime1Converted
	long tt0;
	tt0=lTime1Converted;
	ss[3]=(tt0 & 0xFF);
	ss[2]=(tt0 & 0xFF00) / 0x100;
	ss[1]=(tt0 & 0xFF0000) / 0x10000;
	ss[0]=(tt0 & 0xFF000000) / 0x1000000;

	//The format specifier initial encryption
	//	int ss[4]={0xB7,0x42,0xB0,0x0F};//for fixed time test
	unsigned char pp[4]={0,0,0,0};
	int j=0,k=0;
	int i = 0;
	for(; i<0x20; i++)
	{
		j = i/0x8;
		k = 3 - (i%0x4);
		pp[k] *= 0x2;
		if(ss[j]%2==1)
		{
			pp[k]++;
		}
		ss[j] /= 2;
	}

	//The format specifier calculation
	unsigned char pf[6]={0,0,0,0,0,0};

	int tt1,tt2;
	tt1=pp[3];
	tt1 /= 0x4;
	pf[0]=tt1;
	tt1=pp[3];
	tt1=tt1 & 0x3;
	tt1*=0x10;
	pf[1]=tt1;
	tt2=pp[2];
	tt2/=0x10;
	tt2=tt2 | tt1;
	pf[1]=tt2;
	tt1=pp[2];
	tt1=tt1 & 0x0F;
	tt1*=0x04;
	pf[2]=tt1;
	tt2=pp[1];
	tt2/=0x40;
	tt2=tt2 | tt1;
	pf[2]=tt2;
	tt1=pp[1];
	tt1=tt1 & 0x3F;
	pf[3]=tt1;
	tt2=pp[0];
	tt2/=0x04;
	pf[4]=tt2;
	tt1=pp[0];
	tt1=tt1 & 0x03;
	tt1*=0x10;
	pf[5]=tt1;

	for(i=0;i<6;i++)
	{
		pf[i]+=0x20;
		if((pf[i])>=0x40)
		{
			pf[i]++;
		}
	}

	for(i=0;i<4;i++)
	{
		strInput[i]=ss2[i];
	}
	//Account : initial treatment
	int len=strlen(account);
	int preLen=0;
	for(i=0; i<len && *(account+i)!='@'; i++)
	{
		strInput[4+i]=account[i];
		preLen++;
	}

	for(i=0; i<11; i++)
	{
		strInput[4+preLen+i]=ShareKey[i];
	}
	strInput[15+preLen]='\0';

	char sRealname[40]="\r0";  //The front two character of username prefix

	//Add six bit format character calculation results
	for(i=0;i<6;i++)
	{
		sRealname[2+i]=pf[i];
	}

	//Join the MD5 algorithm results before two
	char md5Str[33]={0};
	strcpy(md5Str,MD5String(strInput));
	for(i=0;i<2;i++)
	{
	sRealname[8+i]=md5Str[i];
	}
	sRealname[10]='\0';
	//Finally, the original user name to join
	strcat(sRealname,account);
	strcpy(dst,sRealname);

	return 1;
}


