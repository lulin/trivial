#include "libphi_cgi.h"
#include "bcmnvram.h"

/********************************************
Guest Network JSON fromat

"wireless" :
{
	"guest_wifi" :
	{
		"enable" : "1",
		"ssid" : "@PHICOMM_XX",
		"password" : "12345678"
	}
}
********************************************/

int get_guest_network_conf(json_object *object)
{
	int ret = NV_SUCCESS;

	char *guest_enable = NULL;
	char *guest_ssid = NULL;
	char *guset_pwd = NULL;

	json_object *myobject = NULL;

	guest_enable = nvram_safe_get("vis_ssid_enable");
	guest_ssid = nvram_safe_get("vis_ssid");
	guset_pwd = nvram_safe_get("vis_ssid_pwd");

	myobject = json_object_new_object();

	if(guest_enable  && guest_ssid && guset_pwd)
	{
		json_object_object_add(myobject,"enable",json_object_new_string(guest_enable));
		json_object_object_add(myobject,"ssid",json_object_new_string(guest_ssid));
		json_object_object_add(myobject,"password",json_object_new_string(guset_pwd));
		json_object_object_add(object,"confs",myobject);
	}
	else
	{
		ret = NV_FAIL;
	}

	return ret;

}

int set_guest_network_conf(json_object *object)
{
	int ret = NV_SUCCESS;

	char guest_eanble[8] = {0};
	char guest_ssid[68] = {0};
	char guest_pwd[68] = {0};

	bool ischanged = FALSE;

	//char *vis_broadcast_ssid_enable;
	//char *vis_unit;
	char interface_list[NVRAM_MAX_VALUE_LEN] = {0};
	int interface_list_size = sizeof(interface_list);
	char nvtmp[NVRAM_MAX_VALUE_LEN] = {0};
	char prefix[] = "wlXXXXXXXXXX_";
	char vif[64] = {0};
	char tmp[256] = {0};

	json_object_object_foreach(object, key, val)
	{
		if(!strcmp(key, "enable"))
		{
			strcpy(guest_eanble, json_object_get_string(val));
		}
		else if(!strcmp(key, "guest_ssid"))
		{
			strcpy(guest_ssid, json_object_get_string(val));
		}
		else if(!strcmp(key, "guset_pwd"))
		{
			strcpy(guest_pwd, json_object_get_string(val));
		}
		else
		{
			cgi_debug("get invalid key: %s\n", key);
		}
	}

	if(strncmp(guest_eanble,"1",1) == 0)
	{
		if(!nvram_match("vis_ssid_enable", guest_eanble) 
		&& !nvram_match("vis_ssid", guest_ssid) 
		&& !nvram_match("vis_ssid_pwd", guest_pwd))
		{
			ischanged = TRUE;
		}
	}
	else if(strncmp(guest_eanble,"0",1) == 0)
	{
		if(!nvram_match("vis_ssid_enable", guest_eanble))
		{
			ischanged = TRUE;
		}
	}

	if (FALSE == ischanged)
	{
		goto func_eixt;
	}

	if(strncmp(guest_eanble,"1",1) == 0)
	{
		nvram_set("vis_ssid_enable", guest_eanble);
		nvram_set("vis_ssid", guest_ssid);
		nvram_set("vis_ssid_pwd", guest_pwd);

		snprintf(prefix, sizeof(prefix), "wl0.2_");
		snprintf(vif, sizeof(vif), "wl0.2");

		nvram_set("vis_ssid_enable",guest_eanble);
		nvram_set(strcat_r(prefix, "bss_enabled", nvtmp), guest_eanble);

		memset(tmp, 0, sizeof(tmp));
		snprintf(tmp, sizeof(tmp), "%s",nvram_safe_get("lan_ifnames"));
		strncpy(interface_list, tmp, interface_list_size);
		add_to_list(vif, interface_list, interface_list_size);
		nvram_set("lan_ifnames", interface_list);

		memset(tmp, 0, sizeof(tmp));
		snprintf(tmp, sizeof(tmp), "%s",nvram_safe_get("wl0_vifs"));
		strncpy(interface_list, tmp, interface_list_size);
		add_to_list(vif, interface_list, interface_list_size);
		nvram_set("wl0_vifs", interface_list);

		nvram_set(strcat_r(prefix, "ifname", nvtmp), vif);
		nvram_set(strcat_r(prefix, "mode", nvtmp), "ap");
		nvram_set(strcat_r(prefix, "nfra", nvtmp), "1");
		nvram_set(strcat_r(prefix, "radio", nvtmp), "1");
		nvram_set(strcat_r(prefix, "auth", nvtmp), "0");
		nvram_set(strcat_r(prefix, "wep", nvtmp), "disabled");
		nvram_set(strcat_r(prefix, "vifs", nvtmp), vif);
		nvram_set(strcat_r(prefix, "infra", nvtmp), "1");
		nvram_set(strcat_r(prefix, "wpa_gtk_rekey", nvtmp), "0");
		nvram_set(strcat_r(prefix, "net_reauth", nvtmp), "36000");
		nvram_set(strcat_r(prefix, "sta_retry_time", nvtmp), "5");
		nvram_set(strcat_r(prefix, "auth_mode", nvtmp), "none");
		nvram_set(strcat_r(prefix, "closed", nvtmp), "0");
		nvram_set(strcat_r(prefix, "ssid", nvtmp), "@PHICOMM_Guest");
		nvram_set(strcat_r(prefix, "wps_mode", nvtmp), "disabled");
		nvram_set(strcat_r(prefix, "wme", nvtmp), "on");
		nvram_set(strcat_r(prefix, "wmf_bss_enable", nvtmp), "0");
		nvram_set(strcat_r(prefix, "wme_bss_disable", nvtmp), "0");

		nvram_set(strcat_r(prefix, "unit", nvtmp), "0.2");

		nvram_set(strcat_r(prefix, "ssid", nvtmp), guest_ssid);
		nvram_set("vis_ssid", guest_ssid);

		if (*guest_ssid == '\0')
		{
		nvram_set(strcat_r(prefix, "akm", nvtmp), "");
		nvram_set(strcat_r(prefix, "crypto", nvtmp), "");
		}
		else
		{
		nvram_set(strcat_r(prefix, "akm", nvtmp), "psk psk2");
		nvram_set(strcat_r(prefix, "crypto", nvtmp), "tkip+aes");
		}
		nvram_set(strcat_r(prefix, "wpa_psk", nvtmp), guest_pwd);
		nvram_set("vis_ssid_pwd",guest_pwd);
	}
	else
	{
		nvram_set(strcat_r(prefix, "bss_enabled", nvtmp), guest_eanble);
		nvram_set("vis_ssid_enable", guest_eanble); 
	}

	nvram_commit();

	func_eixt:

	return ret;
}

