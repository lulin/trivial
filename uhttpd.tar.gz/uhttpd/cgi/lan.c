#include "libphi_cgi.h"

/*=============================================================================
 * Function Name : get_lan_conf
 * Description   : Use nvram handler function to get confs,
 *                 return error_code and output confs in the json object format
 * Format        :
 *       {
 *           "ip":"192.168.2.1",
 *           "netmask": "255.255.255.0"
 *       }
 * Description   : Use nvram handler function to get confs,return success or fail
 *===========================================================================*/

int get_lan_conf(json_object *object)
{
	int ret = NV_SUCCESS;
	char *lan_ip = NULL;
	char *lan_netmask = NULL;
	lan_ip = nvram_get("lan_ipaddr");
	lan_netmask = nvram_get("lan_netmask");

	json_object *myobject = NULL;
	myobject = json_object_new_object();
	if(lan_ip  && lan_netmask )
	{
		json_object_object_add(myobject,"ip",json_object_new_string(lan_ip));
		json_object_object_add(myobject,"netmask",json_object_new_string(lan_netmask));
		json_object_object_add(object,"confs",myobject);

	}
	else
		ret = NV_FAIL;
	return ret;
}

/*=============================================================================
 * Function Name : set_lan_conf
 * Param         : json object format
 * Format        :
 *       {
 *           "ip":"192.168.2.2",
 *           "netmask": "255.255.255.0"
 *       }
 * Description   : Use nvram handler function to set confs,return success or fail
 *===========================================================================*/

int set_lan_conf(json_object *object)
{
	char lan_ip[32] = {0};
	char lan_netmask[32] = {0};
	int lanChange = 0;
	int lan_gw[4] = {0};
	int lastmode, mlastmode, startip, endip;
	char *mpmode;
	char buf[32] = {0};

	json_object_object_foreach(object, key, val)
	{
        if(!strcmp(key, "ip"))
        {
        	memset(lan_ip,0,sizeof(lan_ip));
        	strcpy(lan_ip, json_object_get_string(val));
		}
		else
		{
			memset(lan_netmask,0,sizeof(lan_netmask));
			strcpy(lan_netmask, json_object_get_string(val));
		}
	}

	if(!nvram_match("lan_ipaddr", lan_ip) || !nvram_match("lan_netmask", lan_netmask))
		lanChange = 1;

	nvram_set("lan_ipaddr", lan_ip);
	nvram_set("lan_netmask", lan_netmask);
	nvram_set("lan_gateway", lan_ip);
	nvram_set("lan_pridns", lan_ip);

	sscanf(lan_ip, "%d.%d.%d.%d", &lan_gw[0], &lan_gw[1], &lan_gw[2], &lan_gw[3]);
	lastmode = lan_gw[3];

	mpmode = strrchr(lan_netmask, '.');
	mpmode ++;
	mlastmode = atoi(mpmode);
	if(mlastmode != 0)
	{
		startip = (lastmode & mlastmode);
		if(255 == startip)
			startip = 254;
		else
			startip +=1;

		lan_gw[3] = startip;
		memset(buf, 0, sizeof(buf));
		snprintf(buf, sizeof(buf), "%d.%d.%d.%d", lan_gw[0], lan_gw[1], lan_gw[2], lan_gw[3]);
		nvram_set("dhcp_start", buf);

		endip = startip +(254 - mlastmode -1);
		lan_gw[3] = endip;
		memset(buf, 0, sizeof(buf));
		snprintf(buf,sizeof(buf), "%d.%d.%d.%d", lan_gw[0], lan_gw[1], lan_gw[2], lan_gw[3]);
		nvram_set("dhcp_end", buf);
	}
	else
	{
		lan_gw[3] = 100;
		memset(buf, 0, sizeof(buf));
		snprintf(buf, sizeof(buf), "%d.%d.%d.%d", lan_gw[0], lan_gw[1], lan_gw[2], lan_gw[3]);
		nvram_set("dhcp_start", buf);

		lan_gw[3] = 150;
		memset(buf, 0, sizeof(buf));
		snprintf(buf, sizeof(buf), "%d.%d.%d.%d", lan_gw[0], lan_gw[1], lan_gw[2], lan_gw[3]);
		nvram_set("dhcp_end", buf);
	}

	if(lanChange)
	{
		nvram_set("dhcpreve_rules", "");
		nvram_set("port_forward_rules", "");
		nvram_set("port_forward_en", "0");
		nvram_set("dmz_en", "0");
		nvram_set("dmz_ipaddr", "");
	}

	nvram_commit();

	return NV_SUCCESS;
}

