#include "libphi_cgi.h"
#include <oid.h>
#include <notify.h>

#define PMLIST "/tmp/pmlist"
#define BUF_SIZE (1024)
#define UPNP_DESCRIPT 0
#define UPNP_PROTOCOL 1
#define UPNP_EXT_PORT 2
#define UPNP_INT_PORT 3
#define UPNP_IP       4
#define UPNP_STATUS   5

/*=============================================================================
 * Function Name : get_upnp_config_conf
 * Description   : Use nvram handler function to get confs,
 *                 return error_code and output confs in the json object format
 * Format        :
{
	"enable" : "1"
}
 * Description   : Use nvram handler function to get confs,return success or fail
 *===========================================================================*/
int get_upnp_config_conf(json_object *object)
{
	int ret = NV_SUCCESS;

	json_object *myobject = NULL;
	myobject = json_object_new_object();
	if(NULL == myobject)
	{
		ret = NV_FAIL;
		cgi_debug("creat json fail.\n");
		return ret;
	}

	json_object_object_add(myobject,"enable",json_object_new_string(nvram_safe_get("upnp_enable")));

	json_object_object_add(object,"confs",myobject);

	return ret;
}

/*=============================================================================
 * Function Name : set_upnp_config_conf
 * Description   : Use nvram handler function to get confs,
 *                 return error_code and output confs in the json object format
 * Para Format   :
{
	"enable" : "1",
}
 * Description   : Use nvram handler function to get confs,return success or fail
 *===========================================================================*/
int set_upnp_config_conf(json_object *object)
{
	int ret = NV_SUCCESS;
	char enable[3] = {0};

	json_object_object_foreach(object, key, val)
	{
		if(!strcmp(key, "enable"))
		{
			strncpy(enable, json_object_get_string(val), sizeof(enable));
		}
		else
		{
			//do nothing
		}
	}

	if(0 == strlen(enable))
	{
		ret = NV_FAIL;
		cgi_debug("the upnp enable is empty.\n");
		return ret;
	}

	
	nvram_set("upnp_enable", enable);
	
	nvram_commit();
	notification_send_rc(OID_SERVICE_UPNP, NOTIFY_WAIT);

	return ret;
}

/*=============================================================================
 * Function Name : get_upnp_list_conf
 * Description   : Use nvram handler function to get confs,
 *                 return error_code and output confs in the json object format
 * Format        :
{
	{
		"descript" : "AAAAAA",
		"protocol" : "TCP",
		"external_port" : "100",
		"internal_port" : "200",
		"ip" : "192.168.2.10",
		"status" : "1"
	},
	{
		"descript" : "BBBBBB",
		"protocol" : "UDP",
		"external_port" : "300",
		"internal_port" : "400",
		"ip" : "192.168.2.20",
		"status" : "0"
	}
}
 * Description   : Use nvram handler function to get confs,return success or fail
 *===========================================================================*/
int get_upnp_list_conf(json_object *object)
{
	int ret = NV_SUCCESS;
	int isFirst = 0;
	int iCount = 0;
	FILE *fp = NULL;
	char tmp[BUF_SIZE] = {0};
	char *pmList = NULL;
	char *pChange = NULL;
	char *ptmp = NULL;
	char *pSem = NULL;

	json_object *myobject = NULL;
	json_object *myarray = NULL;

	myarray = json_object_new_array();
	if(NULL == myarray)
	{
		ret = NV_FAIL;
		cgi_debug("creat json array fail.\n");
		return ret;
	}

	pmList = (char *)malloc(BUF_SIZE + 1);
	if(NULL == pmList)
	{
		ret = NV_FAIL;
		cgi_debug("malloc fail.\n");
		return ret;
	}

	// stroe the info that read the information from "/tmp/pmlist"
	// to the pmList
	fp = fopen(PMLIST, "r");
	if(fp)
	{
		while(fread(tmp, 1, BUF_SIZE, fp) != 0)
		{
			if(isFirst)
			{
				pChange = (char *)realloc(pmList, (BUF_SIZE + 1) * (isFirst + 1));
				if(pChange)
				{
					pmList = pChange;
				}
				else
				{
					ret = NV_FAIL;
					cgi_debug("realloc fail.\n");
					free(pmList);
					return ret;
				}
				snprintf(pmList, BUF_SIZE * (isFirst + 1), "%s%s", pmList, tmp);
			}
			else
			{
				strncpy(pmList, tmp, sizeof(tmp));
			}
			memset(tmp, 0x0, sizeof(tmp));
			isFirst++;
		}
	}

	/**************************
	AKDSFJAKLDSJF;TCP;54;34;192.168.2.11;1|adsfadsfasdf;TCP;12;345;192.168.2.12;1|
	descript;protocol;external_port;internal_port;ip;status
	**************************/
	/* analyze pmList */
	while((ptmp = strchr(pmList, '|')) != NULL)
	{
		myobject = json_object_new_object();
		if(NULL == myobject)
		{
			ret = NV_FAIL;
			cgi_debug("creat json fail.\n");
			return ret;
		}
		iCount = 0;
		memset(tmp, 0x0, sizeof(tmp));
		strncpy(tmp, pmList, ptmp - pmList);
		pmList = ptmp + 1;
		pSem = strtok(tmp, ";");
		while(pSem != NULL)
		{
			if(UPNP_DESCRIPT == iCount)
			{
				json_object_object_add(myobject,"descript",json_object_new_string(pSem));
			}
			else if(UPNP_PROTOCOL == iCount)
			{
				json_object_object_add(myobject,"protocol",json_object_new_string(pSem));
			}
			else if(UPNP_EXT_PORT == iCount)
			{
				json_object_object_add(myobject,"external_port",json_object_new_string(pSem));
			}
			else if(UPNP_INT_PORT == iCount)
			{
				json_object_object_add(myobject,"internal_port",json_object_new_string(pSem));
			}
			else if(UPNP_IP == iCount)
			{
				json_object_object_add(myobject,"ip",json_object_new_string(pSem));
			}
			else if(UPNP_STATUS == iCount)
			{
				json_object_object_add(myobject,"status",json_object_new_string(pSem));
			}
			else
			{
				cgi_debug("iCount = %d.\n", iCount);
				//do nothing
			}
			iCount ++;
			pSem = strtok(NULL, ";");
		}
		json_object_array_add(myarray, myobject);
	}

	json_object_object_add(object,"confs",myarray);

	free(pChange);

	return ret;
}

