#include "libphi_cgi.h"
#include <oid.h>
#include <notify.h>

/*=============================================================================
 * Function Name : get_time_reboot_conf
 * Description   : Use nvram handler function to get confs,
 *                 return error_code and output confs in the json object format
 * Format        :
{
	"enable" : "1",
	"reboot_hour" : 0,
	"reboot_minute" : 0
}
 * Description   : Use nvram handler function to get confs,return success or fail
 *===========================================================================*/
int get_time_reboot_conf(json_object *object)
{
	int ret = NV_SUCCESS;

	json_object *myobject = NULL;
	myobject = json_object_new_object();
	if(NULL == myobject)
	{
		ret = NV_FAIL;
		cgi_debug("creat json fail.\n");
		return ret;
	}

	json_object_object_add(myobject,"enable",json_object_new_string(nvram_safe_get("reboot_enable")));
	json_object_object_add(myobject,"reboot_hour",json_object_new_string(nvram_safe_get("reboot_hour")));
	json_object_object_add(myobject,"reboot_minute",json_object_new_string(nvram_safe_get("reboot_minute")));

	json_object_object_add(object,"confs",myobject);

	return ret;
}

/*=============================================================================
 * Function Name : set_time_reboot_conf
 * Description   : Use nvram handler function to get confs,
 *                 return error_code and output confs in the json object format
 * Para Format   :
{
	"enable" : "1",
	"reboot_hour" : 0,
	"reboot_minute" : 0
}
 * Description   : Use nvram handler function to get confs,return success or fail
 *===========================================================================*/
int set_time_reboot_conf(json_object *object)
{
	int ret = NV_SUCCESS;
	char enable[3] = {0};
	char reboot_hour[32] = {0};
	char reboot_minute[32] = {0};

	json_object_object_foreach(object, key, val)
	{
		if(!strcmp(key, "enable"))
		{
			strncpy(enable, json_object_get_string(val), sizeof(enable));
		}
		else if(!strcmp(key, "reboot_hour"))
		{
			strncpy(reboot_hour, json_object_get_string(val), sizeof(reboot_hour));
		}
		else if(!strcmp(key, "reboot_minute"))
		{
			strncpy(reboot_minute, json_object_get_string(val), sizeof(reboot_minute));
		}
		else
		{
			//do nothing
		}
	}

	if(0 == strlen(enable))
	{
		ret = NV_FAIL;
		cgi_debug("the time reboot enable is empty.\n");
		return ret;
	}

	if(0 == strncmp(enable, "1", sizeof(enable)))
	{
		nvram_set("reboot_enable", enable);
		nvram_set("reboot_hour", reboot_hour);
		nvram_set("reboot_minute", reboot_minute);
	}
	else
	{
		nvram_set("reboot_enable", enable);
	}

	nvram_commit();
	notification_send_rc(OID_SERVICE_REBOOT, NOTIFY_WAIT);

	return ret;
}

