#include "libphi_cgi.h"
#include <oui.h>
#include <signal.h>
#include <iconv.h>
#include <proto/ethernet.h>
#include <shutils.h>
#include <dhcpd.h>
#include <bcmutils.h>
#include <bcmnvram.h>

#define RESULTJSON_LEN 100
#define RESULTJSON_LEN_SMALL 80
#define RESULTRULE_LEN 230
#define RULE_NUM 10
#define RULE_LEN 38
#define MAC_LEN 18
#define DEVNAME_LEN 64
#define CYCLE_LEN 7

#define DAY_POS 18
#define STARTTIME_POS 26
#define ENDTIME_POS 32

#define TIME_LEN 3
/**************************added for config section***************************/
/*=============================================================================
 * Function Name : get_parent_ctrl_config_conf
 * Description   : Use nvram handler function to get confs,
 *                 return error_code and output confs in the json object format
 * Format        :
 *       		{
 *           		"enable" : "0"
 *           	}
 * Description   : Use nvram handler function to get confs,return success or fail
 *===========================================================================*/

int get_parent_ctrl_config_conf(json_object *object)
{
	int ret = NV_SUCCESS;
	char* parent_ctrl_en = NULL;

	parent_ctrl_en = nvram_get("parentctl_enable");

	json_object* myobject;
	myobject = json_object_new_object();

	if (parent_ctrl_en)
	{
		json_object_object_add(myobject, "enable", json_object_new_string(parent_ctrl_en));
		json_object_object_add(object, "confs", myobject);
	}
	else
	{
		ret = NV_FAIL;
	}

	return ret;
}

/*=============================================================================
 * Function Name : set_parent_ctrl_config_conf
 * Param         : json object format
 * Format        :
 *       {
 *          "enable" : "0"
 *       }
 * Description   : Use nvram handler function to set confs,return success or fail
 *===========================================================================*/

int set_parent_ctrl_config_conf(json_object *object)
{
	int ret = NV_SUCCESS;
	char enable[4] = {0};

	json_object_object_foreach(object, key, val)
	{
		if (!strcmp(key, "enable"))
		{
			strcpy(enable, json_object_get_string(val));
		}
	}

	char *parentctl_enable = NULL;
	parentctl_enable = nvram_get("parentctl_enable");

	//action: close parent control, delete all rules
	if (!strcmp(enable, "0") && !strcmp(parentctl_enable, "1"))
	{
		nvram_set("parentctl_enable", "0");
		system("parentctl delall");
	}
	//action: open parent control, add all rules
	else if (!strcmp(enable, "1") && !strcmp(parentctl_enable, "0"))
	{
		nvram_set("parentctl_enable", "1");
		system("parentctl addall");
	}
	else
	{
		nvram_set("parentctl_enable", strcmp(enable, "1")?"0":"1");
	}
	nvram_commit();

	return ret;
}


/**************************added for parent_list section*********************/
struct lease_t {
	unsigned char chaddr[16];
	u_int32_t yiaddr;
	u_int32_t expires;
	char hostname[64];
};
int code_convert(char *from_charset, char *to_charset, char *inbuf, size_t inlen, char *outbuf, size_t outlen) {

    iconv_t cd;
    char **pin = &inbuf;
    char **pout = &outbuf;

    cd = iconv_open(to_charset, from_charset);
    if (cd == 0)
        return -1;
    memset(outbuf, 0, outlen);
    if (iconv(cd, pin, &inlen, pout, &outlen) == -1)
  {
        iconv_close(cd);
        return -1;
  }
    iconv_close(cd);
    *pout = '\0';

    return 0;
}
int getTime(const char *strtime)
{
	char time[TIME_LEN] = {0};
	int itime = 0;
	if(NULL == strtime)
	{
		return 0;
	}
	strncpy(time, strtime, TIME_LEN - 1);
	itime = atoi(time);
	memset(time, 0, TIME_LEN);
	strncpy(time, strtime + TIME_LEN, TIME_LEN - 1);
	itime = itime*100 + atoi(time);
	return itime;
}

int getDHCPDevName(const char *mac,char *devname)
{
	// cgi_debug("getDHCPDevName\n");
	if((NULL == devname) || (NULL == mac))
	{
		cgi_debug("parameter error\n");
		return 0;
	}

	FILE *fp = NULL;
	struct lease_t lease;
	int num_interfaces=0;
	char buf[128];
	char sigusr1[] = "-XXXX";
	int index = 0;
    int decode = 0;
    char strmac[MAC_LEN] = {0};
    memset(devname, 0, DEVNAME_LEN/2*3);
	/* Write out leases file */

	// SIGUSR1's default action is the end of the process
//	snprintf(sigusr1, sizeof(sigusr1), "-%d", SIGUSR1);
	snprintf(sigusr1, sizeof(sigusr1), "-%d", SIGCHLD);
	eval("killall", sigusr1, "udhcpd");

	/* Count the number of lan and guest interfaces */

	if (nvram_get("lan_ifname"))
	{
		num_interfaces++;
	}

	if (nvram_get("lan1_ifname"))
	{
		num_interfaces++;
	}
	for (index =0; index < num_interfaces; index++)
	{
		snprintf(buf, sizeof(buf), "/tmp/udhcpd%d.leases", index);
		if (!(fp = fopen(buf, "r")))
			continue;

		while (fread(&lease, sizeof(lease), 1, fp))
		{
			/* Do not display reserved leases */
			// cgi_debug("while\n");
			if (ETHER_ISNULLADDR(lease.chaddr))
				continue;
			lease.hostname[sizeof(lease.hostname) - 1] = '\0';
			// cgi_debug("lease.hostname:%s\n", strmac);
			sprintf(strmac,"%02X:%02X:%02X:%02X:%02X:%02X", lease.chaddr[0], lease.chaddr[1],
				lease.chaddr[2], lease.chaddr[3], lease.chaddr[4], lease.chaddr[5]);
			// cgi_debug("MAC:%s\n", strmac);
			if (!strncmp(strmac, mac, MAC_LEN-1))
			{
				decode = code_convert("gb2312", "utf-8", lease.hostname, strlen(lease.hostname),
					devname, DEVNAME_LEN/2*3);
				// cgi_debug("decode:%d\n",decode);
				if (decode == -1)
				{
					memset(devname, 0, DEVNAME_LEN/2*3);
					strncpy(devname, lease.hostname, DEVNAME_LEN);
				}
				if (strlen(devname) < 1)
				{
					strcpy(devname,"Unknow");
				}
				return 1;
			}
		}
		fclose(fp);
	}
	return 0;
}

int getNameByMAC(const char *mac,char *re_str)
{
    char str_rename[DEVNAME_LEN];
	char temp_rename[DEVNAME_LEN*2] = {0};
	int i = 0;
	int j = 0;
    int rename_len = 0;
	if (NULL == mac || NULL == re_str)
	{
		cgi_debug("error\n");
		return 0;
	}
	memset(re_str, 0, sizeof(re_str));
	char *devname = NULL;
    rename_len = strlen(nvram_safe_get("dev_rename")) + 1;
	devname = (char *)malloc(sizeof(char) * rename_len);
	if(devname == NULL)
	{
		strcpy(re_str, "Unknow");
		free(devname);
		return 0;
	}
	else
	{
		memset(devname, 0, sizeof(char) * rename_len);
		strcpy(devname, nvram_safe_get("dev_rename"));
		char *temp_str = strtok( devname, ";");
		while (temp_str != NULL)
		{
			if (strncmp(mac, temp_str, 17) == 0)
			{
				websDecode64(str_rename, temp_str+18, sizeof(str_rename));
				for (i = 0, j = 0; i < strlen(str_rename); i++)
				{
					if (str_rename[i] == '\"' || str_rename[i] == '\\')
					{
						temp_rename[j++] = '\\';
					}
					temp_rename[j++] = str_rename[i];
				}
				temp_rename[j] = '\0';
				//cgi_debug("temp_rename:%s\n", temp_rename);
				strcpy(re_str, temp_rename);
				free(devname);
				return 1;
			}
			temp_str = strtok(NULL, ";");
		}
		//strcpy(re_str,"Unknow");
		free(devname);
		// return 0;
	}

	if (getDHCPDevName(mac, re_str))
	{
		return 1;
	}
	else
	{
		strcpy(re_str, "Unknow");
		return 0;
	}
}

int getRuleByNum2(const char *rules, const int num,char *rule)
{
	char *tempRules = NULL;
	char *tempRule = NULL;

	int rulesLen = 0;
	int count = 1;

	if ((NULL == rules) || (num < 1) || (num > RULE_LEN) || (NULL == rule))
	{
		cgi_debug("parameter error\n");
		return 0;
	}
	//cgi_debug("rules:%s\n num:%d\n", rules,num);
	rulesLen = strlen(rules) + 1;
	tempRules = (char *)malloc(sizeof(char) * rulesLen);
	if (NULL == tempRules)
	{
		cgi_debug("malloc error\n");
		return 0;
	}
	memset(tempRules, 0, rulesLen);
	strncpy(tempRules, rules, rulesLen - 1);

	tempRule = strtok(tempRules, ";");
	while (NULL != tempRule)
	{
		if (count == num)
		{
			break;
		}
		else
		{
			tempRule = strtok(NULL, ";");
			count++;
		}
	}
	memset(rule, 0, RULE_LEN);
	if (NULL == tempRule)
	{
		strcpy(rule, "");
		cgi_debug("find rule:%s\n", rule);
		free(tempRules);
		return 0;
	}
	else
	{
		strncpy(rule, tempRule, RULE_LEN-1);
		//cgi_debug("find rule:%s\n", rule);
		free(tempRules);
		return 1;
	}
}

/**
 *检查规则时间是否冲突
 *return 0 表示冲突 或出错   1 表示合法
 */
int checkRuleTimeConflict(const char *rules,const char *newRule, const char *originalRule)
{
	if((NULL == rules) || (NULL == newRule) || (NULL == originalRule))
	{
		cgi_debug("parameter error\n");
		return 0;
	}
	char *tempRules = NULL;
	char *tempRule = NULL;
	int rulesLen = 0;
	int i = 0;
	int starttime = 0;
	int endtime = 0;
	int temptime = 0;
	rulesLen = strlen(rules) + 1;

	tempRules = (char *)malloc(sizeof(char) * rulesLen);
	if (NULL == tempRules)
	{
		cgi_debug("malloc error\n");
		return 0;
	}
	memset(tempRules, 0, rulesLen);
	strncpy(tempRules, rules, rulesLen - 1);
	tempRule = strtok(tempRules,";");
	while (NULL != tempRule)
	{
		// 不同规则
		if (strcmp(tempRule, originalRule))
		{
			// cgi_debug("tempRule:%s\n",tempRule);
			// cgi_debug("newrule:%s\n",newRule);
			//相同mac
			if (!strncmp(tempRule, newRule, MAC_LEN - 1))
			{
				for (i = 0; i < 7; ++i)
				{
					//存在相同的一天
					if (tempRule[DAY_POS+i] == newRule[DAY_POS+i] && newRule[DAY_POS+i] == '1')
					{
						starttime = getTime(tempRule + STARTTIME_POS);
						endtime = getTime(tempRule + ENDTIME_POS);
						temptime = getTime(newRule + STARTTIME_POS);
						if (temptime >= starttime && temptime <= endtime)
						{
							free(tempRules);
							return 0;
						}
						starttime = getTime(newRule + STARTTIME_POS);
						endtime = getTime(newRule + ENDTIME_POS);
						temptime = getTime(tempRule + STARTTIME_POS);
						if (temptime >= starttime && temptime <= endtime)
						{
							free(tempRules);
							return 0;
						}
					}
				}
			}
		}
		tempRule = strtok(NULL,";");
	}
	free(tempRules);
	return 1;
}

//update parentctl_rules
//op : add 、del、edit
int updateRules(char *rules, char *op, const char *str1, char *str2)
{
    int i = 0;
    int j = 0;
    int k = 0;
    int tmp = 0;
    int rules_len = 0;
    if ((rules==NULL) || (NULL == op) || (NULL == str1) || (NULL ==str2))
    {
        return 0;
    }
    rules_len = strlen(rules);
    //cgi_debug("rules:%s\n", rules);
    if (!strcmp(op, "add"))
    {
        if ((rules_len + RULE_LEN) < (RULE_LEN * RULE_NUM))
        {
        	if (rules_len != 0)
        	{
                strcat(rules, ";");
            }
            strcat(rules, str1);
            return 1;
        }
        else
        {
            return 0;
        }
    }
    else
    {
        if ((rules_len == RULE_LEN - 1) && !strcmp(op, "del"))
        {
            strcpy(rules, "");
            return 1;
        }
        for (i = 0; i < rules_len; i++)
        {
            if ((rules[i] == ';') || (i == 0))
            {
                if (i == 0)
                {
                    tmp = 0;
                }
                else
                {
                    tmp = i + 1;
                }
                if (!strncmp(rules + tmp, str1, RULE_LEN - 1))
                {
                    if (!strcmp(op, "del"))
                    {
                        for (j = tmp; j < rules_len - RULE_LEN; j++)
                        {
                            rules[j] = rules[j + RULE_LEN];
                        }
                        rules[j] = '\0';
                        return 1;
                    }
                    else
                    {
                        for (j = tmp, k = 0; j < tmp + RULE_LEN - 1; j++, k++)
                        {
                            rules[j] = str2[k];
                        }
                        return 1;
                    }
                }
            }
        }
    }
    return 1;
}
//convert second to hour:minute format,
//if success, return 0, else return 1
int secToHourMin(const char *seconds, char *hour_minute)
{
	if ((NULL == seconds) || (NULL == hour_minute))
	{
		return 1;
	}
	int second = 0;
	int hour = 0;
	int minute = 0;

	second = atoi(seconds);
	hour = second / 3600;
	minute = (second % 3600) / 60;
	if ((hour > 23) || (minute > 59))
	{
		return 1;
	}
	sprintf(hour_minute, "%02d:%02d", hour, minute);

	return 0;
}
//convert hour:minute to seconds(int)
//if success, return 0, else return 1
int HourMintosec(const char* hour_minute, char* sec)
{
	if ((NULL == hour_minute) || (NULL == sec))
	{
		return 1;
	}
	int hour = 0;
	int minute = 0;
	int seconds = 0;
	sscanf(hour_minute, "%d:%d", &hour, &minute);
	if ((hour > 23) || (minute > 59))
	{
		return 1;
	}
	seconds = hour*3600 + minute*60;
	sprintf(sec, "%d", seconds);
	return 0;
}

int getDelRules(const char *rules, char *del_rules, char *strnum)
{
	int num = 0;
	char rule[RULE_LEN] = {0};
	int nums[10] = {0};
	int i = 0;
	int count = 0;
	if((NULL == del_rules) || (NULL == strnum))
	{
		cgi_debug("parameter error\n");
		return 0;
	}
    //cgi_debug("rules:%s\ndel_rules:%s\n,strnum:%s\n", rules, del_rules, strnum);

	memset(del_rules, 0, strlen(rules));
	char *temp_num = strtok(strnum, "|");
	while (NULL != temp_num)
	{
		//cgi_debug("temp_num:%s\n", temp_num);
		num = atoi(temp_num);
		//cgi_debug("num:%d\n", num);
		nums[count++] = num;
		temp_num = strtok(NULL, "|");
	}
	for (i = 0; i < count; ++i)
	{
		if (nums[i] != 0)
		{
			if (getRuleByNum2(rules, nums[i], rule))
			{
				// cgi_debug("del rule:%s\n", rule);
				if (strlen(del_rules) > 0)
				{
					strcat(del_rules, ";");
				}
				strncat(del_rules, rule, RULE_LEN-1);
			}
		}
	}
    // cgi_debug("rules:%s\ndel_rules:%s\n,strnum:%s\n", rules, del_rules, strnum);
    if (strlen(del_rules) < 0)
    {
    	return 0;
    }
    else
    {
		return 1;
    }
}
/*=============================================================================
 * Function Name : get_parent_ctrl_list_conf
 * Description   : Use nvram handler function to get confs,
 *                 return error_code and output confs in the json object format
 * Format        :
 *       {
 *          "id" : "0",
			"name" : "AAAAAA",
			"mac" : "11:22:33:44:55:66",
			"cycle" : "1111111",
			"start_time" : "0",
			"end_time" : "3600",
			"brand": "mi"
 *       }
 * Description   : Use nvram handler function to get confs,return success or fail
 *===========================================================================*/

int get_parent_ctrl_list_conf(json_object *object)
{
	int ret = NV_SUCCESS;

	int rules_len = 0;
	int rule_num = 0;
	char *rules = NULL;

	char id[3] = {0};
	char name[DEVNAME_LEN] = {0};
	char mac[MAC_LEN] = {0};
	char cycle[CYCLE_LEN] = {0};
	char start_time[6] = {0};
	char end_time[6] = {0};
	char brand[32] = {0};

	char temp_rule[RULE_LEN] = {0};
	char temp_rename[DEVNAME_LEN*2]={0};

	int i;
	char start_time_sec[6] = {0};
	char end_time_sec[6] = {0};

	rules_len = strlen(nvram_get("parentctl_rules"));
	rule_num = (rules_len + 1)/RULE_LEN;
	rules = (char *)malloc(sizeof(char) * (rules_len + 1));
	if (NULL == rules)
	{
		ret = NV_FAIL;
		return ret;
	}

	memset(rules, 0, (rules_len + 1));
	strncpy(rules, nvram_get("parentctl_rules"), rules_len);

	oui_handler_t oui;
	oui = load_available_oui();

	// cgi_debug("rules: %s \n", rules);
	// cgi_debug("rules_len: %d , rule_num:%d\n", rules_len, rule_num);

	json_object *arrobject = NULL;
	arrobject = json_object_new_array();

	for (i = 0; i < rule_num; ++i)
	{
		strncpy(temp_rule, rules + i*RULE_LEN, RULE_LEN - 1);
		//get id
		sprintf(id, "%d", i+1);

		//get name
		if (getNameByMAC(temp_rule, temp_rename))
		{
			strcpy(name, temp_rename);
		}
		else
		{
			strcpy(name, "Unknow");
		}

		//get brand
		char tmp_brand[64];
		get_vendor_name(oui, temp_rule, tmp_brand, sizeof(tmp_brand));
		strcpy(brand, tmp_brand);

		//get MAC
		strncpy(mac, temp_rule, MAC_LEN - 1);

		//get cycle
		strncpy(cycle, temp_rule + DAY_POS, CYCLE_LEN);

		//get start_time and end_time, and convert unit to seconds
		strncpy(start_time, temp_rule + STARTTIME_POS, 5);
		HourMintosec(start_time, start_time_sec);
		strncpy(end_time, temp_rule + ENDTIME_POS, 5);
		HourMintosec(end_time, end_time_sec);

		//check parameter is available
		if ((0 != strlen(id)) && (0 != strlen(name)) && (0 != strlen(mac)) && (0 != strlen(cycle)) &&
			(0 != strlen(start_time_sec)) && (0 != strlen(end_time_sec)) && (0 != strlen(brand)))
		{
			json_object *myobject = NULL;
			myobject = json_object_new_object();
			json_object_object_add(myobject, "id", json_object_new_string(id));
			json_object_object_add(myobject, "name", json_object_new_string(name));
			json_object_object_add(myobject, "mac", json_object_new_string(mac));
			json_object_object_add(myobject, "cycle", json_object_new_string(cycle));
			json_object_object_add(myobject, "start_time", json_object_new_string(start_time_sec));
			json_object_object_add(myobject, "end_time", json_object_new_string(end_time_sec));
			json_object_object_add(myobject, "brand", json_object_new_string(brand));
			json_object_array_put_idx(arrobject, i, myobject);
		}
		else
		{
			ret = NV_FAIL;
			return ret;
		}

	}
	free(rules);
	rules = NULL;
	release_oui(oui);

	if (arrobject)
	{
		json_object_object_add(object, "confs", arrobject);
	}
	else
	{
		ret = NV_FAIL;
		return ret;
	}
	// cgi_debug("get formated rules: %s", json_object_get_string(object));
	cgi_debug("get_parent_ctrl_list_conf\n");

	return ret;
}

/*=============================================================================
 * Function Name : set_parent_ctrl_list_conf
 * Param         : json object format
 * Format        :
 *       {
 *           "id" : "0",
			 "name" : "AAAAAA",
			 "mac" : "11:22:33:44:55:66",
			 "cycle" : "1111111",
			 "start_time" : "0",
			 "end_time" : "3600",
			 "brand": "mi"
 *       }
 * Description   : Use nvram handler function to set confs, set one iterm each time
 * 				   return success or fail
 * PS. brand is not necessary here
 *===========================================================================*/
int set_parent_ctrl_list_conf(json_object *object)
{
	int ret = NV_SUCCESS;

	char *rules = NULL;
	char *edit_rule = NULL;
	char *orig_rule = NULL;
	char *temp_buffer = NULL;

	char id[4] = {0};
	char name[128] = {0};
	char mac[32] = {0};
	char cycle[8] = {0};
	char start_time[8] = {0};
	char end_time[8] = {0};
	int rules_len = 0;

	char start_time_tmp[8] = {0};
	char end_time_tmp[8] = {0};

	//used for data collect
	if(!nvram_match("parentctl_used", "1"))
	{
		nvram_set("parentctl_used", "1");
	}

	rules_len = strlen(nvram_get("parentctl_rules"));
	rules = (char *)malloc(sizeof(char) * (rules_len + 1));
	edit_rule = (char *)malloc(sizeof(char) * RULE_LEN);
	orig_rule = (char *)malloc(sizeof(char) * RULE_LEN);
	temp_buffer = (char *)malloc(sizeof(char) * 128);

	if ((NULL == rules) || (NULL == edit_rule) || (NULL == orig_rule) || (NULL == temp_buffer))
	{
		ret = NV_FAIL;
		return ret;
	}
	memset(rules, 0, rules_len + 1);
	memset(edit_rule, 0, RULE_LEN);
	memset(orig_rule, 0, RULE_LEN);
	memset(temp_buffer, 0, 128);
	strncpy(rules, nvram_safe_get("parentctl_rules"), rules_len);

	//get the rule to edit from json
	json_object_object_foreach(object, key, val)
	{
		if (!strcmp(key, "id"))
		{
			strcpy(id, json_object_get_string(val));
		}
		else if (!strcmp(key, "mac"))
		{
			strcpy(mac, json_object_get_string(val));
		}
		else if (!strcmp(key, "name"))
		{
			strcpy(name, json_object_get_string(val));
		}
		else if (!strcmp(key, "cycle"))
		{
			strcpy(cycle, json_object_get_string(val));
		}
		else if (!strcmp(key, "start_time"))
		{
			strcpy(start_time, json_object_get_string(val));
		}
		else if (!strcmp(key, "end_time"))
		{
			strcpy(end_time, json_object_get_string(val));
		}
	}
	//check paras
	if ((0 == strlen(id)) || (0 == strlen(mac)) || (0 == strlen(cycle)) ||
		(0 == strlen(start_time)) || (0 == strlen(end_time)))
	{
		ret = NV_FAIL;
		return ret;
	}
	//build edit_rule string
	secToHourMin(start_time, start_time_tmp);
	secToHourMin(end_time, end_time_tmp);
	snprintf(edit_rule, RULE_LEN, "%s,%s,%s,%s", mac, cycle, start_time_tmp, end_time_tmp);
	if (0 == strlen(edit_rule))
	{
		ret = NV_FAIL;
		return ret;
	}

	//get the ruel for edit by the id
	if (getRuleByNum2(rules, atoi(id), orig_rule))
	{
		// check if edit_rule conflict with orig_rule
		if (checkRuleTimeConflict(rules, edit_rule, orig_rule) == 0)
		{
			ret = NV_FAIL;
			return ret;
		}
		else
		{
			//build the completed rules for saving in nvram
			if (updateRules(rules, "edit", orig_rule, edit_rule))
			{
				sprintf(temp_buffer, "parentctl edit %s %s", edit_rule, orig_rule);
				system(temp_buffer);
				nvram_set("parentctl_rules", rules);
				nvram_set("parentctl_enable", "1");
				nvram_commit();
			}
			else
			{
				ret = NV_FAIL;
				return NV_SUCCESS;
			}
		}
	}
	else
	{
		ret = NV_FAIL;
		return ret;
	}
	free(rules);
	free(edit_rule);
	free(orig_rule);
	free(temp_buffer);
	rules = NULL;
	edit_rule = NULL;
	orig_rule = NULL;
	temp_buffer = NULL;

	cgi_debug("set_parent_ctrl_list_conf\n");
	return ret;
}
/*=============================================================================
 * Function Name : add_parent_ctrl_list_conf
 * Param         : json object format
 * Format        :
 *       {
 *       "id" : "0",
		 "name" : "AAAAAA",
		 "mac" : "11:22:33:44:55:66",
		 "cycle" : "1111111",
		 "start_time" : "0",
		 "end_time" : "3600",
		 "brand": "mi"
 *       }
 * Description   : Use nvram handler function to set confs,return success or fail
 *===========================================================================*/

int add_parent_ctrl_list_conf(json_object *object)
{
	int ret = NV_SUCCESS;

	char *rules = NULL;
	char *newrule = NULL;
	char *temp_buffer = NULL;

	char name[128] = {0};
	char mac[32] = {0};
	char cycle[8] = {0};
	char start_time[8] = {0};
	char end_time[8] = {0};
	int rules_len = 0;

	char start_time_tmp[8] = {0};
	char end_time_tmp[8] = {0};

	if(!nvram_match("parentctl_used", "1"))
	{
		nvram_set("parentctl_used", "1");
	}

	rules_len = strlen(nvram_get("parentctl_rules"));
	rules = (char *)malloc(sizeof(char) * (rules_len + 1 + RULE_LEN));
	newrule = (char *)malloc(sizeof(char) * RULE_LEN);
	temp_buffer = (char *)malloc(sizeof(char) * 64);

	if ((NULL == rules) || (NULL == newrule) || (NULL == temp_buffer))
	{
		ret = NV_FAIL;
		return ret;
	}
	memset(rules, 0, rules_len + 1);
	memset(newrule, 0, RULE_LEN);
	memset(temp_buffer, 0, 64);
	strncpy(rules, nvram_safe_get("parentctl_rules"), rules_len);

	//get the rule to add from web in json formate
	json_object_object_foreach(object, key, val)
	{
		if (!strcmp(key, "mac"))
		{
			strcpy(mac, json_object_get_string(val));
		}
		else if (!strcmp(key, "name"))
		{
			strcpy(name, json_object_get_string(val));
		}
		else if (!strcmp(key, "cycle"))
		{
			strcpy(cycle, json_object_get_string(val));
		}
		else if (!strcmp(key, "start_time"))
		{
			strcpy(start_time, json_object_get_string(val));
		}
		else if (!strcmp(key, "end_time"))
		{
			strcpy(end_time, json_object_get_string(val));
		}
	}

	//check paras
	if ((0 == strlen(name)) || (0 == strlen(mac)) || (0 == strlen(cycle)) ||
		(0 == strlen(start_time)) || (0 == strlen(end_time)))
	{
		ret = NV_FAIL;
		return ret;
	}
	//build new rule string for add
	secToHourMin(start_time, start_time_tmp);
	secToHourMin(end_time, end_time_tmp);
	snprintf(newrule, RULE_LEN, "%s,%s,%s,%s", mac, cycle, start_time_tmp, end_time_tmp);
	if (0 == strlen(newrule))
	{
		ret = NV_FAIL;
		return ret;
	}
	//check time conflict
	if (checkRuleTimeConflict(rules, newrule, "") == 0)
	{
		ret = NV_FAIL;
		return ret;
	}
	//build complete new rules to add into nvram
	if (updateRules(rules, "add", newrule, ""))
	{
		nvram_set("parentctl_rules", rules);
		nvram_set("parentctl_enable", "1");
		nvram_commit();
		snprintf(temp_buffer, 64, "parentctl add %s", newrule);
		system(temp_buffer);
	}
	else
	{
		ret = NV_FAIL;
		return ret;
	}
	free(rules);
	free(newrule);
	free(temp_buffer);
	rules = NULL;
	newrule = NULL;
	temp_buffer = NULL;

	cgi_debug("add_parent_ctrl_list_conf\n");
	return ret;
}

/*=============================================================================
 * Function Name : del_parent_ctrl_list_conf
 * Param         : json object format
 * Format        :
 *       {
 *       "id" : "0",
		 "name" : "AAAAAA",
		 "mac" : "11:22:33:44:55:66",
		 "cycle" : "1111111",
		 "start_time" : "0",
		 "end_time" : "3600",
		 "brand": "mi"
 *       }
 * Description   : Use nvram handler function to set confs,return success or fail
 * PS. actually, only id is needed
 *===========================================================================*/

int del_parent_ctrl_list_conf(json_object *object)
{
	int ret = NV_SUCCESS;

	char *parentctl_rules = NULL;
	char *del_rule = NULL;
	char *temp_buffer = NULL;
	char *del_rules = NULL;
	int parentctl_rules_len = strlen(nvram_safe_get("parentctl_rules"));

	char id[4] = {0};
	//get id from web in json formate
	json_object_object_foreach(object, key, val)
	{
		if (!strcmp(key, "id"))
		{
			strcpy(id, json_object_get_string(val));
		}
	}
	if (NULL == id)
	{
		ret = NV_FAIL;
		return ret;
	}

	del_rules = (char*)malloc(sizeof(char) * parentctl_rules_len);
	parentctl_rules = (char*)malloc(sizeof(char) * parentctl_rules_len);
	del_rule = (char*)malloc(sizeof(char) * RULE_LEN);
	temp_buffer = (char*)malloc(sizeof(char) * 64);
	if ((NULL == del_rules) || (NULL == parentctl_rules) || (NULL == del_rule) || (NULL == temp_buffer))
	{
		ret = NV_FAIL;
		return ret;
	}
	memset(del_rules, 0, parentctl_rules_len);
	memset(parentctl_rules, 0, parentctl_rules_len);
	memset(del_rule, 0, RULE_LEN);
	memset(temp_buffer, 0, 64);

	strcpy(parentctl_rules, nvram_safe_get("parentctl_rules"));

	//del specified rule and generate new rules, then run "parentctl del"
	int k = 0;
	//get the rule to delete from parentctl_rules via id
	if (getDelRules(parentctl_rules, del_rules, id))
	{
		for (k = 0; k < (strlen(del_rules) + 1)/RULE_LEN; ++k)
		{
			memset(del_rule,0,RULE_LEN);
			strncpy(del_rule, del_rules + k * RULE_LEN, RULE_LEN - 1);
			//build the complete rules for delete action the load into nvram
			if (updateRules(parentctl_rules, "del", del_rule, ""))
			{
				nvram_set("parentctl_rules", parentctl_rules);
				nvram_set("parentctl_enable", "1");
				nvram_commit();
				memset(temp_buffer,0,64);
				sprintf(temp_buffer, "parentctl del %s", del_rule);
				system(temp_buffer);
			}
			else
			{
				break;
			}
		}
		if (k != (strlen(del_rules) + 1)/RULE_LEN)
		{
			ret = NV_FAIL;
			return ret;
		}
	}
	else
	{
		ret = NV_FAIL;
		return ret;
	}
	free(temp_buffer);
	free(del_rule);
	free(parentctl_rules);
	free(del_rules);
	temp_buffer = NULL;
	del_rule = NULL;
	parentctl_rules = NULL;
	del_rules = NULL;

	cgi_debug("del_parent_ctrl_list_conf\n");
	return ret;
}
