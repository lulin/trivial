/*
 * If you call the functions listed in this file, please don't forget to link
 * oui.o to your executable, and add the dependency:
 *     oui.o: $(TOP)/shared/oui.c
 *     	$(CC) -c -o $@ $< $(CFLAGS)
 *
 * feixun/uhmi/Makefile is an example.
 */

#ifndef OUI_H_
#define OUI_H_

#include <stdlib.h>

/* paths for download */
#define NEW_OUI_DIR                  "/tmp/oui-update"
#define NEW_OUI                      NEW_OUI_DIR "/vendor.json"
/* the UPDATED OUI paths */
#define UPDATED_OUI_DIR              "/tmp/media/nand/oui"
#define UPDATED_OUI                  UPDATED_OUI_DIR "/vendor.json"
#define UPDATED_OUI_LOCK             UPDATED_OUI_DIR "/lock"
/* the native OUI paths */
#define NATIVE_OUI                   "/etc/oui/vendor.json"

typedef void *oui_handler_t;

/**
 * Load available OUI base. This function first tries to load the <updated OUI>
 * base if it exists, once succeeded, returns an OUI handler for later use.
 * Otherwise, it loads the <native OUI> base.
 *
 * <updated OUI> is the base which could be updated online, while <native OUI> is
 * the base distributed with the firmware. Their paths are defined in @UPDATED_OUI
 * and @NATIVE_OUI.
 *
 * Return value
 * On success, a valid oui_handler_t object is returned, otherwise, NULL is returned.
 */
extern oui_handler_t load_available_oui();

/**
 * Release the resource allocated by load_available_oui().
 */
extern void release_oui(oui_handler_t oui);

/**
 * Given a MAC address, lookup the ID of the vendor who owns the MAC address.
 *
 * The format of @mac is like "AA:BB:CC:DD:EE:FF".
 *
 * Return value
 * For unknown vendors, or the MAC address is not in the ranges in the OUI base,
 * 0 is returned.
 * If a vendor is found, the vendor's ID, a positive number, is returned.
 */
extern int get_vendor_id(oui_handler_t oui, const char *mac);

/**
 * Given a MAC address, lookup the name of the vendor who owns the MAC address.
 *
 * The format of @mac is like "AA:BB:CC:DD:EE:FF".
 * Parameter @buffer is delivered to save the vendor's name, it couldn't be NULL.
 * @size is the size of the @buffer.
 *
 * Return value
 *   0 is returned on success, and @buffer is filled with the name of a vendor.
 * A negative number is returned if some error happens. In ether case of no
 * vendor is found or some error happens, @buffer is filled with "unknown".
 */
extern int get_vendor_name(oui_handler_t oui, const char *mac,
                           char *buffer, size_t size);

#endif
