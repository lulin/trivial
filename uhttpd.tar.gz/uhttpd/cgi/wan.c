#include "libphi_cgi.h"
#include "wan.h"

/* for dhcp\pppoe\static\ common setting */
void set_wan_common(void)
{
	nvram_set("wan0_ipaddr", "");
	nvram_set("wan_ipaddr", "");
	nvram_set("wan0_proto", "");
	nvram_set("wan_proto", "");
	nvram_set("wan0_dns", "");
	nvram_set("wan_dns", "");
	nvram_set("wan0_gateway", "");
	nvram_set("wan_gateway", "");
	nvram_set("wan0_netmask", "");
	nvram_set("wan_netmask", "");

	//set the wan_ifname
	if(nvram_match("ure_disable", "1"))//wisp disable
	{
		nvram_set("wan_ifname", "vlan2");
		nvram_set("wan0_ifnames", nvram_safe_get("wan_ifnames"));
		nvram_set("wan0_ifname", "vlan2");
	}
	else //wisp enable
	{
		//frequency:
		// 0 : 2.4G
		// 1 : 5G
		if(nvram_match("frequency", "0"))
		{
			nvram_set("wan_ifname", "eth1");
			nvram_set("wan0_ifnames", "eth1");
			nvram_set("wan0_ifname", "eth1");
		}
		else if(nvram_match("frequency", "1"))
		{
			nvram_set("wan_ifname", "eth2");
			nvram_set("wan0_ifnames", "eth2");
			nvram_set("wan0_ifname", "eth2");
		}
		nvram_set("wl_config", "1");
	}
}

/*=============================================================================
 * Function Name : get_wan_conf
 * Description   : Use nvram handler function to get confs,
 *                 return error_code and output confs in the json object format
 * Format        :
 *       {
 *           "protocol":"static",
 *           "clone_mode": "1",
 *           "mac": "00:CD:FE:DF:D7:48",
 *           "source_mac": "08:57:00:DE:69:55"
 *       }
 * Description   : Use nvram handler function to get confs,return success or fail
 *===========================================================================*/
int get_wan_conf(json_object *object)
{
	int ret = NV_SUCCESS;
	char mac[32] = {0};
	json_object *myobject = NULL;

	myobject = json_object_new_object();
	if(NULL == myobject)
	{
		ret = NV_FAIL;
		cgi_debug("creat json fail.\n");
		return ret;
	}

	if(nvram_match("mac_clone_enabled", "1"))
	{
		strncpy(mac, nvram_safe_get("wan_hwaddr"), sizeof(mac) - 1);
	}

	json_object_object_add(myobject,"protocol",json_object_new_string(nvram_safe_get("wan_proto")));
	json_object_object_add(myobject,"clone_mode",json_object_new_string(nvram_safe_get("mac_clone_enabled")));
	json_object_object_add(myobject,"mac",json_object_new_string(mac));
	json_object_object_add(myobject,"source_mac",json_object_new_string(nvram_safe_get("et0macaddr")));

	json_object_object_add(object,"confs",myobject);
	return ret;
}

/*=============================================================================
 * Function Name : set_wan_conf
 * Description   : Use nvram handler function to get confs,
 *                 return error_code and output confs in the json object format
 * Para Format   :
 *       {
 *           "protocol":"static",
 *           "clone_mode": "1",
 *           "mac": "00:CD:FE:DF:D7:48",
 *           "source_mac": "08:57:00:DE:69:55"
 *       }
 * Description   : Use nvram handler function to get confs,return success or fail
 *===========================================================================*/
int set_wan_conf(json_object *object)
{
	int ret = NV_SUCCESS;
	char protocol[16] = {0};
	char clone_mode[2] = {0};
	char mac[32] = {0};
	char source_mac[32] = {0};

	json_object_object_foreach(object, key, val)
	{
		if(!strcmp(key, "protocol"))
		{
			strncpy(protocol, json_object_get_string(val), sizeof(protocol));
		}
		else if(!strcmp(key, "clone_mode"))
		{
			strncpy(clone_mode, json_object_get_string(val), sizeof(clone_mode));
		}
		else if(!strcmp(key, "mac"))
		{
			strncpy(mac, json_object_get_string(val), sizeof(mac));
		}
		else if(!strcmp(key, "source_mac"))
		{
			strncpy(source_mac, json_object_get_string(val), sizeof(source_mac));
		}
		else
		{
			//do nothing
		}
	}

	if(strcmp(clone_mode, "0") == 0)
	{
		if(nvram_match("ure_disable", "1")) // wisp diable
		{
			nvram_set("wan_hwaddr", nvram_safe_get("et0macaddr"));
			nvram_set("wan0_hwaddr", nvram_safe_get("et0macaddr"));
		}
		else
		{
			nvram_set("wan_hwaddr", "");
			nvram_set("wan0_hwaddr", "");
		}
		nvram_set( "mac_clone_enabled", "0" );
	}
	else
	{
		nvram_set( "mac_clone_enabled", "1" );
		if(strlen(mac))
		{
			nvram_set("wan_hwaddr", mac);
			nvram_set("wan0_hwaddr", mac);
		}
	}

	nvram_commit();
	return ret;
}


/*=========================================================================
 * Function Name : getDns
 * Decscription  :
 *          type : 0 stands for static
 *                 1 stands for dhcp
 *                 2 stands for pppoe
 *        dnsPri : Primary Dns, we need return
 *        dnsSec : Secondary Dns, we need return
 *========================================================================*/
void getDns(int type, char *dnsPri, char *dnsSec)
{
	char dns1[32] = {0};
	char dns2[32] = {0};
	char dns_buf[64] = {0};
	char *pDns = NULL;

	switch (type)
	{
		case DNS_STATIC:
			pDns = nvram_safe_get("wan0_dns");
			break;
		case DNS_DHCP:
			pDns = nvram_safe_get("wan_dhcp_dns");
			break;
		case DNS_PPPOE:
			pDns = nvram_safe_get("wan_pppoe_dns");
			break;
		case DNS_NONE:
			pDns = nvram_safe_get("wan_dns");
			break;
		default:
			break;
	}

	if(pDns)
	{
		strncpy(dns_buf, pDns, sizeof(dns_buf) - 1);
		pDns = strchr(dns_buf, ' ');
		if(NULL == pDns)
		{
			strncpy(dns1, dns_buf, sizeof(dns1) - 1);
		}
		else
		{
			sscanf(dns_buf, "%s %s", dns1, dns2);
		}

		if('\0' == dns2[0])
		{
			strncpy(dns2, "0.0.0.0", sizeof(dns2));
		}
	}
	else
	{
		strncpy(dns1, "0.0.0.0", sizeof(dns1));
		strncpy(dns2, "0.0.0.0", sizeof(dns2));
	}

	if(strncmp(dns2, "0.0.0.0", sizeof(dns2) - 1) == 0)
	{
		memset(dns2, 0x0, sizeof(dns2));
	}

	strncpy(dnsPri, dns1, strlen(dns1));
	strncpy(dnsSec, dns2, strlen(dns2));

	return;
}


/*=============================================================================
 * Function Name : get_static_conf
 * Description   : Use nvram handler function to get confs,
 *                 return error_code and output confs in the json object format
 * Format        :
 *       {
 *           "ip":"172.17.48.129",
 *           "netmask": "255.255.255.0",
 *           "gateway": "172.17.48.1",
 *           "mtu": "1500",
 *           "dns_mode": "",
 *           "dns_pri": "172.17.10.6",
 *           "dns_sec": "172.17.10.7"
 *     	 }
 * Description   : Use nvram handler function to get confs,return success or fail
 *===========================================================================*/
int get_static_conf(json_object *object)
{
	int ret = NV_SUCCESS;
	char dns1[32] = {0};
	char dns2[32] = {0};
	json_object *myobject = NULL;

	myobject = json_object_new_object();
	if(NULL == myobject)
	{
		ret = NV_FAIL;
		cgi_debug("creat json fail.\n");
		return ret;
	}

	getDns(DNS_STATIC, dns1, dns2);

	json_object_object_add(myobject,"ip",json_object_new_string(nvram_safe_get("wan0_ipaddr")));
	json_object_object_add(myobject,"netmask",json_object_new_string(nvram_safe_get("wan0_netmask")));
	json_object_object_add(myobject,"gateway",json_object_new_string(nvram_safe_get("wan0_gateway")));
	json_object_object_add(myobject,"mtu",json_object_new_string(nvram_safe_get("wan0_static_mtu")));
	json_object_object_add(myobject,"dns_mode",json_object_new_string(""));
	json_object_object_add(myobject,"dns_pri",json_object_new_string(dns1));
	json_object_object_add(myobject,"dns_sec",json_object_new_string(dns2));

	json_object_object_add(object,"confs",myobject);

	return ret;
}

/*=============================================================================
 * Function Name : set_static_conf
 * Description   : Use nvram handler function to get confs,
 *                 return error_code and output confs in the json object format
 * Para Format   :
 *       {
 *           "ip":"172.17.48.129",
 *           "netmask": "255.255.255.0",
 *           "gateway": "172.17.48.1",
 *           "mtu": "1500",
 *           "dns_mode": "",
 *           "dns_pri": "172.17.10.6",
 *           "dns_sec": "172.17.10.7"
 *     	 }
 * Description   : Use nvram handler function to get confs,return success or fail
 *===========================================================================*/
int set_static_conf(json_object *object)
{
	int ret = NV_SUCCESS;
	char ip[32] = {0};
	char netmask[32] = {0};
	char gateway[32] = {0};
	char mtu[16] = {0};
	char dns_mode[32] = {0};
	char dns_pri[32] = {0};
	char dns_sec[32] = {0};
	char tmpbuf[32] = {0};

	json_object_object_foreach(object, key, val)
	{
		if(!strcmp(key, "ip"))
		{
			strncpy(ip, json_object_get_string(val), sizeof(ip));
		}
		else if(!strcmp(key, "netmask"))
		{
			strncpy(netmask, json_object_get_string(val), sizeof(netmask));
		}
		else if(!strcmp(key, "gateway"))
		{
			strncpy(gateway, json_object_get_string(val), sizeof(gateway));
		}
		else if(!strcmp(key, "mtu"))
		{
			strncpy(mtu, json_object_get_string(val), sizeof(mtu));
		}
		else if(!strcmp(key, "dns_mode"))
		{
			strncpy(dns_mode, json_object_get_string(val), sizeof(dns_mode));
		}
		else if(!strcmp(key, "dns_pri"))
		{
			strncpy(dns_pri, json_object_get_string(val), sizeof(dns_pri));
		}
		else if(!strcmp(key, "dns_sec"))
		{
			strncpy(dns_sec, json_object_get_string(val), sizeof(dns_sec));
		}
		else
		{
			//do nothing
		}
	}

	set_wan_common();

	/* set wan proto */
	nvram_set("wan_proto", "static");
	nvram_set("wan0_proto", "static");

	/* set static ip */
	nvram_set("wan_ipaddr", ip);
	nvram_set("wan0_ipaddr", ip);

	/* set static netmask */
	nvram_set("wan_netmask", netmask);
	nvram_set("wan0_netmask", netmask);

	/* set static gateway */
	nvram_set("wan_gateway", gateway);
	nvram_set("wan0_gateway", gateway);

	/* set static mtu */
	nvram_set("wan_static_mtu", mtu);
	nvram_set("wan0_static_mtu", mtu);

	/* set static dns */
	memset(tmpbuf, 0x0, sizeof(tmpbuf));
	if(strlen(dns_sec))
	{
		snprintf(tmpbuf, sizeof(tmpbuf) - 1, "%s %s", dns_pri, dns_sec);
	}
	else
	{
		snprintf(tmpbuf, sizeof(tmpbuf) - 1, "%s", dns_pri);
	}
	nvram_set("wan_dns", tmpbuf);
	nvram_set("wan0_dns", tmpbuf);

	nvram_commit();
	return ret;
}


/*=============================================================================
 * Function Name : get_dhcp_conf
 * Description   : Use nvram handler function to get confs,
 *                 return error_code and output confs in the json object format
 * Format        :
 *       {
 *           "mtu":"1500",
 *           "dns_mode": "1",
 *           "dns_pri": "172.17.10.6",
 *           "dns_sec": "172.17.10.7"
 *     	 }
 * Description   : Use nvram handler function to get confs,return success or fail
 *===========================================================================*/
int get_dhcp_conf(json_object *object)
{
	int ret = NV_SUCCESS;
	char dns1[32] = {0};
	char dns2[32] = {0};
	json_object *myobject = NULL;

	myobject = json_object_new_object();
	if(NULL == myobject)
	{
		ret = NV_FAIL;
		cgi_debug("creat json fail.\n");
		return ret;
	}

	getDns(DNS_DHCP, dns1, dns2);

	json_object_object_add(myobject,"mtu",json_object_new_string(nvram_safe_get("wan_dhcp_mtu")));
	json_object_object_add(myobject,"dns_mode",json_object_new_string(nvram_safe_get("wan_dhcp_dnsen")));
	json_object_object_add(myobject,"dns_pri",json_object_new_string(dns1));
	json_object_object_add(myobject,"dns_sec",json_object_new_string(dns2));

	json_object_object_add(object,"confs",myobject);
	return ret;
}

/*=============================================================================
 * Function Name : set_dhcp_conf
 * Description   : Use nvram handler function to get confs,
 *                 return error_code and output confs in the json object format
 * Para Format        :
 *       {
 *           "mtu":"1500",
 *           "dns_mode": "1",
 *           "dns_pri": "172.17.10.6",
 *           "dns_sec": "172.17.10.7"
 *     	 }
 * Description   : Use nvram handler function to get confs,return success or fail
 *===========================================================================*/
int set_dhcp_conf(json_object *object)
{
	int ret = NV_SUCCESS;
	char mtu[16] = {0};
	char dns_mode[2] = {0};
	char dns_pri[32] = {0};
	char dns_sec[32] = {0};
	char tmpbuf[32] = {0};

	json_object_object_foreach(object, key, val)
	{
		if(!strcmp(key, "mtu"))
		{
			strncpy(mtu, json_object_get_string(val), sizeof(mtu));
		}
		else if(!strcmp(key, "dns_mode"))
		{
			strncpy(dns_mode, json_object_get_string(val), sizeof(dns_mode));
		}
		else if(!strcmp(key, "dns_pri"))
		{
			strncpy(dns_pri, json_object_get_string(val), sizeof(dns_pri));
		}
		else if(!strcmp(key, "dns_sec"))
		{
			strncpy(dns_sec, json_object_get_string(val), sizeof(dns_sec));
		}
		else
		{
			//do nothing
		}
	}

	set_wan_common();

	/* set wan proto */
	nvram_set("wan_proto", "dhcp");
	nvram_set("wan0_proto", "dhcp");

	/* set dhcp mtu */
	if(strlen(mtu))
	{
		nvram_set("wan_dhcp_mtu", mtu);
		nvram_set("wan0_dhcp_mtu", mtu);
	}

	/* set dhcp dns */
	if(strlen(dns_mode))
	{
		nvram_set("wan_dhcp_dnsen", dns_mode);
		nvram_set("wan0_dhcp_dnsen", dns_mode);

		memset(tmpbuf, 0x0, sizeof(tmpbuf));
		if(0 == strcmp(dns_mode, "1"))
		{
			if(strlen(dns_sec))
			{
				snprintf(tmpbuf, sizeof(tmpbuf) - 1, "%s %s", dns_pri, dns_sec);
			}
			else
			{
				snprintf(tmpbuf, sizeof(tmpbuf) - 1, "%s", dns_pri);
			}
		}

		nvram_set("wan_dhcp_dns", tmpbuf);
		nvram_set("wan0_dhcp_dns", tmpbuf);
	}

	nvram_commit();

	return ret;
}

/*=============================================================================
 * Function Name : get_pppoe_conf
 * Description   : Use nvram handler function to get confs,
 *                 return error_code and output confs in the json object format
 * Format        :
 *       {
 *           "username":"feixun",
 *           "password":"feixun",
 *           "dial_mode":"0",
 *           "server":"",
 *           "mtu":"1480",
 *           "dns_mode": "1",
 *           "dns_pri": "172.17.10.6",
 *           "dns_sec": "172.17.10.7"
 *     	 }
 * Description   : Use nvram handler function to get confs,return success or fail
 *===========================================================================*/
int get_pppoe_conf(json_object *object)
{
	int ret = NV_SUCCESS;
	char dns1[32] = {0};
	char dns2[32] = {0};
	json_object *myobject = NULL;

	myobject = json_object_new_object();
	if(NULL == myobject)
	{
		ret = NV_FAIL;
		cgi_debug("creat json fail.\n");
		return ret;
	}

	getDns(DNS_PPPOE, dns1, dns2);

	json_object_object_add(myobject,"username",json_object_new_string(nvram_safe_get("wan_pppoe_tmpusername_utf8")));
	json_object_object_add(myobject,"password",json_object_new_string(nvram_safe_get("wan_pppoe_tmppasswd")));
	json_object_object_add(myobject,"dial_mode",json_object_new_string(nvram_safe_get("wan_pppoe_dialtype")));
	json_object_object_add(myobject,"server",json_object_new_string(nvram_safe_get("wan_pppoe_server")));
	json_object_object_add(myobject,"mtu",json_object_new_string(nvram_safe_get("wan_pppoe_mtu")));
	json_object_object_add(myobject,"dns_mode",json_object_new_string(nvram_safe_get("wan_pppoe_dnsen")));
	json_object_object_add(myobject,"dns_pri",json_object_new_string(dns1));
	json_object_object_add(myobject,"dns_sec",json_object_new_string(dns2));

	json_object_object_add(object,"confs",myobject);
	return ret;
}

/*=============================================================================
 * Function Name : set_pppoe_conf
 * Description   : Use nvram handler function to get confs,
 *                 return error_code and output confs in the json object format
 * Para Format   :
 *       {
 *           "username":"feixun",
 *           "password":"feixun",
 *           "dial_mode":"0",
 *           "server":"",
 *           "mtu":"1480",
 *           "dns_mode": "1",
 *           "dns_pri": "172.17.10.6",
 *           "dns_sec": "172.17.10.7"
 *     	 }
 * Description   : Use nvram handler function to get confs,return success or fail
 *===========================================================================*/
int set_pppoe_conf(json_object *object)
{
	int ret = NV_SUCCESS;
	int srcIdx, dstIdx;
	char username[128] = {0};
	char password[128] = {0};
	char dial_mode[2] = {0};
	char server[128] = {0};
	char mtu[8] = {0};
	char dns_mode[2] = {0};
	char dns_pri[128] = {0};
	char dns_sec[128] = {0};
	char tmpbuf[256] = {0};
	char fcxk_pppoe_username[256] = {0};
	char fcxk_pppoe_password[256] = {0};

	json_object_object_foreach(object, key, val)
	{
		if(!strcmp(key, "username"))
		{
			strncpy(username, json_object_get_string(val), sizeof(username));
		}
		else if(!strcmp(key, "password"))
		{
			strncpy(password, json_object_get_string(val), sizeof(password));
		}
		else if(!strcmp(key, "dial_mode"))
		{
			strncpy(dial_mode, json_object_get_string(val), sizeof(dial_mode));
		}
		else if(!strcmp(key, "server"))
		{
			strncpy(server, json_object_get_string(val), sizeof(server));
		}
		else if(!strcmp(key, "mtu"))
		{
			strncpy(mtu, json_object_get_string(val), sizeof(mtu));
		}
		else if(!strcmp(key, "dns_mode"))
		{
			strncpy(dns_mode, json_object_get_string(val), sizeof(dns_mode));
		}
		else if(!strcmp(key, "dns_pri"))
		{
			strncpy(dns_pri, json_object_get_string(val), sizeof(dns_pri));
		}
		else if(!strcmp(key, "dns_sec"))
		{
			strncpy(dns_sec, json_object_get_string(val), sizeof(dns_sec));
		}
		else
		{
			//do nothing
		}
	}

	set_wan_common();

	/* set wan proto */
	nvram_set("wan_proto", "pppoe");
	nvram_set("wan0_proto", "pppoe");

	nvram_set("wan_pppoe_ifname", "ppp0");
	nvram_set("wan0_pppoe_ifname", "ppp0");

	if(strlen(dial_mode))
	{
		nvram_set("wan_pppoe_dialtype", dial_mode);
		nvram_set("wan0_pppoe_dialtype", dial_mode);
	}

	/* set username */
	nvram_set("wan_pppoe_tmpusername_utf8", username); // for web show
	if(nvram_match("wan_pppoe_dialtype", "1"))
	{
		encrypt_user_chinavnet_31(fcxk_pppoe_username, username);
	}
	else if(nvram_match("wan_pppoe_dialtype", "2"))
	{
		encrypt_user_chinavnet25(fcxk_pppoe_username, username);
	}
	else if(nvram_match("wan_pppoe_dialtype", "3"))
	{
		encrypt_user(fcxk_pppoe_username, username);
	}
	else if(nvram_match("wan_pppoe_dialtype", "4"))
	{
		encrypt_user_chinavnet32(fcxk_pppoe_username, username);
	}
	else
	{
		strncpy(fcxk_pppoe_username, username, strlen(username));
	}

	for (srcIdx=0, dstIdx=0; fcxk_pppoe_username[srcIdx]; srcIdx++, dstIdx++)
	{
		if (fcxk_pppoe_username[srcIdx] == '\"' || fcxk_pppoe_username[srcIdx] == '\''
				|| fcxk_pppoe_username[srcIdx] == '<'|| fcxk_pppoe_username[srcIdx] == '>'
				|| fcxk_pppoe_username[srcIdx] == '('|| fcxk_pppoe_username[srcIdx] == ')'
				|| fcxk_pppoe_username[srcIdx] == '&'||fcxk_pppoe_username[srcIdx] == '\\'
				|| fcxk_pppoe_username[srcIdx] == ' ')
		{
			tmpbuf[dstIdx++] = '\\';
		}
		tmpbuf[dstIdx] = fcxk_pppoe_username[srcIdx];
	}

	if (dstIdx != srcIdx)
	{
		memcpy(fcxk_pppoe_username, tmpbuf, dstIdx);
		fcxk_pppoe_username[dstIdx] ='\0';
	}
	nvram_set( "wan_pppoe_username", fcxk_pppoe_username ); // for function
	nvram_set( "wan0_pppoe_username", fcxk_pppoe_username );

	/* set password */
	nvram_set( "wan_pppoe_tmppasswd", password);//for web show
	if(nvram_match("wan_pppoe_dialtype", "4"))
	{
		encrypt_pwd_chinavnet32(fcxk_pppoe_password, password);
	}
	else
	{
		strncpy(fcxk_pppoe_password, password, strlen(password));
	}
	nvram_set("wan_pppoe_passwd", fcxk_pppoe_password); // for function
	nvram_set("wan0_pppoe_passwd", fcxk_pppoe_password);

	/* set service */
	if(strlen(server))
	{
		nvram_set("wan_pppoe_service", server);
		nvram_set("wan0_pppoe_service", server);
	}
	else
	{
		nvram_set("wan_pppoe_service", "");
		nvram_set("wan0_pppoe_service", "");
	}

	/* set mtu */
	if(strlen(mtu))
	{
		nvram_set("wan_pppoe_mru", mtu);
		nvram_set("wan0_pppoe_mru", mtu);
		nvram_set("wan_pppoe_mtu", mtu);
		nvram_set("wan0_pppoe_mtu", mtu);
	}

	/* set dns */
	if(strlen(dns_mode))
	{
		nvram_set("wan_pppoe_dnsen", dns_mode);
		nvram_set("wan0_pppoe_dnsen", dns_mode);

		memset(tmpbuf, 0x0, sizeof(tmpbuf));
		if(0 == strcmp(dns_mode, "1"))
		{
			if(strlen(dns_sec))
			{
				snprintf(tmpbuf, sizeof(tmpbuf) - 1, "%s %s", dns_pri, dns_sec);
			}
			else
			{
				snprintf(tmpbuf, sizeof(tmpbuf) - 1, "%s", dns_pri);
			}
		}
		nvram_set("wan_pppoe_dns", tmpbuf);
		nvram_set("wan0_pppoe_dns", tmpbuf);
	}

	nvram_commit();

	return ret;
}


/*=========================================================================
 * Function Name : getErrorCode
 * Decscription  : get PPPoE error code
 *========================================================================*/
int getErrorCode(void)
{
	int fd;
	char buf[128] = {0};
	int err;
	char *p;

	fd = open(PPPOE_ERR_PATH, O_RDONLY);
	if(fd < 0)
		return INTERNET_SUCCESS;

	read(fd, buf, (sizeof(buf) - 1));

	close(fd);

	if((p = strstr(buf, ERRORCODE)) != NULL)
	{
		p += strlen(ERRORCODE);
		err = atoi(p);
	}
	else
	{
		return INTERNET_SUCCESS;
	}

	return err;
}

/*=========================================================================
 * Function Name : getStatusCode
 * Decscription  : get wan status code
 **network.wan_status.status_code**值描述：
| 值    | 描述                           | API    |
| :--- | :--------------------------- | :----- |
| 0    | WAN口状态正常                     | 1.0.0+ |
| 1    | WAN口未连接                      | 1.0.0+ |
| 2    | WAN口无IP                      | 1.0.0+ |
| 3    | 网关无响应                        | 1.0.0+ |
| 4    | WAN口无DNS地址                   | 1.0.0+ |
| 5    | WAN口DNS无响应                   | 1.0.0+ |
| 6    | WAN口自定义DNS错误                 | 1.0.0+ |
| 7    | WAN口无DHCP服务器（针对上网方式为DHCP的情况） | 1.0.0+ |
| 8    | WAN口获取地址中（针对上网方式为DHCP的情况）    | 1.0.0+ |
| 9    | 正在PPPOE拨号（针对上网方式为PPPOE的情况）   | 1.0.0+ |
| 10   | PPPOE服务器无应答（针对上网方式为PPPOE的情况） | 1.0.0+ |
| 646  | PPPOE拨号错误                    | 1.0.0+ |
| 647  | PPPOE拨号错误                    | 1.0.0+ |
| 648  | PPPOE拨号错误                    | 1.0.0+ |
| 649  | PPPOE拨号错误                    | 1.0.0+ |
| 678  | PPPOE服务器错误                   | 1.0.0+ |
| 691  | PPPOE账号错误                    | 1.0.0+ |
| 709  | PPPOE密码错误                    | 1.0.0+ |
 *========================================================================*/
int getStatusCode(void)
{
	int ret = 0;
	int retPPPoE = 0;
	char pwanProto[16] = {0};
	char pwanGateway[24] = {0};

	if(nvram_match("pingcheck", "1"))
	{
		ret = WAN_OK;
	}
	else
	{
		if(nvram_match("get_wan_port_status", "1"))
		{
			strncpy(pwanProto, nvram_safe_get("wan0_proto"), sizeof(pwanProto) - 1);
			strncpy(pwanGateway, nvram_safe_get("wan0_gateway"), sizeof(pwanGateway) - 1);
			if(!strcmp(pwanProto, "dhcp")) //DHCP logic
			{
				if(nvram_match("wan0_ipaddr", "0.0.0.0") || nvram_match("wan0_ipaddr", ""))
				{
					ret = WAN_NOIP;
				}
				else
				{
					if(pingalive(pwanGateway) < 0) // check ping wan gateway
					{
						ret = WAN_GATE_NO_RSP;
					}
					else
					{
						if(nvram_match("wan_dhcp_dnsen", "1")) //check the dns is manual or dynamic
						{
							ret = WAN_DNS_MANUAL;
						}
						else
						{
							if(nvram_invmatch("wan0_dns", "") && nvram_invmatch("wan0_dns", "0.0.0.0")) //judge whether get dns
							{
								ret = WAN_DNS_NO_RSP;
							}
							else
							{
								ret = WAN_NODNS;
							}
						}
					}
				}

			}
			else if(!strcmp(pwanProto, "pppoe")) //PPPOE login
			{
				if(nvram_match("wan0_ipaddr", "0.0.0.0") || nvram_match("wan0_ipaddr", ""))
				{
					retPPPoE = getErrorCode();
					if(0 == retPPPoE)
					{
						ret = WAN_PPPOE_SER_NO_RSP;
					}
					else if(1 == retPPPoE)
					{
						ret = WAN_PPPOE_GETING;
					}
					else
					{
						ret = retPPPoE;
					}
				}
				else
				{
					if(pingalive(pwanGateway) < 0)//check ping wan gateway
					{
						ret = WAN_GATE_NO_RSP;
					}
					else
					{
						if(nvram_match("wan0_pppoe_dnsen", "1"))//judge the dns is manual or dynamic
						{
							ret = WAN_DNS_MANUAL;
						}
						else
						{
							if(nvram_invmatch("wan0_dns", ""))//judge whether get dns
							{
								ret = WAN_DNS_NO_RSP;
							}
							else
							{
								ret = WAN_NODNS;
							}
						}
					}
				}
			}
			else
			{
				//do nothing
			}
		}
		else
		{
			ret = WAN_DISCONNET;
		}
	}

	return ret;
}


/*=============================================================================
 * Function Name : get_wan_status_conf
 * Description   : Use nvram handler function to get confs,
 *                 return error_code and output confs in the json object format
 * Format        :
 *       {
 *           "protocol":"dhcp",
 *           "ip":"172.17.48.129",
 *           "netmask":"255.255.255.0",
 *           "gateway":"172.17.48.1",
 *           "dns_mode": "1",
 *           "dns_pri": "192.168.100.3",
 *           "dns_sec": "192.168.100.4",
 *           "internet_status":"1",
 *           "upload_speed":"1234",
 *           "download_speed":"5678",
 *           "status_code":"0"
 *     	 }
 * Description   : Use nvram handler function to get confs,return success or fail
 *===========================================================================*/
int get_wan_status_conf(json_object *object)
{
	int ret = NV_SUCCESS;
	int pppoeCode;
	char dns1[32] = {0};
	char dns2[32] = {0};
	char err_code[16] = {0};
	json_object *myobject = NULL;

	myobject = json_object_new_object();
	if(NULL == myobject)
	{
		ret = NV_FAIL;
		cgi_debug("creat json fail.\n");
		return ret;
	}

	getDns(DNS_NONE, dns1, dns2);
	pppoeCode = getStatusCode();
	snprintf(err_code, sizeof(err_code), "%d", pppoeCode);

	json_object_object_add(myobject,"protocol",json_object_new_string(nvram_safe_get("wan_proto")));
	json_object_object_add(myobject,"ip",json_object_new_string(nvram_safe_get("wan0_ipaddr")));
	json_object_object_add(myobject,"netmask",json_object_new_string(nvram_safe_get("wan0_netmask")));
	json_object_object_add(myobject,"gateway",json_object_new_string(nvram_safe_get("wan0_gateway")));
	json_object_object_add(myobject,"dns_pri",json_object_new_string(dns1));
	json_object_object_add(myobject,"dns_sec",json_object_new_string(dns2));
	json_object_object_add(myobject,"internet_status",json_object_new_string(nvram_safe_get("pingcheck")));
	json_object_object_add(myobject,"upload_speed",json_object_new_string(nvram_safe_get("wan_txbytes")));
	json_object_object_add(myobject,"download_speed",json_object_new_string(nvram_safe_get("wan_rxbytes")));
	json_object_object_add(myobject,"status_code",json_object_new_string(err_code));

	json_object_object_add(object,"confs",myobject);
	return ret;
}


