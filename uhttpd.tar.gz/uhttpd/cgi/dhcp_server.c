#include "libphi_cgi.h"
#include <arpa/inet.h>

#include <oid.h>
#include <notify.h>

#include "dhcpd.h"
#include "device_manage.h"
#include "checkdata.h"
#include "iconv.h"
#include "wlcr_main.h"


/*****************************
	len --> *.*.*.*
	25 --> 255.255.255.128
 ******************************/
char* netmask_len2str(int mask_len, char* mask_str)
{
	int i = 0;
	int ip_mask = 0;

	if (NULL == mask_str)
	{
		return mask_str;
	}

	for (i = 1, ip_mask = 1; i < mask_len; i++)
	{
		ip_mask = (ip_mask << 1) | 1;
	}

	ip_mask = htonl(ip_mask << (32 - mask_len));

	inet_ntop(AF_INET, &ip_mask, mask_str, INET_ADDRSTRLEN);

	return mask_str;
}

/*****************************
	*.*.*.* --> len
	255.255.255.128 --> 25
******************************/
int netmask_str2len(char* mask)
{
	int mask_len = 0;
	unsigned int ip_mask;
	
	inet_pton(AF_INET, mask, &ip_mask);
	ip_mask = ntohl(ip_mask);
	while (ip_mask & 0x80000000)
	{
		mask_len++;
		ip_mask = (ip_mask << 1);
	}

	return mask_len;
}

/*********************************************
"dhcpd" :
	{
		"config" : 
		{
			"enable" : "1", 
			"pool_start" : "100", 
			"pool_end" : "200", 
			"network_address" : "192.168.2.0/24"
		}
	}
*********************************************/
int get_dhcpd_conf(json_object *object)
{
	int ret = NV_SUCCESS;
	json_object *myobject = NULL;

	char lan_ip[16] = {0};
	char lan_mask[16] = {0};
	char lan_mode[8] = {0};
	
	char dhcp_start[16] = {0};
	char dhcp_end[16] = {0};

	char *p = NULL;

	char net_addr[24] = {0};
	int mask_len = 0;
	
	myobject = json_object_new_object();
	if(NULL == myobject)
	{
		ret = NV_FAIL;
		cgi_debug("creat json fail.\n");
		return ret;
	}

	strlcpy(lan_ip, nvram_safe_get("lan_ipaddr"), sizeof(lan_ip));
	strlcpy(lan_mask, nvram_safe_get("lan_netmask"), sizeof(lan_mask));
	strlcpy(lan_mode, nvram_safe_get("lan_proto"), sizeof(lan_mode));
	strlcpy(dhcp_start, nvram_safe_get("dhcp_start"), sizeof(dhcp_start));
	strlcpy(dhcp_end, nvram_safe_get("dhcp_end"), sizeof(dhcp_end));

	//3 get lan mode: 1.dhcp or 0.static.
	if (strcmp(lan_mode, "static") == 0)
	{
		sprintf(lan_mode, "0");
	}
	else
	{
		sprintf(lan_mode, "1");
	}
	json_object_object_add(myobject,"enable",json_object_new_string(lan_mode));

	//3 get dhco pool
	p = strrchr(dhcp_start, '.');	//"192.168.2.100" pool is last 8bits
	if (p)
	{
		json_object_object_add(myobject,"pool_start",json_object_new_string(p+1));
	}
	else
	{
		ret = NV_FAIL;
		goto func_exit;
	}

	p = strrchr(dhcp_end, '.');
	if (p)
	{
		json_object_object_add(myobject,"pool_end",json_object_new_string(p+1));
	}
	else
	{
		ret = NV_FAIL;
		goto func_exit;
	}

	//3 lan_ip & lan_mask convert to network_address.
	mask_len = netmask_str2len(lan_mask);

	sprintf(net_addr, "%s/%d", lan_ip, mask_len);	// "192.168.2.1/24" lan_ip/mask_len
	
	json_object_object_add(myobject,"network_address",json_object_new_string(net_addr));

	json_object_object_add(object,"confs",myobject);

func_exit:
	
	return ret;
	
}

int set_dhcpd_conf(json_object *object)
{
	int ret = NV_SUCCESS;

	char enable[8] = {0};
	char pool_start[16] = {0};
	char pool_end[16] = {0};
	char net_addr[24] = {0};
	char subnet[16] = {0};
	
	char *p = NULL;

	int mask_len = 0;
	
	json_object_object_foreach(object, key, val)
	{
		if(!strcmp(key, "enable"))
		{
			strlcpy(enable, json_object_get_string(val), sizeof(enable));
		}
		else if(!strcmp(key, "pool_start"))
		{
			strlcpy(pool_start, json_object_get_string(val), sizeof(pool_start));
		}
		else if(!strcmp(key, "pool_end"))
		{
			strlcpy(pool_end, json_object_get_string(val), sizeof(pool_end));
		}
		else if(!strcmp(key, "network_address"))
		{
			strlcpy(net_addr, json_object_get_string(val), sizeof(net_addr));
		}
		else
		{
			//do nothing
		}
	}

	if (strcmp(enable, "1") == 0)
	{
		sscanf(net_addr, "%[^/]/%d", subnet, &mask_len);
		p = strrchr(subnet, '.');
		if (p)
		{
			strlcpy((p+1), pool_start, 4);
			nvram_set("dhcp_start", subnet);

			strlcpy((p+1), pool_end, 4);
			nvram_set("dhcp_end", subnet);
		}

		nvram_set("lan_proto", "dhcp");
	}
	else
	{
		nvram_set("lan_proto", "static");
	}
	
	nvram_commit();

	notification_send_rc(OID_SERVICE_DHCPD, NOTIFY_WAIT);

	return ret;
}

/*
 * rename nvram like: dev_rename="d8:42:ac:11:22:33,phicomm"
 */
static int get_rename(dev_status **p_head)
{
//	dev_mng_debug("entry.\n");
	dev_status *p_cur = NULL;
	char *rules = nvram_safe_get(NVRAM_RENAME);
	char rec[128];
	char mac[DEV_MAC_LEN];
	char rename[NVRAM_RENAME_LEN];
	int i;
	int ret;
	dev_status tmp;
	char s_base64[NVRAM_RENAME_LEN * 2];

	if(strlen(rules) == 0)
		return -1;

//	dev_mng_debug("get rules %s=%s\n", NVRAM_RENAME, rules);

	i = 0;
	while (getNthValueSafe(i++, rules, ';', rec, sizeof(rec)) != -1)
	{
		//i++;
		if ((getNthValueSafe(0, rec, ',', mac, sizeof(mac)) == -1))
		{
			continue;
		}
		if ((getNthValueSafe(1, rec, ',', s_base64, sizeof(s_base64)) == -1))
		{
			continue;
		}
		websDecode64(rename, s_base64, sizeof(rename));

		ret = 0;
		p_cur = *p_head;
		while (p_cur != NULL)
		{
			if(strncasecmp(p_cur->mac, mac, DEV_MAC_LEN - 1) == 0)
			{
				ret = 1;
				strncpy(p_cur->rename, rename, NVRAM_RENAME_LEN - 1);
				break;
			}
			p_cur = p_cur->p_next;
		}
	}

	return 0;
}

extern int code_convert(char *from_charset, char *to_charset, char *inbuf, size_t inlen, char *outbuf, size_t outlen);

static int set_dev_ipbind(const char *mac, const char *ip, int is_bind)
{
	int i_idx;
	int found = 0;
	char rec[128];
	char s_mac[DEV_MAC_LEN];
	char s_ip[DEV_IP_LEN];
	char s_tmp[128];
	char buff[2048];

	char *rules = nvram_safe_get(NVRAM_STATIC_LIST);

	dev_mng_debug("get %s=%s, var ip=[%s], var is_bind=%d\n", NVRAM_STATIC_LIST, rules, ip, is_bind);

	i_idx = 0;
	memset(buff, 0x0, sizeof(buff));
	while (getNthValueSafe(i_idx++, rules, ';', rec, sizeof(rec)) != -1)
	{
		if(getNthValueSafe(0, rec, ',', s_mac, sizeof(s_mac)) == -1
			|| input_mac_check(s_mac) != CHE_OK)
		{
			continue;
		}
		if(getNthValueSafe(1, rec, ',', s_ip, sizeof(s_ip)) == -1)
		{
			continue;
		}

		dev_mng_debug("parse rec=[%s], s_mac=[%s], s_ip=[%s]\n", rec, s_mac, s_ip);

		if(strncasecmp(s_mac, mac, DEV_MAC_LEN - 1) == 0
			|| strncmp(s_ip, ip, DEV_IP_LEN - 1) == 0)
		{
			found = 1;
			if(is_bind == 0)
				continue;
			else
				sprintf(s_tmp, "%s,%s", mac, ip);
		}
		else
		{
			sprintf(s_tmp, "%s,%s", s_mac, s_ip);
		}

		dev_mng_debug("s_tmp=[%s]\n", s_tmp);

		if(strlen(buff) > 16)
			strcat(buff, ";");
		strcat(buff, s_tmp);

		dev_mng_debug("strcat buff=[%s]\n", buff);
	}
	if(found != 1 && is_bind == 1)
	{
		sprintf(s_tmp, "%s,%s", mac, ip);
		if(strlen(buff) > 16)
			strcat(buff, ";");
		strcat(buff, s_tmp);

		dev_mng_debug("strcat buff=[%s], s_tmp=[%s]\n", buff, s_tmp);
	}
	dev_mng_debug("set %s=%s\n", NVRAM_STATIC_LIST, buff);

	nvram_set(NVRAM_STATIC_LIST, buff);
	nvram_commit();

	//dhcpd restart?
	//notification_send_rc(OID_SERVICE_DHCPD, NOTIFY_WAIT);

	return 0;
}

/*
 * static-IP-bound nvram: dhcpreve_rules="d8:42:ac:11:22:33,192.168.1.100;d8:42:ac:11:22:44,192.168.1.101"
 */
static int get_dev_status_ipbind(dev_status **p_head)
{
//	dev_mng_debug("entry.\n");
	int i;
	char rec[64];
	char mac[32];
	char ip[32];
	char *rules = nvram_safe_get(NVRAM_STATIC_LIST);
	dev_status *p_cur = NULL;
	int ret;
	dev_status tmp;

	if(strlen(rules) == 0)
		return -1;

//	dev_mng_debug("get rules=%s\n", rules);

	i = 0;
	while(getNthValueSafe(i, rules, ';', rec, sizeof(rec)) != -1 && strlen(rec))
	{
		i++;
		if((getNthValueSafe(0, rec, ',', mac, sizeof(mac)) == -1))
		{
			continue;
		}
		if(getNthValueSafe(1, rec, ',', ip, sizeof(ip)) == -1)
		{
			continue;
		}

		ret = 0;
		p_cur = *p_head;
		while(p_cur != NULL)
		{
			if(strncasecmp(mac, p_cur->mac, DEV_MAC_LEN - 1) == 0)
			{
				p_cur->bind_flags = 1;
				ret = 1;
				break;
			}
			p_cur = p_cur->p_next;
		}

		if (ret == 1)
		{
			break;
		}
		else
		{
			memset(&tmp, 0x0, sizeof(tmp));
			strncpy(tmp.mac, mac, DEV_MAC_LEN - 1);
			strncpy(tmp.ip, ip, DEV_IP_LEN - 1);
			tmp.online_flags = CLIENT_STATUS_OFFLINE;
			tmp.bind_flags = 1;
			add_entry_to_link(p_head, &tmp);
		}
	}

	return 0;
}


int get_bind_list(json_object *object)
{
	int ret = NV_SUCCESS;

	int index = 0;
	char buf[8] = {0};
	
	dev_status *p_link = NULL;
	dev_status *p_cur = NULL;
	char utf8_str[HOST_NAME_LEN * 2]; //two gbk Bytes = three UTF8 Bytes
	char gbk_str[HOST_NAME_LEN];
	json_object *my_object = NULL;
	json_object *my_array = NULL;

	get_dev_status_ipbind(&p_link);
	get_rename(&p_link);
	
	/* format to json */
	p_cur = p_link;
	my_array = json_object_new_array();
	while(p_cur != NULL)
	{
		//display_entry(p_cur); //just for debug
		my_object = json_object_new_object();

		sprintf(buf, "%d", index++);
		json_object_object_add(my_object, "id", json_object_new_string(buf));
		
		if(strlen(p_cur->rename) > 0)
		{
			json_object_object_add(my_object, "name", json_object_new_string(p_cur->rename));
		}
		else if(strlen(p_cur->hostname) > 0)
		{
			memset(utf8_str, 0x0, sizeof(utf8_str));
			memset(gbk_str, 0x0, sizeof(gbk_str));
			strncpy(gbk_str, p_cur->hostname, sizeof(gbk_str)-1);
			code_convert("gb2312", "utf-8", gbk_str, strlen(gbk_str), utf8_str, sizeof(utf8_str));
			json_object_object_add(my_object, "name", json_object_new_string(utf8_str));
		}
		else
		{
			json_object_object_add(my_object, "name", json_object_new_string("Unknow"));
		}

		json_object_object_add(my_object, "ip", json_object_new_string(p_cur->ip));
		json_object_object_add(my_object, "mac", json_object_new_string(p_cur->mac));

		json_object_array_add(my_array, my_object);

		p_cur = p_cur->p_next;
	}

	free_dev_status_link(p_link);

	json_object_object_add(object,"confs", my_array);
	
	return ret;
}

int set_bind_list(json_object *object)
{
	int ret = NV_SUCCESS;
	
	char mac[18] = {0};
	char ip[16] = {0};

	json_object_object_foreach(object, key, val)
	{
		if(!strcmp(key, "ip"))
		{
			strlcpy(ip, json_object_get_string(val), sizeof(ip));
		}
		else if(!strcmp(key, "mac"))
		{
			strlcpy(mac, json_object_get_string(val), sizeof(mac));
		}
		else
		{
			//do nothing
		}
	}

	set_dev_ipbind(mac, ip, 0);
	set_dev_ipbind(mac, ip, 1); //bind ip/mac

	notification_send_rc(OID_SERVICE_DHCPD, NOTIFY_WAIT);

	return ret;
}

int add_bind_list(json_object *object)
{
	int ret = NV_SUCCESS;
	
	char mac[18] = {0};
	char ip[16] = {0};

	json_object_object_foreach(object, key, val)
	{
		if(!strcmp(key, "ip"))
		{
			strlcpy(ip, json_object_get_string(val), sizeof(ip));
		}
		else if(!strcmp(key, "mac"))
		{
			strlcpy(mac, json_object_get_string(val), sizeof(mac));
		}
		else
		{
			//do nothing
		}
	}

	set_dev_ipbind(mac, ip, 1); //bind ip/mac

	notification_send_rc(OID_SERVICE_DHCPD, NOTIFY_WAIT);

	return ret;
}

int del_bind_list(json_object *object)
{
	int ret = NV_SUCCESS;
	
	char mac[18] = {0};
	char ip[16] = {0};

	json_object_object_foreach(object, key, val)
	{
		if(!strcmp(key, "ip"))
		{
			strlcpy(ip, json_object_get_string(val), sizeof(ip));
		}
		else if(!strcmp(key, "mac"))
		{
			strlcpy(mac, json_object_get_string(val), sizeof(mac));
		}
		else
		{
			//do nothing
		}
	}

	set_dev_ipbind(mac, ip, 0);

	notification_send_rc(OID_SERVICE_DHCPD, NOTIFY_WAIT);

	return ret;
}



