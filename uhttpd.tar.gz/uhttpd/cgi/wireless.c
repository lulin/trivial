#include "libphi_cgi.h"
#include <error_code.h>

/* copy from bcmcvar.h */
#ifndef NVRAM_BUFSIZE
#define NVRAM_BUFSIZE	100
#endif

enum {
	WIFI_2G,
	WIFI_5G
};

enum {
	SECURITY_LOW = 1,
	SECURITY_MID,
	SECURITY_HIG
};

struct wifi_config_table {
	int wifi;
	char *bss_enabled; //enable
	char *ssid;
	char *wpa_psk;     //password
	char *closed;      //hidden
	char *mode;
	char *channel;
	char *nbw_cap;     //band_width
	char *ap_isolate;
	char *mu_mimo;
	char *beamforming;
	int safety;
};

static void
getWifiNvram(char *key, char *value, int is5G)
{
	const char newKey[128] = {0};

	if(nvram_match("ure_disable", "1")) //wisp disable
	{
		if (is5G)
		{
			sprintf(newKey, "wl1_%s", key);
		}
		else
		{
			sprintf(newKey, "wl0_%s", key);
		}
	}
	else //wisp enable
	{
		if(nvram_match("frequency", "0"))  // wisp 2.4g
		{
			if ( is5G)
			{
				sprintf(newKey, "wl1_%s", key);
			}
			else
			{
				sprintf(newKey, "wl0.1_%s", key);
			}
		}
		else if(nvram_match("frequency", "1")) // wisp 5g
		{
			if (is5G)
			{
				sprintf(newKey, "wl1.1_%s", key);
			}
			else
			{
				sprintf(newKey, "wl0_%s", key);
			}
		}
		else
		{
			//date invalid, so do nothing
		}
	}

	sprintf(value, "%s", nvram_safe_get(newKey));
}

#if 0
/*
 * Function Name : wifi_variable_check
 * Description   : check wireless config value, and return error_code.
 */
int wifi_variable_check(struct wifi_config_table *wifi_config)
{
	int ret = 0;
	//cgi_debug("wireless_basic_variable_check: %s.\n", wifi_config->wifi==WIFI_2G?"2g":"5g");

	if (NULL != wifi_config->bss_enabled)
	{
		//cgi_debug("wifi_config->bss_enabled=%s\n", wifi_config->bss_enabled);
		if (strncmp(wifi_config->bss_enabled, "0", 1) && strncmp(wifi_config->bss_enabled, "1", 1))
		{
			if (wifi_config->wifi == WIFI_2G)
				return E_WL2GENABLE;
			else
				return E_WL5GENABLE;
		}
	}

	if (NULL != wifi_config->ssid)
	{
		//cgi_debug("wifi_config->ssid=%s\n", wifi_config->ssid);
		ret = input_string_check(wifi_config->ssid, 1, 32, STR_NOT_EMPTY|STR_ASCII_ONLY);
		if (ret == CHE_ERR_EMPTY)
		{
			if (wifi_config->wifi == WIFI_2G)
				return E_WL2GSSIDBLANK;
			else
				return E_WL5GSSIDBLANK;
		}
		else if ((ret == CHE_ERR_STR_LEN_SHORTER) || (ret == CHE_ERR_STR_LEN_LONGER))
		{
			if (wifi_config->wifi == WIFI_2G)
				return E_WL2GSSIDLEN;
		}
		else if (ret == CHE_ERR_ASCII)
		{
			if (wifi_config->wifi == WIFI_2G)
				return E_WL2GSSIDILLEGAL;
		}

		if (strcmp(wifi_config->ssid, nvram_safe_get("vis_ssid")) == 0)
		{
			if (wifi_config->wifi == WIFI_2G)
				return E_WL2GSSIDCONFICTWITHGUEST;
		}
	}

	if (NULL != wifi_config->wpa_psk)
	{
		ret = input_string_check(wifi_config->wpa_psk, 8, 63, STR_ASCII_ONLY);
		if ((ret == CHE_ERR_STR_LEN_SHORTER) || (ret == CHE_ERR_STR_LEN_LONGER))
		{
			if (wifi_config->wifi == WIFI_2G)
				return E_WL2GSSIDPWLEN;
		}
		else if (ret == CHE_ERR_ASCII)
		{
			if (wifi_config->wifi == WIFI_2G)
				return E_WL2GSSIDPWILLEGAL;
		}
	}

	if (NULL != wifi_config->closed)
	{
		if ((strncmp(wifi_config->closed, "0", 1)) && (strncmp(wifi_config->closed, "1", 1)))
		{
			if (wifi_config->wifi == WIFI_2G)
				return E_WL2GSSIDBROAD;
		}
	}

	if (wifi_config->wifi == WIFI_2G)
	{
		if (NULL != wifi_config->mode)
		{
			//cgi_debug("wifi_config->mode = %s\n",wifi_config->mode);
			//wifi mode 0-bgn 1-bg 2-n 
			//wifi nbw_cap 0-20M 1-20/40M 2-40M
			if ((strncmp(wifi_config->mode, "0", 1))
					&& (strncmp(wifi_config->mode, "1", 1))
					&& (strncmp(wifi_config->mode, "2", 1)))
			{
				return E_WL2GMODE;
			}
			if (NULL != wifi_config->nbw_cap)
			{
				if((!strncmp(wifi_config->mode, "1", 1)) 
						&& ((!strncmp(wifi_config->nbw_cap, "1", 1))
							|| (!strncmp(wifi_config->nbw_cap, "2", 1))))
				{
					return E_WL2GMODEWIDTHNOTMATCH;
				}
			}
			else {
				if (!strncmp(wifi_config->mode, "1", 1)
						&& !strncmp(nvram_get("wl0_bw_cap"), "3", 1))
				{
					return E_WL2GMODEWIDTHNOTMATCH;
				}
			}
		}
	}
	else if (wifi_config->wifi == WIFI_5G)
	{
		//0-a/n/ac 1-n/ac 2-ac
		if(NULL != wifi_config->mode)
		{
			//cgi_debug("wifi_config->mode = %s\n",wifi_config->mode);
			if (strncmp(wifi_config->mode, "0", 1) && strncmp(wifi_config->mode, "1", 1))
			{
				return E_WL5GMODE;
			}
		}

		//0-20M 1-40M 2-80M 3-20/40/80
		if (NULL != wifi_config.nbw_cap)
		{
			if(strncmp(wifi_config.nbw_cap, "0", 1)
					&& strncmp(wifi_config.nbw_cap, "1", 1)
					&& strncmp(wifi_config.nbw_cap, "2", 1)
					&& strncmp(wifi_config.nbw_cap, "3", 1))
			{
				return E_WL5GCHWIDTH;
			}
		}
	}

	if (wifi_config->wifi == WIFI_2G)
	{
		if (NULL != wifi_config->channel)
		{
			ret = input_num_check(wifi_config->channel, 0, 13, NULL);
			if ((ret == CHE_ERR_STR_LEN_SHORTER)
					|| (ret == CHE_ERR_STR_LEN_LONGER)
					|| (ret == CHE_ERR_EMPTY))
			{
				return E_WL2GCHANNEL;
			}
		}
	}
	else if (wifi_config->wifi == WIFI_5G)
	{
		if(strncmp(wifi_config->channel, "0", 1))
		{
			ret = input_num_check(wifi_config->channel, 36, 165, NULL);
			if((ret == CHE_ERR_STR_LEN_SHORTER) || (ret == CHE_ERR_STR_LEN_LONGER))
			{
				return E_WL5GCHANNEL;
			}
			if((atoi(wifi_config->channel) > 64) && (atoi(wifi_config->channel) < 148))
			{
				return E_WL5GCHANNEL;
			}
			if((atoi(wifi_config->channel) >= 36) && (atoi(wifi_config->channel) <= 64))
			{
				if(atoi(wifi_config->channel)%4 != 0)
				{
					return E_WL5GCHANNEL;
				}
			}
			else if ((atoi(wifi_config->channel) >= 149) && (atoi(wifi_config->channel) <= 165))
			{
				if(atoi(wifi_config->channel)%4 != 1)
				{
					return E_WL5GCHANNEL;
				}
			}
		}
	}

	if (NULL != wifi_config->ap_isolate)
	{
		if ((strncmp(wifi_config->ap_isolate, "0", 1)) && (strncmp(wifi_config->ap_isolate, "1", 1)))
		{
			return E_WL2GISOLATE;
		}
	}

#if 0
	/* not support yet */
	if (NULL != wifi_config->mu_mimo)
	{
	}
#endif

	if (NULL != wifi_config->beamforming)
	{
	}

	return E_NONE;
}
#endif

int checkpass_strlength(char *password)
{
	char temp[65] = {0};
	int i = 0;
	int flag_int = 0;
	int flag_char_low = 0;
	int flag_char_hig = 0;
	int flag_other = 0;
	int flag = 0;

	if(!password || (strlen(password) > 64) || (strlen(password) == 0))
		return SECURITY_LOW;

	strcpy(temp, password);

	for(i = 0; i < strlen(password); i++)
	{
		if((temp[i] >= '0') && (temp[i] <= '9'))
			flag_int = 1;
		else if((temp[i] >= 'a') && (temp[i] <= 'z'))
			flag_char_low = 2;
		else if((temp[i] >= 'A') && (temp[i] <= 'Z'))
			flag_char_hig = 4;
		else
			flag_other = 8;
	}

	flag = flag_int | flag_char_low | flag_char_hig | flag_other;

	if((flag == 1) || (flag == 2) || (flag == 4))
		return SECURITY_LOW;
	else if((flag == 3) || (flag == 5) || (flag == 6))
		return SECURITY_MID;
	else if((flag == 7) || (flag >= 8))
		return SECURITY_HIG;

	return SECURITY_LOW;

}

/* check wifi password safety */
int wifisecurity_strlength(int flag)
{
	int level = SECURITY_LOW;
	char mode[64] = {0};
	char mode_auth[64] = {0};
	char mode_akm[64] = {0};
	char mode_wep[64] = {0};
	char pass[64] = {0};

	
	getWifiNvram("auth", mode_auth, flag);
	getWifiNvram("akm", mode_akm, flag);
	getWifiNvram("wep", mode_wep, flag);

	if(((strcmp(mode_auth, "0") == 0)||(strlen(mode_auth) == 0)) && (strcmp(mode_wep, "disabled") == 0) && (strlen(mode_akm) == 0))
	{
		strcpy(mode, "OPEN");
	}
	else if(strcmp(mode_wep, "enabled") == 0)
	{
		strcpy(mode, "WEPAUTO");
	}
	else if(strcmp(mode_akm, "psk") == 0)
	{
		strcpy(mode, "WPAPSK");
	}
	else if((strcmp(mode_akm, "psk2") == 0) || (strcmp(mode_akm, "psk psk2") == 0))
	{
		strcpy(mode, "WPAPSKWPA2PSK");
	}
	else
	{
		strcpy(mode, "OPEN");
	}
	

	if((strcmp(mode, "OPEN") == 0) || (strcmp(mode, "WEPAUTO") == 0) || (strcmp(mode, "WPAPSK") == 0))
	{
		level = SECURITY_LOW;
	}
	else if((strcmp(mode, "WPA2PSK") == 0) || (strcmp(mode, "WPAPSKWPA2PSK") == 0))
	{
		getWifiNvram("wpa_psk", pass, flag);
		level = checkpass_strlength(pass);
	}
	else
		level = SECURITY_LOW;

	return level;
}

/*===========================================================================
 * Function Name : get_smart_connect
 * Format        :
 "smart_connect" :
 {
 "enable" : "1"
 }
 *===========================================================================*/
int get_smart_connect(json_object *object)
{
	cgi_debug("function in.\n");
	int ret = NV_SUCCESS;
	char *smart_connect = NULL;
	json_object *myobject = NULL;

	myobject = json_object_new_object();
	smart_connect = nvram_safe_get("bsd_role");

	if (!strncmp(smart_connect, "0", 1))
		json_object_object_add(myobject, "enable", json_object_new_string("0"));
	else if (!strncmp(smart_connect, "3", 1))
		json_object_object_add(myobject, "enable", json_object_new_string("1"));
	else
		ret = NV_FAIL;
	
	if (ret != NV_FAIL)
		json_object_object_add(object, "confs", myobject);

	cgi_debug("function out.\n");

	return ret;
}

/*===========================================================================
 * Function Name : set_smart_connect
 * Format        :
 "smart_connect" :
 {
 "enable" : "1"
 }
 *===========================================================================*/
int set_smart_connect(json_object *object)
{
	cgi_debug("function in.\n");
	int ret = NV_SUCCESS;
	char en[4] = {0};

	json_object_object_foreach(object, key, val)
	{
		if (!strcmp(key, "enable"))
		{
			strncpy(en, json_object_get_string(val), 3);
		}
	}

	if (!strncmp(en, "0", 1))
		nvram_set("bsd_role", "0");
	else if(!strncmp(en, "1", 1))
		nvram_set("bsd_role", "3");
	else
		ret = NV_FAIL;

	if (ret != NV_FAIL)
		nvram_commit();

	cgi_debug("function out.\n");

	return ret;
}

/*===========================================================================
 * Function Name : get_wifi_2g
 * Format        :
 "wifi_2g_config" :
 {
 "enable" : "1",
 "ssid" : "@PHICOMM_XX",
 "password" : "12345678",
 "hidden" : "1",
 "mode" : "0",
 "channel" : "0",
 "band_width" : "0",
 "ap_isolate" : "1",
 "mu_mimo" : "1",
 "beamforming" : "1",
 "safety":"1"
 },
 *===========================================================================*/
int get_wifi_2g(json_object *object)
{
	cgi_debug("function in.\n");
	char status[4] = {0};
	char ssid[65] = {0};
	char passwd[256] = {0};
	struct json_object *infor_object = NULL;

	infor_object = json_object_new_object();

	getWifiNvram("bss_enabled", status, 0);
	if(strncmp(status, "0", 1) == 0)
	{
		json_object_object_add(infor_object, "enable", json_object_new_string("0"));
	}
	else
	{
		json_object_object_add(infor_object, "enable", json_object_new_string("1"));
	}

	getWifiNvram("ssid", ssid, 0);
	json_object_object_add(infor_object, "ssid", json_object_new_string(ssid));

	// password
	getWifiNvram("wpa_psk", passwd, 0);
	json_object_object_add(infor_object, "password", json_object_new_string(passwd));

	// BroadcatsSSID
	memset(status, 0x0, sizeof(status));
	getWifiNvram("closed", status, 0);
	if(!strncmp(status, "0", 1))
	{
		json_object_object_add(infor_object, "hidden", json_object_new_string("0"));
	}
	else
	{
		json_object_object_add(infor_object, "hidden", json_object_new_string("1"));
	}

	// wl mode
	json_object_object_add(infor_object, "mode", json_object_new_string(nvram_safe_get("pc_show_2_mode")));

	// wl channel
	json_object_object_add(infor_object, "channel", json_object_new_string(nvram_safe_get("pc_show_2_chanspec")));

	// wl band_width
	json_object_object_add(infor_object, "band_width", json_object_new_string(nvram_safe_get("pc_show_2_nbw_cap")));

	// wl ap_isolate
	memset(status, 0x0, sizeof(status));
	getWifiNvram("ap_isolate", status, 0);
	if(!strncmp(status, "0", 1))
	{
		json_object_object_add(infor_object, "ap_isolate", json_object_new_string("0"));
	}
	else
	{
		json_object_object_add(infor_object, "ap_isolate", json_object_new_string("1"));
	}

	// wl mu_mimo
	json_object_object_add(infor_object, "mu_mimo", json_object_new_string(nvram_safe_get("wl0_mu_features")));

	// wl beamforming
	json_object_object_add(infor_object, "beamforming", json_object_new_string(nvram_safe_get("pc_show_2_beamforming")));

	// 无线密码强度
	int safety = 1;
	safety = wifisecurity_strlength(WIFI_2G);
	snprintf(status, sizeof(status), "%d", safety);
	json_object_object_add(infor_object, "safety", json_object_new_string(status));

	json_object_object_add(object, "confs", infor_object);
	cgi_debug("object:%s\n", json_object_to_json_string(object));

	cgi_debug("function out.\n");

	return NV_SUCCESS;
}

/*===========================================================================
 * Function Name : set_wifi_2g
 * Format        :
 "wifi_2g_config" :
 {
 "enable" : "1",
 "ssid" : "@PHICOMM_XX",
 "password" : "12345678",
 "hidden" : "1",
 "mode" : "0",
 "channel" : "0",
 "band_width" : "0",
 "ap_isolate" : "1",
 "mu_mimo" : "1",
 "beamforming" : "1",
 "safety":"1"
 },
 *===========================================================================*/
int set_wifi_2g(json_object *object)
{
	cgi_debug("function in.\n");
	struct wifi_config_table wifi_config = {0};
	char unit_str[]={'\0','\0','\0','\0','\0'};
	char nvtmp[NVRAM_BUFSIZE] = {0};
	char prefix[] = "wlXXXXXXXXXX_";

	wifi_config.wifi = WIFI_2G;
	json_object_object_foreach(object, key, val)
	{
		if (!strcmp(key, "enable"))
		{
			wifi_config.bss_enabled = json_object_get_string(val);
		}
		else if (!strcmp(key, "ssid"))
		{
			wifi_config.ssid = json_object_get_string(val);
		}
		else if (!strcmp(key, "password"))
		{
			wifi_config.wpa_psk = json_object_get_string(val);
		}
		else if (!strcmp(key, "hidden"))
		{
			wifi_config.closed = json_object_get_string(val);
		}
		else if (!strcmp(key, "mode"))
		{
			wifi_config.mode = json_object_get_string(val);
		}
		else if (!strcmp(key, "channel"))
		{
			wifi_config.channel = json_object_get_string(val);
		}
		else if (!strcmp(key, "band_width"))
		{
			wifi_config.nbw_cap = json_object_get_string(val);
		}
		else if (!strcmp(key, "ap_isolate"))
		{
			wifi_config.ap_isolate = json_object_get_string(val);
		}
		else if (!strcmp(key, "mu_mimo"))
		{
			wifi_config.mu_mimo = json_object_get_string(val);
		}
		else if (!strcmp(key, "beamforming"))
		{
			wifi_config.beamforming = json_object_get_string(val);
		}
		else if (!strcmp(key, "safety"))
		{
			wifi_config.safety = json_object_get_string(val);
		}
	}
#if 0
	if (wifi_variable_check(&wifi_config) < 0)
		return NV_FAIL;
#endif

	if(nvram_match("ure_disable","0") && nvram_match("frequency","0"))
		strcpy(unit_str,"0.1");
	else
		strcpy(unit_str,"0");
	snprintf(prefix, sizeof(prefix), "wl%s_", unit_str);

	if (NULL != wifi_config.bss_enabled)
		nvram_set(strcat_r(prefix, "bss_enabled", nvtmp), wifi_config.bss_enabled);

	if (NULL != wifi_config.ssid)
		nvram_set(strcat_r(prefix, "ssid", nvtmp), wifi_config.ssid);

	if (NULL != wifi_config.closed)
		nvram_set(strcat_r(prefix, "closed", nvtmp), wifi_config.closed);

	if (NULL != wifi_config.wpa_psk)
		if(wifi_config.wpa_psk[0] == '\0')
		{
			nvram_set(strcat_r(prefix, "akm", nvtmp), "");
			nvram_set(strcat_r(prefix, "crypto", nvtmp), "");
			nvram_set(strcat_r(prefix, "wpa_psk", nvtmp), "");
		}
		else
		{
			nvram_set(strcat_r(prefix, "akm", nvtmp), "psk psk2");
			nvram_set(strcat_r(prefix, "crypto", nvtmp), "tkip+aes");
			nvram_set(strcat_r(prefix, "wpa_psk", nvtmp), wifi_config.wpa_psk);
		}

	if (NULL != wifi_config.ap_isolate)
		nvram_set(strcat_r(prefix, "ap_isolate", nvtmp), wifi_config.ap_isolate);

	if(!strcmp(unit_str, "0"))
	{
		//wifi mode 0-bgn 1-bg 2-n
		if (NULL != wifi_config.mode)
		{
			//cgi_debug("wl0_mode = %s\n",wl0_mode);
			if (!strncmp(wifi_config.mode, "0", 1))
			{
				nvram_set("wl0_nmode","-1");
				nvram_set("wl0_nmode_protection", "auto");
				nvram_set("wl0_mode_bg", "1");
				nvram_set("wl0_vht_features", "7");
				nvram_set("pc_show_2_mode", "0");
				nvram_set("wl0_acs_scan_bw", "0");
				nvram_set("wl0_nreqd", "0");
			}
			else if(!strncmp(wifi_config.mode, "1", 1))
			{
				nvram_set("wl0_nmode","0");
				nvram_set("wl0_mode_bg", "1");
				nvram_set("wl0_vht_features", "-1");
				nvram_set("pc_show_2_mode", "1");
				nvram_set("wl0_acs_scan_bw", "1");
				nvram_set("wl0_nreqd", "0");
			}
			else if(!strncmp(wifi_config.mode, "2", 1))
			{
				nvram_set("wl0_nmode","-1");
				nvram_set("wl0_vht_features", "7");
				nvram_set ("wl0_nmode_protection", "off");
				nvram_set("wl0_mode_bg", "0");
				nvram_set("pc_show_2_mode", "2");
				nvram_set("wl0_acs_scan_bw", "2");
				nvram_set("wl0_nreqd", "1");
			}
		}

		if ((NULL != wifi_config.channel) && (('\0' != wifi_config.channel[0])))
		{
			nvram_set("wl0_chanspec",wifi_config.channel);
			nvram_set("pc_show_2_chanspec", wifi_config.channel);
		}

		if (NULL != wifi_config.nbw_cap)
		{
			if (!strncmp(wifi_config.nbw_cap, "0", 1))
			{
				nvram_set("pc_show_2_nbw_cap", "0");
				nvram_set("wl0_bw_cap", "1");
				nvram_set("wl0_obss_coex", "0");
			}
			else if (!strncmp(wifi_config.nbw_cap, "1", 1))
			{
				nvram_set("pc_show_2_nbw_cap", "1");
				nvram_set("wl0_bw_cap", "3");
				nvram_set("wl0_obss_coex", "1");

				if (atoi(wifi_config.channel) == 0)
					nvram_set("wl0_chanspec", "0");
				else if ((atoi(wifi_config.channel) >= 10) && (atoi(wifi_config.channel) <= 13))
					nvram_set("wl0_chanspec", strcat_r(wifi_config.channel, "u", nvtmp));
				else
					nvram_set("wl0_chanspec", strcat_r(wifi_config.channel, "l", nvtmp));

			}
			else if (!strncmp(wifi_config.nbw_cap, "2", 1))
			{
				nvram_set("pc_show_2_nbw_cap", "2");
				nvram_set("wl0_bw_cap", "3");
				nvram_set("wl0_obss_coex", "0");

				if (atoi(wifi_config.channel) == 0)
					nvram_set("wl0_chanspec", "0");
				else if ((atoi(wifi_config.channel) >= 10) && (atoi(wifi_config.channel) <= 13))
					nvram_set("wl0_chanspec", strcat_r(wifi_config.channel, "u", nvtmp));
				else
					nvram_set("wl0_chanspec", strcat_r(wifi_config.channel, "l", nvtmp));

			}
		}
	}

	// mu_features: set mu_mimo
	if (NULL != wifi_config.mu_mimo)
	{
		if (!strncmp(wifi_config.mu_mimo, "0", 1))
			nvram_set("wl0_mu_features", "0");
		else if (!strncmp(wifi_config.mu_mimo, "1", 1))
			nvram_set("wl0_mu_features", "1");
	}

	/* beamforming
	 * 关闭:
	 *    nvram set wl0_txbf_bfr_cap 0
	 *    nvram set wl0_txbf_bfe_cap 0
	 *    nvram set wl0_txbf 0
	 *    nvram set wl0_txbf_imp 0
	 *打开:
	 *    nvram set wl0_txbf_bfr_cap 2
	 *    nvram set wl0_txbf_bfe_cap 2
	 *    nvram set wl0_txbf 1
	 *    nvram set wl0_txbf_imp 1
	 */
	if (NULL != wifi_config.beamforming)
	{
		if (!strncmp(wifi_config.beamforming, "0", 1))
		{
			nvram_set("wl0_txbf_bfr_cap", "0");
			nvram_set("wl0_txbf_bfe_cap", "0");
			nvram_set("wl0_txbf", "0");
			nvram_set("wl0_txbf_imp", "0");
			nvram_set("pc_show_2_beamforming", "0");
		}
		else if (!strncmp(wifi_config.beamforming, "1", 1))
		{
			nvram_set("wl0_txbf_bfr_cap", "2");
			nvram_set("wl0_txbf_bfe_cap", "2");
			nvram_set("wl0_txbf", "1");
			nvram_set("wl0_txbf_imp", "1");
			nvram_set("pc_show_2_beamforming", "1");
		}
	}

	if (NULL != wifi_config.safety)
	{
		if (!strncmp(wifi_config.safety, "1", 1)
				|| !strncmp(wifi_config.safety, "2", 1)
				|| !strncmp(wifi_config.safety, "3", 1))
			nvram_set("pc_show_2_safety", wifi_config.safety);
	}

	nvram_commit();

	cgi_debug("function out.\n");

	return NV_SUCCESS;
}

/*===========================================================================
 * Function Name : get_wifi_5g
 * Format        :
 "wifi_5g_config" :
 {
 "enable" : "1",
 "ssid" : "@PHICOMM_XX",
 "password" : "12345678",
 "hidden" : "1",
 "mode" : "0",
 "channel" : "0",
 "band_width" : "0",
 "ap_isolate" : "1",
 "mu_mimo" : "1",
 "beamforming" : "1",
 "safety":"1"
 },
 *===========================================================================*/
int get_wifi_5g(json_object *object)
{
	cgi_debug("function in.\n");
	char status[4] = {0};
	char ssid[65] = {0};
	char passwd[256] = {0};
	struct json_object *infor_object = NULL;

	infor_object = json_object_new_object();

	getWifiNvram("bss_enabled", status, 1);
	if(strncmp(status, "0", 1) == 0)
	{
		json_object_object_add(infor_object, "enable", json_object_new_string("0"));
	}
	else
	{
		json_object_object_add(infor_object, "enable", json_object_new_string("1"));
	}

	getWifiNvram("ssid", ssid, 1);
	json_object_object_add(infor_object, "ssid", json_object_new_string(ssid));

	// password
	getWifiNvram("wpa_psk", passwd, 1);
	json_object_object_add(infor_object, "password", json_object_new_string(passwd));

	// BroadcatsSSID
	memset(status, 0x0, sizeof(status));
	getWifiNvram("closed", status, 1);
	if(!strncmp(status, "0", 1))
	{
		json_object_object_add(infor_object, "hidden", json_object_new_string("0"));
	}
	else
	{
		json_object_object_add(infor_object, "hidden", json_object_new_string("1"));
	}

	// wl mode
	json_object_object_add(infor_object, "mode", json_object_new_string(nvram_safe_get("pc_show_5_mode")));

	// wl channel
	json_object_object_add(infor_object, "channel", json_object_new_string(nvram_safe_get("pc_show_5_chanspec")));

	// wl band_width
	json_object_object_add(infor_object, "band_width", json_object_new_string(nvram_safe_get("pc_show_5_nbw_cap")));

	// wl ap_isolate
	memset(status, 0x0, sizeof(status));
	getWifiNvram("ap_isolate", status, 1);
	if(!strncmp(status, "0", 1))
	{
		json_object_object_add(infor_object, "ap_isolate", json_object_new_string("0"));
	}
	else
	{
		json_object_object_add(infor_object, "ap_isolate", json_object_new_string("1"));
	}

	// wl mu_mimo
	json_object_object_add(infor_object, "mu_mimo", json_object_new_string(nvram_safe_get("wl1_mu_features")));

	// wl beamforming
	json_object_object_add(infor_object, "beamforming", json_object_new_string(nvram_safe_get("pc_show_5_beamforming")));

	// 无线密码强度
	int safety = 1;
	safety = wifisecurity_strlength(WIFI_2G);
	snprintf(status, sizeof(status), "%d", safety);
	json_object_object_add(infor_object, "safety", json_object_new_string(status));

	json_object_object_add(object, "confs", infor_object);

	cgi_debug("function out.\n");

	return NV_SUCCESS;
}

/*=============================================================================
 * Function Name : set_wifi_5g
 * Format        :
 "wifi_5g_config" :
 {
 "enable" : "1",
 "ssid" : "@PHICOMM_XX_5G",
 "password" : "12345678",
 "hidden" : "1",
 "mode" : "0",
 "channel" : "0",
 "band_width" : "0",
 "ap_isolate" : "1",
 "mu_mimo" : "1",
 "beamforming" : "1",
 "safety":"1"
 }
 *===========================================================================*/
int set_wifi_5g(json_object *object)
{
	cgi_debug("function in.\n");
	struct wifi_config_table wifi_config = {0};
	char wl1_mode_select[]={'\0','\0'};
	char unit_str[]={'\0','\0','\0','\0','\0'};
	char nvtmp[NVRAM_BUFSIZE] = {0};
	char prefix[] = "wlXXXXXXXXXX_";

	wifi_config.wifi = WIFI_5G;
	json_object_object_foreach(object, key, val)
	{
		if (!strcmp(key, "enable"))
		{
			wifi_config.bss_enabled = json_object_get_string(val);
		}
		else if (!strcmp(key, "ssid"))
		{
			wifi_config.ssid = json_object_get_string(val);
		}
		else if (!strcmp(key, "password"))
		{
			wifi_config.wpa_psk = json_object_get_string(val);
		}
		else if (!strcmp(key, "hidden"))
		{
			wifi_config.closed = json_object_get_string(val);
		}
		else if (!strcmp(key, "mode"))
		{
			wifi_config.mode = json_object_get_string(val);
		}
		else if (!strcmp(key, "channel"))
		{
			wifi_config.channel = json_object_get_string(val);
		}
		else if (!strcmp(key, "band_width"))
		{
			wifi_config.nbw_cap = json_object_get_string(val);
		}
		else if (!strcmp(key, "ap_isolate"))
		{
			wifi_config.ap_isolate = json_object_get_string(val);
		}
		else if (!strcmp(key, "mu_mimo"))
		{
			wifi_config.mu_mimo = json_object_get_string(val);
		}
		else if (!strcmp(key, "beamforming"))
		{
			wifi_config.beamforming = json_object_get_string(val);
		}
		else if (!strcmp(key, "safety"))
		{
			wifi_config.safety = json_object_get_string(val);
		}
	}
#if 0
	if (wifi_variable_check(&wifi_config) < 0)
		return NV_FAIL;
#endif

	if(nvram_match("ure_disable","0") && nvram_match("frequency","1"))
		strcpy(unit_str,"1.1");
	else
		strcpy(unit_str,"1");
	snprintf(prefix, sizeof(prefix), "wl%s_", unit_str);

	if (NULL != wifi_config.bss_enabled)
		nvram_set(strcat_r(prefix, "bss_enabled", nvtmp), wifi_config.bss_enabled);

	if (NULL != wifi_config.ssid)
		nvram_set(strcat_r(prefix, "ssid", nvtmp), wifi_config.ssid);

	if (NULL != wifi_config.closed)
		nvram_set(strcat_r(prefix, "closed", nvtmp), wifi_config.closed);

	if (NULL != wifi_config.wpa_psk)
	{
		if(wifi_config.wpa_psk[0] == '\0')
		{
			nvram_set(strcat_r(prefix, "akm", nvtmp), "");
			nvram_set(strcat_r(prefix, "crypto", nvtmp), "");
			nvram_set(strcat_r(prefix, "wpa_psk", nvtmp), "");
		}
		else
		{
			nvram_set(strcat_r(prefix, "akm", nvtmp), "psk psk2");
			nvram_set(strcat_r(prefix, "crypto", nvtmp), "tkip+aes");
			nvram_set(strcat_r(prefix, "wpa_psk", nvtmp), wifi_config.wpa_psk);
		}
	}

	if (NULL != wifi_config.ap_isolate)
		nvram_set(strcat_r(prefix, "ap_isolate", nvtmp), wifi_config.ap_isolate);

	if (!strcmp(unit_str, "1"))
	{
		if (NULL != wifi_config.mode)
		{
			if (!strncmp(wifi_config.mode, "0", 1))
			{
				nvram_set("wl1_nmode","-1");
				nvram_set("wl1_nmode_protection", "auto");
				nvram_set("pc_show_5_mode", "0");
				nvram_set("wl1_nreqd", "0");
			}
			else if (!strncmp(wifi_config.mode, "1", 1))
			{
				nvram_set("wl1_nmode","-1");
				nvram_set("pc_show_5_mode", "1");
				nvram_set("wl1_nreqd", "1");
			}
		}

		if ((NULL != wifi_config.channel) && (('\0' != wifi_config.channel[0])))
		{
			nvram_set("wl1_chanspec",wifi_config.channel);
			nvram_set("pc_show_5_chanspec", wifi_config.channel);
		}

		if (NULL != wifi_config.nbw_cap)
		{
			if (!strncmp(wifi_config.nbw_cap, "0", 1))
			{
				nvram_set("pc_show_5_nbw_cap", "0");
				nvram_set("wl1_bw_cap", "1");
				nvram_set("wl1_acs_scan_bw", "0");
			}
			else if (!strncmp(wifi_config.nbw_cap, "1", 1))
			{
				nvram_set("pc_show_5_nbw_cap", "1");
				nvram_set("wl1_bw_cap", "3");
				nvram_set("wl1_obss_coex", "1");

				if ((atoi(wifi_config.channel) >= 36) && (atoi(wifi_config.channel) <= 64))
				{
					if (0 == atoi(wifi_config.channel)%8)
						snprintf(wl1_mode_select, sizeof(wl1_mode_select), "%s", "u");
					else
						snprintf(wl1_mode_select, sizeof(wl1_mode_select), "%s", "l");
				}
				else if ((atoi(wifi_config.channel) >= 149) && (atoi(wifi_config.channel) <= 161))
				{
					if (1 == atoi(wifi_config.channel)%8)
						snprintf(wl1_mode_select, sizeof(wl1_mode_select), "%s", "u");
					else
						snprintf(wl1_mode_select, sizeof(wl1_mode_select), "%s", "l");

				}
				nvram_set("wl1_acs_scan_bw", "1");
			}
			else if (!strncmp(wifi_config.nbw_cap, "2", 1))
			{
				nvram_set("pc_show_5_nbw_cap", "2");
				nvram_set("wl1_bw_cap", "7");
				//strcpy(wl1_mode_select,"/80");
				snprintf(wl1_mode_select, sizeof(wl1_mode_select), "%s", "/80");
				nvram_set("wl1_acs_scan_bw", "2");
			}
			else if (!strncmp(wifi_config.nbw_cap, "3", 1))
			{
				//printf("get the forth num\n");
				nvram_set("pc_show_5_nbw_cap", "3");
				nvram_set("wl1_bw_cap", "7");
				//strcpy(wl1_mode_select,"/80");
				snprintf(wl1_mode_select, sizeof(wl1_mode_select), "%s", "/80");
				nvram_set("wl1_acs_scan_bw", "3");
			}
		}
		if((NULL != wifi_config.channel) && ('\0' != wifi_config.channel[0]))
		{
			nvram_set("pc_show_5_chanspec", wifi_config.channel);
			if (!strncmp(wifi_config.channel, "0", 1))
				nvram_set("wl1_chanspec", wifi_config.channel);
			else	
				nvram_set("wl1_chanspec", strcat_r(wifi_config.channel, wl1_mode_select, nvtmp));
		}
	}

	// mu_features: set mu_mimo
	if (NULL != wifi_config.mu_mimo)
	{
		if (!strncmp(wifi_config.mu_mimo, "0", 1))
			nvram_set("wl1_mu_features", "0");
		else if (!strncmp(wifi_config.mu_mimo, "1", 1))
			nvram_set("wl1_mu_features", "1");
	}

	/* beamforming
	 * 关闭:
	 *    nvram set wl1_txbf_bfr_cap 0
	 *    nvram set wl1_txbf_bfe_cap 0
	 *    nvram set wl1_txbf 0
	 *    nvram set wl1_txbf_imp 0
	 *打开:
	 *    nvram set wl1_txbf_bfr_cap 2
	 *    nvram set wl1_txbf_bfe_cap 2
	 *    nvram set wl1_txbf 1
	 *    nvram set wl1_txbf_imp 1
	 */
	if (NULL != wifi_config.beamforming)
	{
		if (!strncmp(wifi_config.beamforming, "0", 1))
		{
			nvram_set("wl1_txbf_bfr_cap", "0");
			nvram_set("wl1_txbf_bfe_cap", "0");
			nvram_set("wl1_txbf", "0");
			nvram_set("wl1_txbf_imp", "0");
			nvram_set("pc_show_5_beamforming", "0");
		}
		else if (!strncmp(wifi_config.beamforming, "1", 1))
		{
			nvram_set("wl1_txbf_bfr_cap", "2");
			nvram_set("wl1_txbf_bfe_cap", "2");
			nvram_set("wl1_txbf", "1");
			nvram_set("wl1_txbf_imp", "1");
			nvram_set("pc_show_5_beamforming", "1");
		}
	}

	nvram_commit();

	cgi_debug("function out.\n");

	return NV_SUCCESS;
}
