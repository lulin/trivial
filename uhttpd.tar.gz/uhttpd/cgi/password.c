#include "libphi_cgi.h"

/********************************************
login and password JSON fromat

"account" :
{
	"config" :
	{
		"user" : "admin",
		"pwd" : "xxxx",
		"mtime" : "xxxxx",
	}
}
********************************************/
int get_password_conf(json_object *object)
{
	int ret = NV_SUCCESS;
	char *user_name = NULL;
	char *user_password = NULL;
	char *os_time = NULL;

	user_name = nvram_safe_get("http_username");
	user_password = nvram_safe_get("http_passwd");
	os_time = nvram_safe_get("http_os_time");

	json_object *myobject = NULL;
	myobject = json_object_new_object();

	if(myobject == NULL)
	{
		printf("new json object failed.\n");
		ret = NV_FAIL;
		return ret;
	}

	if(user_name && user_password)
	{
		json_object_object_add(myobject,"user",json_object_new_string(user_name));
		json_object_object_add(myobject,"pwd",json_object_new_string(user_password));
		json_object_object_add(myobject,"mtime",json_object_new_string(os_time));
		json_object_object_add(object,"confs",myobject);
	}
	else
	{
		ret = NV_FAIL;
	}

	return ret;
}

int set_password_conf(json_object *object)
{
	char user_password[64] = {0};
	char user_name[64] = {0};
	char os_time[256] = {0};

	json_object_object_foreach(object, key, val)
	{
		if(!strcmp(key, "user"))
		{
        	memset(user_name,0,sizeof(user_name));
        	strcpy(user_name, json_object_get_string(val));
		}
		else if(!strcmp(key, "pwd"))
		{
			memset(user_password,0,sizeof(user_password));
        	strcpy(user_password, json_object_get_string(val));
		}
		else
		{
			memset(os_time,0,sizeof(os_time));
        	strcpy(os_time, json_object_get_string(val));
		}
	}

	nvram_set("http_username", user_name);
	nvram_set("http_passwd", user_password);
	nvram_set("http_os_time", os_time);
	nvram_commit();

	return NV_SUCCESS;
}

/********************************************
welcome password JSON fromat

"welcome" :
{
	"config" :
	{
		"guide" : "1",
		"language" : "zh-cn",
		"agreement" : "1"
	}
}
********************************************/

int get_welcome_password_conf(json_object *object)
{
	int ret = NV_SUCCESS;
	char *user_guide = NULL;
	char *user_language = NULL;
	char *user_agreement = NULL;

	user_guide = nvram_safe_get("guide");
	user_language = nvram_safe_get("language");
	user_agreement = nvram_safe_get("agreement");

	json_object *myobject = NULL;
	myobject = json_object_new_object();

	if(myobject == NULL)
	{
		printf("new json object failed.\n");
		ret = NV_FAIL;
		return ret;
	}

	if(user_guide && user_language && user_agreement)
	{
		json_object_object_add(myobject,"guide",json_object_new_string(user_guide));
		json_object_object_add(myobject,"language",json_object_new_string(user_language));
		json_object_object_add(myobject,"agreement",json_object_new_string(user_agreement));
		json_object_object_add(object,"confs",myobject);
	}
	else
	{
		ret = NV_FAIL;
	}

	return ret;
}

int set_welcome_password_conf(json_object *object)
{
	char user_guide[64] = {0};
	char user_language[64] = {0};
	char user_agreement[64] = {0};

	json_object_object_foreach(object, key, val)
	{
		if(!strcmp(key, "guide"))
		{
			memset(user_guide,0,sizeof(user_guide));
			strcpy(user_guide, json_object_get_string(val));
		}
		else if(!strcmp(key, "language"))
		{
			memset(user_language,0,sizeof(user_language));
			strcpy(user_language, json_object_get_string(val));
		}
		else
		{
			memset(user_agreement,0,sizeof(user_agreement));
			strcpy(user_agreement, json_object_get_string(val));
		}
	}

	nvram_set("guide", user_guide);
	nvram_set("language", user_language);
	nvram_set("agreement", user_agreement);
	nvram_commit();

	return NV_SUCCESS;
}
