/**
 * VPNC nvram setup management. Guarantee the setup is consistent.
 */
#include <nv_vpn_client.h>
#include <vpn_client.h>
#include <stdio.h>

void vpnc_account_release(vpnc_account_ptr account)
{
    if (account) {
        if (account->id)
            free(account->id);
        if (account->name)
            free(account->name);
        if (account->protocol)
            free(account->protocol);
        if (account->peer)
            free(account->peer);
        if (account->user)
            free(account->user);
        if (account->password)
            free(account->password);
    }
}

/**
 * Return NULL if no account is found. Otherwise, a pointer points to an array
 * of vpnc_account_ptr objects is returned, the length of the array is stored in
 * @count. Parameter @count should never be NULL.
 */
vpnc_account_ptr *vpnc_setup_account_dump(int *count)
{
    vpnc_account_ptr *accounts;
    // assert(count);
    if (!count)
        return NULL;

    int aux_count = atoi(nvram_safe_get(NV_KEY_VPNC_ACCOUNT_COUNT));
    if (aux_count == 0)
        return NULL;

    accounts = calloc(*count, sizeof(vpnc_account_ptr));
    int i;
    *count = 0;
    for (i = 0; i < aux_count; i++) {
        if (vpnc_setup_account_get_byid(i + 1,  accounts + i) < 0) {
            /* bad database, log error */
            continue;
        }
        (*count)++;
    }

    if (*count == 0) {
        if (accounts)
            free(accounts);
        return NULL;
    }
    return accounts;
}

/**
 * Add @item to the top, i.e. @item will be assigned its ID with total count + 1.
 */
int vpnc_setup_account_add(vpnc_account_ptr item)
{
    /* @item mustn't be null and must be initialized */
    if (!item || !item->name)
        return -1;

    /* An account with the same name is all ready existed. */
    if (vpnc_setup_account_get_byname(item->name, NULL) == 0) {
        return -1;
    }

    int count;
    char str_count[6];
    /* old count */
    snprintf(str_count, sizeof(str_count), "%s",
             nvram_safe_get(NV_KEY_VPNC_ACCOUNT_COUNT));

    /* new count */
    count = strtol(str_count, NULL, 10) + 1;
    snprintf(str_count, sizeof(str_count), "%d", count);

    char key[NV_KEY_LENGTH_MAX];
    snprintf(key, sizeof(key), NV_KEY_FMT_VPNC_ACCOUNT_ID, count);
    nvram_set(key, str_count);

    snprintf(key, sizeof(key), NV_KEY_FMT_VPNC_ACCOUNT_ENABLE, count);
    nvram_set(key, item->enabled? "1": "0");

    snprintf(key, sizeof(key), NV_KEY_FMT_VPNC_ACCOUNT_NAME, count);
    nvram_set(key, item->name? : "");

    snprintf(key, sizeof(key), NV_KEY_FMT_VPNC_ACCOUNT_PROTO, count);
    nvram_set(key, item->protocol? : "");

    snprintf(key, sizeof(key), NV_KEY_FMT_VPNC_ACCOUNT_PEER, count);
    nvram_set(key, item->peer? : "");

    snprintf(key, sizeof(key), NV_KEY_FMT_VPNC_ACCOUNT_USER, count);
    nvram_set(key, item->user? : "");

    snprintf(key, sizeof(key), NV_KEY_FMT_VPNC_ACCOUNT_PASSWD, count);
    nvram_set(key, item->password? : "");

    nvram_set(NV_KEY_VPNC_ACCOUNT_COUNT, str_count);
    return 0;
}

int vpnc_setup_account_set(vpnc_account_ptr item)
{
    char key[NV_KEY_LENGTH_MAX];
    int id = atoi(item->id);

    /* @item mustn't be null and must be initialized */
    if (!item || !item->name)
        return -1;

    if (vpnc_setup_account_get_byid(atoi(item->id), NULL) < 0) {
        return -1;
    }

    // snprintf(key, sizeof(key), NV_KEY_FMT_VPNC_ACCOUNT_ID, id);
    //assert(id == atoi(nvram_get(key)));

    snprintf(key, sizeof(key), NV_KEY_FMT_VPNC_ACCOUNT_ENABLE, id);
    nvram_set(key, item->enabled? "1": "0");

    snprintf(key, sizeof(key), NV_KEY_FMT_VPNC_ACCOUNT_NAME, id);
    nvram_set(key, item->name? : "");

    snprintf(key, sizeof(key), NV_KEY_FMT_VPNC_ACCOUNT_PROTO, id);
    nvram_set(key, item->protocol? : "");

    snprintf(key, sizeof(key), NV_KEY_FMT_VPNC_ACCOUNT_PEER, id);
    nvram_set(key, item->peer? : "");

    snprintf(key, sizeof(key), NV_KEY_FMT_VPNC_ACCOUNT_USER, id);
    nvram_set(key, item->user? : "");

    snprintf(key, sizeof(key), NV_KEY_FMT_VPNC_ACCOUNT_PASSWD, id);
    nvram_set(key, item->password? : "");

    return 0;
}

static int nv_vpnc_account_unset(int id)
{
    char key[NV_KEY_LENGTH_MAX];
    snprintf(key, sizeof(key), NV_KEY_FMT_VPNC_ACCOUNT_ENABLE, id);
    nvram_unset(key);

    snprintf(key, sizeof(key), NV_KEY_FMT_VPNC_ACCOUNT_ID, id);
    nvram_unset(key);

    snprintf(key, sizeof(key), NV_KEY_FMT_VPNC_ACCOUNT_NAME, id);
    nvram_unset(key);

    snprintf(key, sizeof(key), NV_KEY_FMT_VPNC_ACCOUNT_PROTO, id);
    nvram_unset(key);

    snprintf(key, sizeof(key), NV_KEY_FMT_VPNC_ACCOUNT_PEER, id);
    nvram_unset(key);

    snprintf(key, sizeof(key), NV_KEY_FMT_VPNC_ACCOUNT_USER, id);
    nvram_unset(key);

    snprintf(key, sizeof(key), NV_KEY_FMT_VPNC_ACCOUNT_PASSWD, id);
    nvram_unset(key);

    return 0;
}

/**
 * Descend the IDs of accounts after @pos.
 * When an account is being deleted, those accounts, whose ID is higher, would
 * be moved toward a lower position.
 *
 * @pos starts from 1.
 */
static int nv_vpnc_account_descend_at(int pos)
{
    /* we know the count of all accounts */
    int count;
    char *str_count = nvram_safe_get(NV_KEY_VPNC_ACCOUNT_COUNT);
    // assert(str_count);
    count = atoi(str_count);

    /* move items downwards */
    vpnc_account_ptr next;
    int i;
    char i_str[6];

    for (i = pos + 1; i <= count; i++) {
        next = NULL;
        vpnc_setup_account_get_byid(i, &next);

        snprintf(i_str, sizeof(i_str), "%d", i - 1);
        vpnc_account_set_id(next, i_str);
        vpnc_setup_account_set(next);

        vpnc_account_release(next);
    }

    /* The old top is at i - 1, delete it. */
    nv_vpnc_account_unset(i - 1);

    /* reduce the count */
    if (pos <= count) {
        count--;
        snprintf(str_count, sizeof(str_count), "%d", count);
    }
    nvram_set(NV_KEY_VPNC_ACCOUNT_COUNT, str_count);

    /* commit */
    nvram_commit();
    return 0;
}

int vpnc_setup_account_del(const char *name)
{
    if (!name) {
        return -1;
    }

    int count = atoi(nvram_safe_get(NV_KEY_VPNC_ACCOUNT_COUNT));
    char key[NV_KEY_LENGTH_MAX];

    int i;
    for (i = 0; i < count; i++) {
        snprintf(key, sizeof(key), NV_KEY_FMT_VPNC_ACCOUNT_NAME, i + 1);
        if (strcmp(nvram_safe_get(key), name) == 0) {
            return vpnc_setup_account_del_byid(i + 1);
        }
    }
    return -1;
}

int vpnc_setup_account_del_byid(int id)
{
    return nv_vpnc_account_descend_at(id);
}

/**
 * Return 0 on success, otherwise, return a negative value, typically -1.
 *
 * Parameter @account is a pointer points to a vpnc_account_ptr object, it's
 * an _OUT_ parameter, which is used to store the found object. E.g.:
 *   {
 *     int id = 2;
 *     vpnc_account_ptr account;
 *     vpnc_account_ptr(id, &account);
 *   }
 *
 * If @account is NULL, this function could be used to check if there exists
 * an account whose ID is @id.
 *
 *    if (vpnc_setup_account_get_byid(3, NULL) < 0) {
 *        // No account's ID is 3
 *    }
 */
int vpnc_setup_account_get_byid(int id, vpnc_account_ptr *account)
{
    char key[NV_KEY_LENGTH_MAX];
    int enabled;
    char *str_id;
    char *name;
    char *proto;
    char *peer;
    char *user;
    char *password;

    snprintf(key, sizeof(key), NV_KEY_FMT_VPNC_ACCOUNT_ID, id);
    str_id = nvram_safe_get(key);

    if ((strcmp(str_id, "") == 0) || (atoi(str_id) != id)) {
        return -1;
    }

    snprintf(key, sizeof(key), NV_KEY_FMT_VPNC_ACCOUNT_ENABLE, id);
    enabled = atoi(nvram_safe_get(key));

    snprintf(key, sizeof(key), NV_KEY_FMT_VPNC_ACCOUNT_NAME, id);
    name = nvram_safe_get(key);

    snprintf(key, sizeof(key), NV_KEY_FMT_VPNC_ACCOUNT_PROTO, id);
    proto = nvram_safe_get(key);

    snprintf(key, sizeof(key), NV_KEY_FMT_VPNC_ACCOUNT_PEER, id);
    peer = nvram_safe_get(key);

    snprintf(key, sizeof(key), NV_KEY_FMT_VPNC_ACCOUNT_USER, id);
    user = nvram_safe_get(key);

    snprintf(key, sizeof(key), NV_KEY_FMT_VPNC_ACCOUNT_PASSWD, id);
    password = nvram_safe_get(key);

    if (account) {
        *account = vpnc_account_new();
        vpnc_account_set_enabled(*account, enabled);
        vpnc_account_set_id(*account, str_id);
        vpnc_account_set_name(*account, name);
        vpnc_account_set_proto(*account, proto);
        vpnc_account_set_peer(*account, peer);
        vpnc_account_set_user(*account, user);
        vpnc_account_set_password(*account, password);
    }
    return 0;
}

int vpnc_setup_account_get_byname(const char *name, vpnc_account_ptr *account)
{
    if (!name)
        return -1;

    /* we know the count of the total accounts */
    int count;
    char *str_count = nvram_safe_get(NV_KEY_VPNC_ACCOUNT_COUNT);
    // assert(str_count);
    count = atoi(str_count);

    char key[NV_KEY_LENGTH_MAX];
    int i;
    for (i = 0; i < count; i++) {
        snprintf(key, sizeof(key), NV_KEY_FMT_VPNC_ACCOUNT_NAME, i+1);
        if (strcmp(nvram_safe_get(key), name) == 0) { /* found */
            /*
             * There should be an assertion that the key's index number is the same
             * as the corresponding account object's ID, in another word, there
             * exists an equation value_of(vpnc(X)_id) == X, like:
             *   # nvram get vpnc3_id
             *   > 3
             *
             * omitted assertion code:
             *
             *   snprintf(key, sizeof(key), NV_KEY_FMT_VPNC_ACCOUNT_ID, i+1);
             *   assert((i+1) == atoi(nvram_safe_get(key)));
             */
            return vpnc_setup_account_get_byid(i+1, account);
        }
    }
    return -1;
}

