#include "libphi_cgi.h"

/*=============================================================================
 * Function Name : get_screen_set_conf
 * Description   : Use nvram handler function to get confs,
 *                 return error_code and output confs in the json object format
 * Format        :
 *       {
 *          "screen_time" : "0",
 *			"show_wireless_pwd" : "1",
 *			"show_guestwifi_pwd" : "1"
 *       }
 * Description   : Use nvram handler function to get confs,return success or fail
 *============================================================================*/

int get_screen_set_conf(json_object *object)
{
	int ret = NV_SUCCESS;
	char *screen_time = NULL;
	char *show_wireless_pwd = NULL;
	char *show_guestwifi_pwd = NULL;

	screen_time = nvram_get("screen_time");
	show_wireless_pwd = nvram_get("screen_2G5G_pwd_en");
	show_guestwifi_pwd = nvram_get("screen_guest_pwd_en");

	json_object *myobject = NULL;
	myobject = json_object_new_object();
	if (screen_time && show_guestwifi_pwd && show_wireless_pwd)
	{
		json_object_object_add(myobject, "screen_time", json_object_new_string(screen_time));
		json_object_object_add(myobject, "wifi_pwd_show", json_object_new_string(show_wireless_pwd));
		json_object_object_add(myobject, "guest_pwd_show", json_object_new_string(show_guestwifi_pwd));
		json_object_object_add(object, "confs", myobject);
	}
	else
		ret = NV_FAIL;

	return ret;
}

/*=============================================================================
 * Function Name : set_screen_set_conf
 * Param         : json object format
 * Format        :
 *       {
 *           "screen_time" : "0",
 *           "show_wireless_pwd" : "1",
 *           "show_guestwifi_pwd" : "1"
 *       }
 * Description   : Use nvram handler function to set confs,return success or fail
 *===========================================================================*/

 int set_screen_set_conf(json_object *object)
 {
 	char screen_time[8] = {0};
 	char show_wireless_pwd[8] = {0};
 	char show_guestwifi_pwd[8] = {0};

 	json_object_object_foreach(object, key, val)
 	{
 		if (!strcmp(key, "screen_time"))
 		{
 			strcpy(screen_time, json_object_get_string(val));
 		}
 		else if (!strcmp(key, "wifi_pwd_show"))
 		{
 			strcpy(show_wireless_pwd, json_object_get_string(val));
 		}
 		else if (!strcmp(key, "guest_pwd_show"))
 		{
 			strcpy(show_guestwifi_pwd, json_object_get_string(val));
 		}
 	}

 	//cgi_debug("screen_time=%s, screen_2G5G_pwd_en=%s, screen_guest_pwd_en=%s\n", screen_time, show_wireless_pwd, show_guestwifi_pwd);

 	nvram_set("screen_time", screen_time);
	nvram_set("screen_2G5G_pwd_en", show_wireless_pwd);
	nvram_set("screen_guest_pwd_en", show_guestwifi_pwd);

	nvram_commit();
	system("uhmiMsg screenset");
	return NV_SUCCESS;
 }
