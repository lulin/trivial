#include "libphi_cgi.h"

#include <oui.h>
#include <dhcpd.h>
#include <ip_ctl.h>
#include <firewall.h>
#include <fcntl.h>
#include <arpa/inet.h>
#include "wlcr_main.h"
#include "wlcr_shared.h"
#include <signal.h>
#include <notify.h>
#include <oid.h>
#include <sys/sysinfo.h>

#include "device_manage.h"

/* This file created by uhmi, here just parse it. */
#define VENDOR_FILE		"/usr/sbin/oui.txt"


#ifndef FW_DB
#define FW_DB	1
#endif

struct lease_t {
	unsigned char chaddr[16];
	u_int32_t yiaddr;
	u_int32_t expires;
	char hostname[64];
};

enum {
	CLIENT_STATUS_IFTYPE_2G = 1,
	CLIENT_STATUS_IFTYPE_5G,
	CLIENT_STATUS_IFTYPE_GUEST,
	CLIENT_STATUS_IFTYPE_WIRE
};

struct dev_list_count{
	uint8 num_2g;
	uint8 num_5g;
	uint8 num_guest;
	uint8 num_wire;
};


int add_entry_to_link(dev_status **p_link, const dev_status *p_entry)
{
	dev_status *p_cur = *p_link, *p_tmp = NULL;

	if(p_link == NULL || p_entry == NULL)
	{
		cgi_debug("get link error or the entry is empty!\n");
		return -1;
	}

	if( p_cur != NULL )
	{
		while( p_cur->p_next != NULL )
		{
			p_cur = p_cur->p_next;
		}
	}

	p_tmp = (dev_status *)malloc(sizeof(dev_status));
	if(p_tmp == NULL)
	{
		cgi_debug( "client_status link: malloc fail.\n" );
		return -1;
	}
	memset(p_tmp, 0x0, sizeof(dev_status));
	memcpy(p_tmp, p_entry, sizeof(dev_status));

	p_tmp->p_next = NULL;

	if( p_cur == NULL )
		*p_link = p_tmp;
	else
		p_cur->p_next = p_tmp;

	return 0;
}

int fresh_dev_status_link(dev_status *p_head)
{
	int idx = 0;
	dev_status *p_cur = p_head;

	while( p_cur != NULL )
	{
		++idx;
		p_cur->i_idx = idx;
		p_cur = p_cur->p_next;
	}

	return idx;
}

int free_dev_status_link(dev_status *p_head)
{
	dev_status *p_cur = NULL, *p_tmp = NULL;

	p_cur = p_head;
	while(p_cur)
	{
		p_tmp = p_cur->p_next;
		free(p_cur);
		p_cur = p_tmp;
	}
	return 0;
}


/*
 * display all client info, just for debug
 */
int display_link(dev_status *p_head)
{
	dev_status *p_cur = NULL;
	char *msg = NULL;

	if(p_head == NULL)
		return 0;

	msg = (char *)malloc((HOSTS_MAX + 1) * 118 + 1); // msg line max:118
	if(msg == NULL)
	{
		cgi_debug( "malloc fail.\n" );
		return -1;
	}

	memset(msg, 0x0, HOSTS_MAX * HOST_NAME_LEN);
	sprintf(msg, "\n");
	sprintf(msg+strlen(msg), "%-18s%-16s%-10s%-5s%-5s%-32s%-s\n",
			"MAC", "IP", "interface", "tx", "rx", "hostname", "rename");

	p_cur = p_head;
	while(p_cur != NULL)
	{
		sprintf(msg+strlen(msg), "%-18s", p_cur->mac);
		sprintf(msg+strlen(msg), "%-16s", p_cur->ip);
		sprintf(msg+strlen(msg), "%-10d", p_cur->if_type);
		sprintf(msg+strlen(msg), "%-5u", p_cur->txByte);
		sprintf(msg+strlen(msg), "%-5u", p_cur->rxByte);
		sprintf(msg+strlen(msg), "%-32s", p_cur->hostname);
		sprintf(msg+strlen(msg), "%-s", p_cur->rename);
		sprintf(msg+strlen(msg), "\n");

		p_cur = p_cur->p_next;
	}
	cgi_debug("display device list link:%s\n", msg);

	free(msg);

	return 0;
}

/*
 * display one client info, just for debug
 */
int display_entry(dev_status *p_entry)
{
	dev_status *p_cur = NULL;
	char msg[2 * 118 + 1];

	memset(msg, 0x0, sizeof(msg));
	sprintf(msg, "\n");
	sprintf(msg+strlen(msg), "%-18s%-16s%-10s%-5s%-5s%-32s%-s\n",
			"MAC", "IP", "interface", "tx", "rx", "host", "rename");

	p_cur = p_entry;
	if (p_cur != NULL)
	{
		sprintf(msg+strlen(msg), "%-18s", p_cur->mac);
		sprintf(msg+strlen(msg), "%-16s", p_cur->ip);
		sprintf(msg+strlen(msg), "%-10d", p_cur->if_type);
		sprintf(msg+strlen(msg), "%-5u", p_cur->txByte);
		sprintf(msg+strlen(msg), "%-5u", p_cur->rxByte);
		sprintf(msg+strlen(msg), "%-32s", p_cur->hostname);
		sprintf(msg+strlen(msg), "%-s", p_cur->rename);
		sprintf(msg+strlen(msg), "\n");
	}
	cgi_debug("display device entry:%s\n", msg);

	return 0;
}


/*
 * Copy list info from shared-memory.
 *
 */
int get_dev_list_from_shm(dev_status **p_link, struct dev_list_count *p_count_s)
{
	dev_status tmp;
	struct flock lk_info = {0};
	int lock_fd = -1;
	int sum = 0;
	int retry;
	char buff[TERMNG_SHARED_SPACE] = {0};
	struct _wlcr *wlcr_p = NULL;
	int i;

	if (p_link == NULL && p_count_s == NULL)
		return -1;
	retry = 3;
	while (--retry)
	{
		lock_fd = open(WLCR_LOCK_FILE, O_RDWR|O_CREAT, 0666);
		if (lock_fd < 0)
		{
			cgi_debug("lock_fd try open fail\n");
		}
		else
		{
			break;
		}
		usleep(20); //sleep 20 ms, and try again
	}
	if (!retry)
	{
		cgi_debug("lock_fd open fail\n");
		return -1;
	}

	retry = 3;
	while (--retry)
	{
		lk_info.l_type = F_WRLCK;
		lk_info.l_whence = SEEK_SET;
		lk_info.l_start = 0;
		lk_info.l_len = 0;
		if (!fcntl(lock_fd, F_SETLKW, &lk_info))
			break;
	}
	if (!retry) {
		cgi_debug("Failed locking LOCK_FILE\n");
		close(lock_fd);
		unlink(WLCR_LOCK_FILE);
		return -1;
	}

	memset(buff, 0x00, sizeof(buff));
	devm_shared_read(buff, TERMNG_SHARED_SPACE);
	wlcr_p = (struct _wlcr *)buff;

	sum = wlcr_p->list_2g.count + wlcr_p->list_5g.count + wlcr_p->list_guest.count + wlcr_p->list_wire.count;
	if (p_count_s != NULL)
	{
		p_count_s->num_2g = wlcr_p->list_2g.count;
		p_count_s->num_5g = wlcr_p->list_5g.count;
		p_count_s->num_guest = wlcr_p->list_guest.count;
		p_count_s->num_wire = wlcr_p->list_wire.count;
	}
	if (p_link != NULL)
	{
		for (i = 0; i < wlcr_p->list_2g.count; i++)
		{
			memset(&tmp, 0x0, sizeof(tmp));
			strncpy(tmp.mac, wlcr_p->list_2g.info[i].str_mac, DEV_MAC_LEN - 1);
			strncpy(tmp.ip, wlcr_p->list_2g.info[i].str_ip, DEV_IP_LEN - 1);
			tmp.if_type = CLIENT_STATUS_IFTYPE_2G;
			tmp.txByte = wlcr_p->list_2g.info[i].rate_tx;
			tmp.rxByte = wlcr_p->list_2g.info[i].rate_rx;
			tmp.join_time = wlcr_p->list_2g.info[i].join_time;
			tmp.online_flags = CLIENT_STATUS_ONLINE;
			add_entry_to_link(p_link, &tmp);
		}

		for (i = 0; i < wlcr_p->list_5g.count; i++)
		{
			memset(&tmp, 0x0, sizeof(tmp));
			strncpy(tmp.mac, wlcr_p->list_5g.info[i].str_mac, DEV_MAC_LEN - 1);
			strncpy(tmp.ip, wlcr_p->list_5g.info[i].str_ip, DEV_IP_LEN - 1);
			tmp.if_type = CLIENT_STATUS_IFTYPE_5G;
			tmp.txByte = wlcr_p->list_5g.info[i].rate_tx;
			tmp.rxByte = wlcr_p->list_5g.info[i].rate_rx;
			tmp.join_time = wlcr_p->list_5g.info[i].join_time;
			tmp.online_flags = CLIENT_STATUS_ONLINE;
			add_entry_to_link(p_link, &tmp);
		}

		for (i = 0; i < wlcr_p->list_guest.count; i++)
		{
			memset(&tmp, 0x0, sizeof(tmp));
			strncpy(tmp.mac, wlcr_p->list_guest.info[i].str_mac, DEV_MAC_LEN - 1);
			strncpy(tmp.ip, wlcr_p->list_guest.info[i].str_ip, DEV_IP_LEN - 1);
			tmp.if_type = CLIENT_STATUS_IFTYPE_GUEST;
			tmp.txByte = wlcr_p->list_guest.info[i].rate_tx;
			tmp.rxByte = wlcr_p->list_guest.info[i].rate_rx;
			tmp.join_time = wlcr_p->list_guest.info[i].join_time;
			tmp.online_flags = CLIENT_STATUS_ONLINE;
			add_entry_to_link(p_link, &tmp);
		}

		for (i = 0; i < wlcr_p->list_wire.count; i++)
		{
			memset(&tmp, 0x0, sizeof(tmp));
			strncpy(tmp.mac, wlcr_p->list_wire.info[i].str_mac, DEV_MAC_LEN - 1);
			strncpy(tmp.ip, wlcr_p->list_wire.info[i].str_ip, DEV_IP_LEN - 1);
			tmp.if_type = CLIENT_STATUS_IFTYPE_WIRE - 4;
			tmp.txByte = wlcr_p->list_wire.info[i].rate_tx;
			tmp.rxByte = wlcr_p->list_wire.info[i].rate_rx;
			tmp.join_time = wlcr_p->list_wire.info[i].join_time;
			tmp.online_flags = wlcr_p->list_wire.info[i].online;
			add_entry_to_link(p_link, &tmp);
		}
	}

	// remove lock file
	close(lock_fd);
	unlink(WLCR_LOCK_FILE);

	return sum;
}

static int
sync_hostname_leasetime_to_link(dev_status **p_head, struct lease_t *p_lease, u_int32_t lan_lease)
{
	int ret;
	char mac[32] = {0};
	char ip[32] = {0};
	dev_status *p_cur = NULL;
	u_int32_t expires;
	dev_status tmp;
	struct in_addr addr;

	addr.s_addr = p_lease->yiaddr;
	expires = ntohl(p_lease->expires);
	sprintf(mac, "%02X:%02X:%02X:%02X:%02X:%02X",
			p_lease->chaddr[0], p_lease->chaddr[1], p_lease->chaddr[2],
			p_lease->chaddr[3], p_lease->chaddr[4], p_lease->chaddr[5]);
	sprintf(ip, "%s", inet_ntoa(addr)?:"0.0.0.0");

//	cgi_debug("parse leases: mac=[%s], ip=[%s], hostname=[%s]\n", mac, inet_ntoa(addr), p_lease->hostname);

	ret = -1;
	p_cur = *p_head;
	while(p_cur != NULL)
	{
		if(strncasecmp(p_cur->mac, mac, DEV_MAC_LEN - 1) == 0
			|| (strncmp("00:00:00:00:00:00", mac, 17) == 0
				&& strncmp(p_cur->ip, ip, DEV_IP_LEN - 1) == 0))
		{
			strncpy(p_cur->hostname, p_lease->hostname, NVRAM_RENAME_LEN - 1);
			p_cur->lease_time = lan_lease - expires;
			if(strlen(p_cur->ip) < 7)
			{
				strncpy(p_cur->ip, ip, DEV_IP_LEN - 1);
			}
			ret = 0;
		}
		p_cur = p_cur->p_next;
	}

	//offline device info add to list
	if (ret != 0)
	{
		memset(&tmp, 0x0, sizeof(tmp));
		strncpy(tmp.mac, mac, DEV_MAC_LEN-1);
		strncpy(tmp.ip, ip, DEV_IP_LEN-1);
		strncpy(tmp.hostname, p_lease->hostname, NVRAM_RENAME_LEN - 1);
		tmp.lease_time = lan_lease - expires;
		tmp.online_flags = CLIENT_STATUS_OFFLINE;

		add_entry_to_link(p_head, &tmp);
	}

	return ret;
}


/*
 * get client hostname from udhcpd lease file.
 * by the way, get online time(lan_lease - expires), because APP's CGI need it
 */
static int
get_dev_status_hostname(dev_status **p_head)
{
	FILE *fp_leases = NULL;
	struct lease_t lease;
	int index, num_interfaces=0;
	char path_lease[64];
	char sigline[] = "-XX";
	u_int32_t lan_lease = 0;

	/* Write out leases file */
	// SIGUSR1's default action is the end of the process
//	sprintf(sigline, "-%d", SIGUSR1);
	sprintf(sigline, "-%d", SIGCHLD);
	eval("killall", sigline, "udhcpd");

	/* Count the number of lan and guest interfaces */
	if (nvram_get("lan_ifname"))
		num_interfaces++;
	if (nvram_get("lan1_ifname"))
		num_interfaces++;

	lan_lease = atoi(nvram_safe_get("lan_lease"));

	for (index = 0; index < num_interfaces; index++)
	{
		snprintf(path_lease, sizeof(path_lease), "/tmp/udhcpd%d.leases", index);

		if (!(fp_leases= fopen(path_lease, "r")))
		{
//			cgi_debug("open file %s error\n", path_lease);
			continue;
		}

		while (fread(&lease, sizeof(lease), 1, fp_leases))
		{
			/* Do not display reserved leases */
			if (ETHER_ISNULLADDR(lease.chaddr))
			{
				cgi_debug("parse leases IP error\n");
				continue;
			}

			sync_hostname_leasetime_to_link(p_head, &lease, lan_lease);
		}
		fclose(fp_leases);
	}

	return 0;
}


/*
 * rename nvram like: dev_rename="d8:42:ac:11:22:33,phicomm"
 */
static int
get_dev_status_rename(dev_status **p_head)
{
	dev_status *p_cur = NULL;
	char *rules = nvram_safe_get(NVRAM_RENAME);
	char rec[256];
	char mac[DEV_MAC_LEN];
	char rename[NVRAM_RENAME_LEN];
	int i;
	int ret;
	dev_status tmp;
	char s_base64[NVRAM_RENAME_LEN * 2];

	if(strlen(rules) == 0)
		return -1;

	//cgi_debug("get rules %s=%s\n", NVRAM_RENAME, rules);

	i = 0;
	while (getNthValueSafe(i++, rules, ';', rec, sizeof(rec)) != -1)
	{
		//i++;
		if ((getNthValueSafe(0, rec, ',', mac, sizeof(mac)) == -1))
		{
			continue;
		}
		if ((getNthValueSafe(1, rec, ',', s_base64, sizeof(s_base64)) == -1))
		{
			continue;
		}
		websDecode64(rename, s_base64, sizeof(rename));

		ret = 0;
		p_cur = *p_head;
		while (p_cur != NULL)
		{
			if(strncasecmp (p_cur->mac, mac, DEV_MAC_LEN - 1) == 0)
			{
				ret = 1;
				strncpy(p_cur->rename, rename, NVRAM_RENAME_LEN - 1);
				break;
			}
			p_cur = p_cur->p_next;
		}

		if (ret == 1)
		{
			continue;
		}
		else
		{
			memset(&tmp, 0x0, sizeof(tmp));
			strncpy(tmp.mac, mac, DEV_MAC_LEN - 1);
			strncpy(tmp.rename, rename, NVRAM_RENAME_LEN - 1);
			tmp.online_flags = CLIENT_STATUS_OFFLINE;

			add_entry_to_link(p_head, &tmp);
		}
	}

	return 0;
}

/*
 * limit nvram: option=mac,uplimit,downlimit
 * e.g.
 * dev_ratelimit="d8:42:ac:11:22:33,100,200"
 */
static int
get_dev_status_limit(dev_status *p_head)
{
	char *rules = nvram_safe_get(NVRAM_IPCTL_RULES);
	char rec[128];
	char mac[DEV_MAC_LEN];
	char ip[DEV_IP_LEN];
	char up[16];
	char down[16];
	dev_status *p_cur = NULL;
	int i;

	if(strlen(rules) == 0)
		return -1;

//	cgi_debug("get rules %s=%s\n", NVRAM_IPCTL_RULES, rules);

	i = 0;
	while(getNthValueSafe(i++, rules, ';', rec, sizeof(rec)) != -1 && strlen(rec))
	{
		if((getNthValueSafe(0, rec, ',', mac, sizeof(mac)) == -1)) //cell:mac
		{
			continue;
		}
		if((getNthValueSafe(1, rec, ',', ip, sizeof(ip)) == -1)) //cell:ip
		{
			continue;
		}
		if((getNthValueSafe(2, rec, ',', up, sizeof(up)) == -1)) //cell:up_max
		{
			continue;
		}
		if((getNthValueSafe(3, rec, ',', down, sizeof(down)) == -1)) //cell:down_max
		{
			continue;
		}

		p_cur = p_head;
		while(p_cur != NULL)
		{
			if(strncasecmp(mac, p_cur->mac, DEV_MAC_LEN - 1) == 0)
			{
				p_cur->limit_up = strtoul(up, NULL, 10) / 8;     //Kbit -> KB
				p_cur->limit_down = strtoul(down, NULL, 10) / 8;
				break;
			}
			p_cur = p_cur->p_next;
		}
	}

	return 0;
}

/*
 * limit nvram: dev_block="d8:42:ac:11:22:33;d8:42:ac:11:22:44"
 */
static int
get_dev_status_deny(dev_status **p_head)
{
	char *rules = nvram_safe_get(NVRAM_DEVDENY);
	char mac[32];
	dev_status *p_cur = NULL;
	int i;
	int ret;
	dev_status tmp;

	if(strlen(rules) == 0)
		return -1;

	i = 0;
	while(getNthValueSafe(i++, rules, ';', mac, sizeof(mac)) != -1)
	{
		ret = 0;
		p_cur = *p_head;
		while(p_cur != NULL)
		{
			if(strncasecmp(mac, p_cur->mac, DEV_MAC_LEN - 1) == 0)
			{
				ret = 1;
				p_cur->deny = 1;
				break;
			}
			p_cur = p_cur->p_next;
		}

		if (ret != 1)
		{
			memset(&tmp, 0x0, sizeof(tmp));
			strncpy(tmp.mac, mac, DEV_MAC_LEN - 1);
			tmp.deny = 1;
			tmp.online_flags = CLIENT_STATUS_OFFLINE;

			add_entry_to_link(p_head, &tmp);
		}
	}

	return 0;
}


static int
get_dev_status_brand(dev_status *p_head)
{
	dev_status *p_cur = NULL;

    /**
     * We don't check if @oui is returned NULL or not here, because function
     * @get_vendor_name guarantees a value "Unknown" being returned in the 3rd
     * parameter, which must be a length enough buffer, in any error cases.
     */
    oui_handler_t oui = load_available_oui();

    for (p_cur = p_head; p_cur; p_cur = p_cur->p_next) {
        get_vendor_name(oui, p_cur->mac, p_cur->brand, DEV_VENDOR_LEN);
    }

    if (oui != NULL)
        release_oui(oui);

	return 0;
}

static int
create_dev_list(dev_status **p_link)
{
	dev_status *p_head = *p_link;


	/* get dev list from /tmp/maclist_info */
	get_dev_list_from_shm(p_link, NULL);

	/* fresh number */
	fresh_dev_status_link(p_head);

	return 0;
}


static int
set_dev_deny(const char *mac, int deny)
{
	int i_idx;
	int found = 0;
	char rec[128];
	char buff[2048];

	char *rules = nvram_safe_get(NVRAM_DEVDENY);

//	cgi_debug("get %s=%s, var mac=%s, var deny=%d\n", NVRAM_DEVDENY, rules, mac, deny);

	i_idx = 0;
	memset(buff, 0x0, sizeof(buff));
    while(getNthValueSafe(i_idx++, rules, ';', rec, sizeof(rec)) != -1)
    {

		if(strncasecmp(rec, mac, DEV_MAC_LEN - 1) == 0)
		{
			found = 1;
			if(deny == 0)
				continue;
		}
		if(strlen(buff) > 16)
			strcat(buff, ";");
		strcat(buff, rec);
    }

	if(found != 1 && deny == 1)
	{
		if(strlen(buff) > 16)
			strcat(buff, ";");
		strcat(buff, mac);
	}

	nvram_set(NVRAM_DEVDENY, buff);
	nvram_commit();
	notification_send_rc( OID_SERVICE_BLOCKMAC, NOTIFY_WAIT );

	return 0;
}

static int
set_dev_limit(const char *mac, const char *ip, int limit_up, int limit_down)
{
	ip_ctl_t *p_head = NULL, *p_cur = NULL;
	ip_ctl_t entry;
	int result = 0;
	int idx;
	char s_ip[DEV_IP_LEN] = "0.0.0.0";
	char *p_ip = NULL;
	p_ip = ip;
	if(p_ip == NULL || strlen(p_ip) == 0)
	{
		p_ip = s_ip;
	}

	memset(&entry, 0x0, sizeof(entry));
	entry.i_enable = 1;
	strncpy(entry.s_ip, p_ip, IP_CTL_RULE_NETADDR_SIZE-1);
	strncpy(entry.s_mac, mac, IP_CTL_RULE_MACADDR_SIZE-1);
	entry.ul_up_speed = (limit_up < 0) ? 0 : limit_up * 8;
	entry.ul_dw_speed = (limit_down < 0) ? 0 : limit_down * 8;

	ip_ctl_read_link(&p_head);

	p_cur = p_head;
	idx = 0;
	result = 0;
	while(p_cur != NULL)  //find which one edit
	{
		if(strncasecmp(p_cur->s_mac, entry.s_mac, IP_CTL_RULE_MACADDR_SIZE - 1) == 0)
		{
			if( entry.ul_up_speed == p_cur->ul_up_speed && entry.ul_dw_speed == p_cur->ul_dw_speed)
			{
				cgi_debug("limit not change\n");
				return 0;
			}
			idx = p_cur->i_idx;

			// sync to entry
			if(limit_up == 0 && limit_down == 0)
			{
				ip_ctl_delete_rule(&p_head, idx);
				result = 1;
			}
			else
			{
				if(limit_down >= 0)
				{
					result = 2;
					p_cur->ul_dw_speed = limit_down * 8;
				}
				if(limit_up >= 0)
				{
					result = 3;
					p_cur->ul_up_speed = limit_up * 8;
				}
			}
			break;
		}
		p_cur = p_cur->p_next;
	}

	//if not exist, add it.
	if(idx == 0 && (limit_up > 0 || limit_down > 0))
	{
		ip_ctl_add_link(&p_head, &entry);
		result = 4;
	}


	if (result != 0)
	{
		ip_ctl_write_link(p_head);

		//firewall module restart when wan connected!
		if (nvram_match("get_wan_port_status", "1"))
		{
			ip_ctl_disable();
			ip_ctl_enable();
		}
	}

	ip_ctl_free(p_head);

	return 0;
}

static int
set_dev_rename(const char *mac, const char *rename)
{
	char rec[256];
	char s_mac[DEV_MAC_LEN];
	char s_rename[NVRAM_RENAME_LEN * 2];
	char s_tmp[DEV_MAC_LEN + NVRAM_RENAME_LEN * 2 + 1];
	char buff[4096];
	int i_idx;
	int found = 0;
	char name_buf[NVRAM_RENAME_LEN] = {0};
	char s_base64[NVRAM_RENAME_LEN * 2] = {0};

	char *rules = nvram_safe_get(NVRAM_RENAME);

	if (rename == NULL)
		strncpy(name_buf, "", sizeof(name_buf)-1);
	else
		strncpy(name_buf, rename, sizeof(name_buf)-1);

	base64_encode(name_buf, strlen(name_buf), s_base64);

//	cgi_debug("get nvram %s=%s, rename=[%s]\n", NVRAM_RENAME, rules, name_buf);

	memset(buff, 0x0, sizeof(buff));
    i_idx = 0;
	while(getNthValueSafe(i_idx++, rules, ';', rec, sizeof(rec)) != -1)
	{
		//i_idx++;
		if((getNthValueSafe(0, rec, ',', s_mac, sizeof(s_mac)) == -1))
		{
			continue;
		}
		if((getNthValueSafe(1, rec, ',', s_rename, sizeof(s_rename)) == -1))
		{
			continue;
		}

		if(strncasecmp(s_mac, mac, DEV_MAC_LEN - 1) == 0)
		{
			found = 1;
			if (rename != NULL && !strncmp(s_rename, s_base64, strlen(s_base64)))
			{
				cgi_debug("name is not change\n");
				return 0;
			}
			if(strlen(name_buf) > 0)
			{
				memset(s_rename, 0x0, sizeof(s_rename));
				strncpy(s_rename, s_base64, NVRAM_RENAME_LEN * 2 - 1);
			}
			else
				continue;
		}
		sprintf(s_tmp, "%s,%s", s_mac, s_rename);

		if(strlen(buff) > 16)
			strcat(buff, ";");
		strcat(buff, s_tmp);
    }
	if(found != 1 && strlen(name_buf) > 0)
	{
		sprintf(s_tmp, "%s,%s", mac, s_base64);
		if(strlen(buff) > 1)
			strcat(buff, ";");
		strcat(buff, s_tmp);
	}

	nvram_set(NVRAM_RENAME, buff);
	nvram_commit();

	return 0;
}


/*=============================================================================
 * Function Name : get_device_mng_conf
 * Description   : Use nvram handler function to get confs,
 *                 return error_code and output confs in the json object format
 * Para Format   :
         {
            "name" : "iPhone",
            "ip" = "192.168.2.100",
            "mac" = "00:CD:FE:DF:D7:48",
            "internet_enable" = "1",
            "upload_speed" = "123",
            "download_speed" = "456",
            "upload_limit" = "51200",
            "download_limit" = "1024000",
            "online_status" = "1",
            "online_time" = "3600",
            "device_type" = "1"
        }
 * Description   : Use nvram handler function to get confs,return success or fail
 *===========================================================================*/
 int get_device_mng_conf(json_object *object)
{
	int ret = NV_SUCCESS;
	dev_status *p_link = NULL, *p_cur = NULL;
	char host_str[HOST_NAME_LEN];
	json_object *my_object = NULL;
	json_object *my_array = NULL;
	struct sysinfo s_info;
	long online_t;

	/* create new list */
	create_dev_list(&p_link);

	//display_link(p_link); //just for debug

	get_dev_status_hostname(&p_link);

	get_dev_status_rename(&p_link);

	get_dev_status_limit(p_link);

	get_dev_status_deny(&p_link);

    get_dev_status_brand(p_link);

	//display_link(p_link); //just for debug

	sysinfo(&s_info);
	

	/* format to json */
	p_cur = p_link;
	my_array = json_object_new_array();
	while(p_cur != NULL)
	{
		//display_entry(p_cur); //just for debug

		/* skip someone no ip but online in the wireless driver */
		if (strlen(p_cur->ip) == 0 && p_cur->online_flags == 1)
		{
			p_cur = p_cur->p_next;
			continue;
		}
		my_object = json_object_new_object();
		json_object_object_add(my_object, "mac", json_object_new_string(p_cur->mac));
		json_object_object_add(my_object, "ip", json_object_new_string(p_cur->ip));

		if(strlen(p_cur->rename) > 0)
		{
			json_object_object_add(my_object, "name", json_object_new_string(p_cur->rename));
		}
		else if(strlen(p_cur->hostname) > 0)//translate chinese code GB2312 to UTF-8
		{
			memset(host_str, 0x0, sizeof(host_str));
			strncpy(host_str, p_cur->hostname, sizeof(host_str)-1);
			json_object_object_add(my_object, "name", json_object_new_string(host_str));
		}
		else
		{
			json_object_object_add(my_object, "name", json_object_new_string("Unknown"));
		}
		json_object_object_add(my_object, "internet_enable", json_object_new_int(p_cur->deny == 1 ? 0 : 1));
		json_object_object_add(my_object, "upload_limit", json_object_new_int(p_cur->limit_up));
		json_object_object_add(my_object, "download_limit", json_object_new_int(p_cur->limit_down));

		json_object_object_add(my_object, "download_speed", json_object_new_int64(p_cur->rxByte));

		json_object_object_add(my_object, "upload_speed", json_object_new_int64(p_cur->txByte));

		json_object_object_add(my_object, "online_status", json_object_new_int(1 == p_cur->deny ? 0 : p_cur->online_flags)); //for UI's request, KB-286

		json_object_object_add(my_object, "device_type", json_object_new_int(p_cur->if_type));

		online_t = s_info.uptime - p_cur->join_time;
		json_object_object_add(my_object, "online_time", json_object_new_int((int)online_t));

        json_object_object_add(my_object, "brandName", json_object_new_string(p_cur->brand));

		json_object_array_add(my_array, my_object);

		p_cur = p_cur->p_next;
	}
	json_object_object_add(object,"confs",my_array);

	free_dev_status_link(p_link);

	return ret;
}

/*=============================================================================
 * Function Name : set_device_mng_conf
 * Param         : json object format
 * Format        :
 *      {
 *          "name" : "iPhone",
 *           "ip" = "192.168.2.100",
 *           "mac" = "00:CD:FE:DF:D7:48",
 *           "internet_enable" = "1",
 *           "upload_limit" = "0",
 *           "download_limit" = "4096"
 *       }
 * Description   : Use nvram handler function to set confs,return success or fail
 *===========================================================================*/
 int set_device_mng_conf(json_object *object)
 {
	char mac[DEV_MAC_LEN] = {0};
	char ip[DEV_IP_LEN] = {0};
	char rename[NVRAM_RENAME_LEN] = {0};
	char deny[8] = {0};
	char up_limit[16] = {0};
	char down_limit[16] = {0};
	int  enable = 0;
	int i_up = 0;
	int i_down = 0;
	int ret = NV_SUCCESS;
	json_object_object_foreach(object, key, val)
	{
		if(!strcmp(key, "name"))
		{
			strncpy(rename, json_object_get_string(val), sizeof(rename));
		}
		else if(!strcmp(key, "mac"))
		{
			strncpy(mac, json_object_get_string(val), sizeof(mac));
		}
		else if(!strcmp(key, "ip"))
		{
			strncpy(ip, json_object_get_string(val), sizeof(ip));
		}
		else if(!strcmp(key, "internet_enable"))
		{
			strncpy(deny, json_object_get_string(val), sizeof(deny));
		}
		else if(!strcmp(key, "upload_limit"))
		{
			strncpy(up_limit, json_object_get_string(val), sizeof(up_limit));
		}
		else if(!strcmp(key, "download_limit"))
		{
			strncpy(down_limit, json_object_get_string(val), sizeof(down_limit));
		}
		else
		{
			cgi_debug("invalid key, please check!!!\n");
		}
	}
	if (strlen(mac) && strlen(ip))
	{
		/*****set rename rule*****/
		if(strlen(rename))
			set_dev_rename(mac, rename);
		else
			cgi_debug("rename is empty\n");
		/*****set deny rule*****/
		if(strlen(deny))
		{
			enable = atoi(deny) == 1? 0 : 1;
			set_dev_deny(mac, enable);
		}
		else
			cgi_debug("deny is empty\n");
		/*****set limit rule*****/
		if(strlen(up_limit) || strlen(down_limit))
		{
			if (strlen(up_limit))
			{
				i_up = atoi(up_limit);
			}
			else
				i_up = -1;
			if (strlen(down_limit))
			{
				i_down = atoi(down_limit);
			}
			else
				i_down = -1;
			set_dev_limit(mac, ip, i_up, i_down);
		}
	}
	else
		cgi_debug("mac or ip is null,please check!!\n");
	return ret;
 }
