#include "libphi_cgi.h"


/*=============================================================================
 * Function Name : get_safe_set_conf
 * Description   : Use nvram handler function to get confs,
 *                 return error_code and output confs in the json object format
 * Format        :
 *       {
 *         "enable" : "1", 
 *         "dos" : "1", 
 *         "icmp_flood" : "1", 
 *         "icmp_threshold" : "500", 
 *         "udp_flood" : "1", 
 *         "udp_threshold" : "500", 
 *         "tcp_flood" : "1", 
 *         "tcp_threshold" : "500", 
 *         "ping_disable" : "1" 
 *       }
 * Description   : Use nvram handler function to get confs,return success or fail
 *============================================================================*/

int get_safe_set_conf(json_object *object)
{
	int ret = NV_SUCCESS;

	char *enable = NULL;
	char *dos = NULL;
	char *icmp_flood = NULL;
	char *icmp_threshold = NULL;
	char *udp_flood = NULL;
	char *udp_threshold = NULL;
	char *tcp_flood = NULL;
	char *tcp_threshold = NULL;
	char *ping_disable = NULL;


	enable = nvram_get("firewall_enable");
	dos = nvram_get("dos_enable");
	icmp_flood = nvram_get("icmp_flood_enable");
	icmp_threshold = nvram_get("icmp_flood_data");
	udp_flood = nvram_get("udp_flood_enable");
	udp_threshold = nvram_get("udp_flood_data");
	tcp_flood = nvram_get("tcp_syn_flood_enable");
	tcp_threshold = nvram_get("tcp_syn_flood_data");
	ping_disable = nvram_get("wan_ping_enable");
	
	json_object *myobject = NULL;
	myobject = json_object_new_object();
	
	if (enable  && dos && icmp_flood && icmp_threshold && udp_flood &&
		udp_threshold && tcp_flood && tcp_threshold && ping_disable )
	{
		json_object_object_add(myobject, "enable", json_object_new_string(enable));
		json_object_object_add(myobject, "dos", json_object_new_string(dos));
		json_object_object_add(myobject, "icmp_flood", json_object_new_string(icmp_flood));
		json_object_object_add(myobject, "icmp_threshold", json_object_new_string(icmp_threshold));
		json_object_object_add(myobject, "udp_flood", json_object_new_string(udp_flood));
		json_object_object_add(myobject, "udp_threshold", json_object_new_string(udp_threshold));
		json_object_object_add(myobject, "tcp_flood", json_object_new_string(tcp_flood));
		json_object_object_add(myobject, "tcp_threshold", json_object_new_string(tcp_threshold));
		json_object_object_add(myobject, "ping_disable", json_object_new_string(ping_disable));
		json_object_object_add(object, "confs", myobject);
	}
	else
		ret = NV_FAIL;

	return ret;
}

/*=============================================================================
 * Function Name : set_safe_set_conf
 * Param         : json object format
 * Format        :
 *       {
 *         "enable" : "1", 
 *         "dos" : "1", 
 *         "icmp_flood" : "1", 
 *         "icmp_threshold" : "500", 
 *         "udp_flood" : "1", 
 *         "udp_threshold" : "500", 
 *         "tcp_flood" : "1", 
 *         "tcp_threshold" : "500", 
 *         "ping_disable" : "1" 
 *       }
 * Description   : Use nvram handler function to set confs,return success or fail
 *===========================================================================*/
 
 int set_safe_set_conf(json_object *object)
{
	int ret = NV_SUCCESS;
	char enable[4] = {0};
	char dos[4] = {0};
	char icmp_flood[4] = {0};
	char icmp_threshold[16] = {0};
	char udp_flood[4] = {0};
	char udp_threshold[16] = {0};
	char tcp_flood[4] = {0};
	char tcp_threshold[16] = {0};
	char ping_disable[4] = {0};

	json_object_object_foreach(object, key, val)
	{
        if (!strcmp(key, "enable"))
        {
        	strcpy(enable, json_object_get_string(val));
		}
		else if (!strcmp(key, "dos"))
		{
			strcpy(dos, json_object_get_string(val));
		}
		else if (!strcmp(key, "icmp_flood"))
		{
			strcpy(icmp_flood, json_object_get_string(val));
		}
		else if (!strcmp(key, "icmp_threshold"))
		{
			strcpy(icmp_threshold, json_object_get_string(val));
		}
		else if (!strcmp(key, "udp_flood"))
		{
			strcpy(udp_flood, json_object_get_string(val));
		}
		else if (!strcmp(key, "udp_threshold"))
		{
			strcpy(udp_threshold, json_object_get_string(val));
		}
		else if (!strcmp(key, "tcp_flood"))
		{
			strcpy(tcp_flood, json_object_get_string(val));
		}
		else if (!strcmp(key, "tcp_threshold"))
		{
			strcpy(tcp_threshold, json_object_get_string(val));
		}
		else
		{
			strcpy(ping_disable, json_object_get_string(val));
		}
	}
	printf("get nvram paras enable:%s, dos:%s\n", enable, dos);

	if (!strcmp(enable, "0"))
	{
		nvram_set("firewall_enable", "0");
	}
	else
	{
		nvram_set("firewall_enable","1");
		nvram_set("dos_enable", dos);
		nvram_set("icmp_flood_enable", icmp_flood);
		if(!strcmp(icmp_flood, "1"))
		{
			nvram_set("icmp_flood_data", icmp_threshold);
		}
		nvram_set("udp_flood_enable", udp_flood);
		if(!strcmp(udp_flood, "1"))
		{
			nvram_set("udp_flood_data", udp_threshold);
		}
		nvram_set("tcp_syn_flood_enable", tcp_flood);
		if(!strcmp(tcp_flood, "1"))
		{
			nvram_set("tcp_syn_flood_data", tcp_threshold);
		}
		nvram_set("wan_ping_enable", ping_disable);
	}
	
	nvram_commit();

	return ret;
	
}
